# Projecte KenKen - Tercera Entrega

Aquest projecte és una implementació del joc KenKen per a l'assignatura PROP (Projectes de Programació). El nostre grup, 12.3, ha desenvolupat aquest projecte sota la supervisió del professor Carles Arnal.

## Membres de l'Equip:
- Gerard Ferrer Oriol
- Albert Betorz López
- Sergi Pla Casamitjana
- Bart Sebastiaan Zanen

KenKen és un joc de lògica i matemàtiques similar als sudokus, on els jugadors han d'omplir una quadrícula amb nombres seguint certes regles i operacions matemàtiques. Aquest projecte inclou la implementació completa del joc, així com la documentació, els executables, el codi font i les llibreries necessàries.

## Subcarpetes i Fitxers

### DOCS
- Aquest directori conté tota la documentació del projecte KenKen, incloent-hi diagrames de classes, diagrames de casos d'ús, documentació detallada i jocs de prova. Per a més detalls, consulteu el fitxer `index.txt` dins de la carpeta `DOCS`.

### EXE
- Aquest directori conté la sortida de totes les compilacions del projecte KenKen. Inclou els fitxers executables i altres artefactes generats després de compilar el codi font. Per a més detalls, consulteu el fitxer `index.txt` dins de la carpeta `EXE`.

### FONTS
- Aquest directori conté el codi font principal i les llibreries necessàries per al projecte KenKen. Inclou la carpeta `src` i la carpeta `lib`. Per a més detalls, consulteu el fitxer `index.txt` dins de la carpeta `FONTS`.

### lib
- Aquest directori conté les llibreries necessàries per al projecte KenKen. Per a més detalls, consulteu el fitxer `index.txt` dins de la carpeta `lib`.

