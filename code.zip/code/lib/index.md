# Projecte KenKen - Biblioteca de Llibreries

Aquest directori conté les llibreries necessàries per al projecte KenKen. Aquestes llibreries s'utilitzen per proporcionar funcionalitats addicionals i suport per a diverses operacions del projecte. A continuació es descriu breument el propòsit de cada fitxer.

## Fitxers de Llibreria

1. **hamcrest-core-1.3.jar**
   - Llibreria utilitzada per escriure asserts de forma més expressiva en les proves.

2. **junit-4.13.2.jar**
   - Llibreria utilitzada per realitzar proves unitàries del codi Java.

3. **json-20210307.jar**
   - Llibreria utilitzada per treballar amb dades en format JSON.

4. **mockito-core-4.9.0.jar**
   - Llibreria utilitzada per crear mocks en les proves, permetent la simulació de comportaments de classes.

