# Projecte KenKen - FONTS

Aquest directori conté el codi font principal i les llibreries necessàries per al projecte KenKen. A continuació es descriu breument el propòsit de cada subcarpeta.

## Subcarpetes i Fitxers

### src
- Aquesta subcarpeta conté el codi font principal del projecte. Inclou la carpeta `main`, el fitxer `Main.java` i el fitxer `Makefile`. Per a més detalls, consulteu el fitxer `index.txt` dins de la carpeta `src`.

### lib
- Aquesta subcarpeta conté les llibreries necessàries per al projecte. Per a més detalls, consulteu el fitxer `index.txt` dins de la carpeta `lib`.
