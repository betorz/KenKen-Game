# Projecte KenKen - Domini

Aquest directori conté les classes i controladors del domini del projecte KenKen. Aquestes classes i controladors s'encarreguen de la lògica de negoci del joc.

## Subcarpetes i Fitxers

### classes
- Aquest directori conté les classes que gestionen la lògica del domini del joc. Per a més detalls, consulteu el fitxer `index.txt` dins de la carpeta `classes`.

### controllers
- Aquest directori conté els controladors que gestionen les operacions del domini. Per a més detalls, consulteu el fitxer `index.txt` dins de la carpeta `controllers`.

### exceptions
- Aquest directori conté les classes per gestionar les excepcions específiques del joc. Per a més detalls, consulteu el fitxer `index.txt` dins de la carpeta `exceptions`.

