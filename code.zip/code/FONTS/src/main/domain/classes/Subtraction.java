/**
 * The Subtraction class represents a region where the cells must be subtracted to a specific result.
 * It extends the Region class.
 */
package main.domain.classes;

import java.util.List;

public class Subtraction extends Region {
    /**
     * Constructs a new Subtraction object with the specified result and number of cells.
     *
     * @param result the result that the cells in this region must subtract to.
     * @param numCells the number of cells in this region.
     */
    public Subtraction(int result, int numCells) {
        super(result, '-', numCells);
    }

    /**
     * Creates and returns a copy of this Subtraction object.
     *
     * @return a clone of this Subtraction object.
     */
    public Region copy () {
        return new Subtraction(this.result, this.numCells);
    }

    /**
     * Checks if the absolute difference of the first two values in the given list is equal to the result of this Subtraction object.
     *
     * @param values a list of integer values to check.
     * @return true if the absolute difference of the first two values is equal to the result, false otherwise.
     */
    public boolean checkResult(List<Integer> values) {
        if (values.size() < numCells) return true;
        int value1 = values.get(0);
        int value2 = values.get(1);
        return Math.abs(value1 - value2) == result;
    }

    /**
     * Gets the number of possible pairs of values that can be used to reach the result of this Subtraction object.
     *
     * @param size the size of the region.
     * @return the number of possible pairs of values.
     */
    public int getPossibleValues(int size) {
        int count = 0;
        for (int i = 1; i <= size; i++) {
            for (int j = 1; j <= size; j++) {
                if (Math.abs(i - j) == result) {
                    count++;
                    break;
                }
            }
        }
        return count;
    }
}