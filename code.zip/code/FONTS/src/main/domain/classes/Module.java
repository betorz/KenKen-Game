/**
 * The Module class represents a region where the cells must have a modulus operation result to a specific value.
 * It extends the Region class.
 */
package main.domain.classes;

import java.util.List;

public class Module extends Region {

    /**
     * Constructs a new Module object with the specified result and number of cells.
     *
     * @param result the result that the cells in this region must modulus to.
     * @param numCells the number of cells in this region.
     */
    public Module(int result, int numCells) {
        super(result, '%', numCells);
    }

    /**
     * Creates and returns a copy of this Module object.
     *
     * @return a clone of this Module object.
     */
    public Region copy () {
        return new Module(this.result, this.numCells);
    }

    /**
     * Checks if the modulus of the first two values in the given list is equal to the result of this Module object.
     *
     * @param values a list of integer values to check.
     * @return true if the modulus of the first two values is equal to the result, false otherwise.
     */
    public boolean checkResult(List<Integer> values) {
        if (values.size() < numCells) return true;
        int value1 = values.get(0);
        int value2 = values.get(1);
        return (value1%value2 == result) || (value2%value1 == result);
    }

    /**
     * Gets the number of possible values that can be used to reach the result of this Module object.
     *
     * @param size the size of the region.
     * @return the number of possible values.
     */
    public int getPossibleValues(int size) {
        int count = 0;
        for (int i = 1; i <= size; i++) {
            for (int j = 1; j <= size; j++) {
                if ((i%j == result) || (j%i == result)){
                    count++;
                    break;
                }
            }
        }
        return count;
    }
}