/**
 * The Game class represents a game session.
 */
package main.domain.classes;

import main.domain.classes.exceptions.ExceptionGame;

public class Game {
    private Board board;
    private User user;
    private long time;
    private boolean started;
    private boolean finished;
    private long startTime;
    private int hintsUsed;
    private long timePenaltyPerHint = 60000;

    /**
     * Constructs a new Game object with the specified board and user.
     *
     * @param board the game board.
     * @param user the user playing the game.
     */
    public Game(Board board, User user) {
        this.board = board;
        this.user = user;
        this.time = 0;
        this.started = false;
        this.finished = false;
    }

    /**
     * Constructs a new Game object with the specified board, user, time, and number of hints used.
     *
     * @param board the game board.
     * @param user the user playing the game.
     * @param time the time spent on the game.
     * @param hintsUsed the number of hints used.
     */
    public Game(Board board, User user, long time, int hintsUsed) {
        this.board = board;
        this.user = user;
        this.time = time;
        this.started = true;
        this.finished = false;
        this.hintsUsed = hintsUsed;
    }

    /**
     * Returns the board object associated with this game.
     *
     * @return the board object
     */
    public Board getBoard() {
        return board;
    }

    /**
     * Marks the game as finished and performs necessary actions.
     * Stops the game from playing, calculates points, and updates user statistics.
     */
    public void finish() {
        this.finished = true;

        stopPlaying();
        if (board.getId() != -1) {
            int points = calculatePoints();
            int kenkenSize = board.getSize() - 3; //-3 perque nosaltres comencem desde el 3
            int difficulty = board.getDifficulty() - 1; //-1 perque nosaltres la difficultat la comencem desde 1

            user.getStats().updateStats(kenkenSize, difficulty, this.time + this.timePenaltyPerHint*hintsUsed, points);
        }
    }



    
    /**
     * Calculates the final score of the game based on the board size, difficulty level,
     * time taken, and hints used.
     *
     * @return The final score of the game.
     * @throws IllegalArgumentException if the difficulty level is unknown.
     */
    private int calculatePoints() {
        int boardSize = board.getSize();
        double baseScore = Math.pow(boardSize, 2) * 10;
        double difficultyMultiplier;
    
        int difficulty = board.getDifficulty();
        switch (difficulty) {
            case 1:
                difficultyMultiplier = 1.0;
                break;
            case 2:
                difficultyMultiplier = 1.5;
                break;
            case 3:
                difficultyMultiplier = 2.0;
                break;
            case 4:
                difficultyMultiplier = 2.5;
                break;
            default:
                throw new IllegalArgumentException("Unknown difficulty level: " + difficulty);
        }
    
        double timePenalty = (this.time/1000.0) * 0.1;
        double hintPenalty = hintsUsed * 20;
    
        int finalScore = (int) ((baseScore * difficultyMultiplier) - timePenalty - hintPenalty);
        finalScore = Math.max(finalScore, 0);
        return finalScore;
    }

    /**
     * Checks if the game has started.
     *
     * @return true if the game has started, false otherwise.
     */
    public boolean isStarted () {
        return started;
    }

    /**
     * Returns the time of the game.
     *
     * @return the time of the game as a double value
     */
    public double getTime () {
        double dTime = (double) time;
        return dTime;
    }

    /**
     * Returns the number of hints used in the game.
     *
     * @return the number of hints used
     */
    public int getHintsUsed () {
        return hintsUsed;
    }

    /**
     * Starts the game if it is not already finished.
     * Sets the 'started' flag to true and records the start time.
     */
    public void startGame() {
        if (finished) {
            return;
        }
        this.started = true;
        this.startTime = System.currentTimeMillis();
    }

    /**
     * Makes a move in the game by modifying the cell value at the specified row and column.
     *
     * @param r The row index of the cell.
     * @param c The column index of the cell.
     * @param v The new value to be assigned to the cell.
     * @throws ExceptionGame If the specified row or column is out of bounds, or if the value is invalid.
     */
    public void makeMove(int r, int c, int v) throws ExceptionGame {    
        int size = board.getSize();
        if (r < 0 || c < 0 || r >= size || c >= size) {
            throw new ExceptionGame("Out of bounds");
        }

        if (v < 0 || v > size) {
            throw new ExceptionGame("Invalid value");
        }

        board.modifyCellValue(v, r, c);     
    }

    /**
     * Stops the game and calculates the total time played.
     */
    public void stopPlaying() {
        long currentTime = System.currentTimeMillis();
        long time = currentTime - this.startTime;
        this.time += time;    
    }

    /**
     * Checks if the current game solution is correct.
     * 
     * @return true if the solution is correct, false otherwise.
     */
    public boolean checkSolution() {
        return this.board.checkSolution();
    }

    /**
     * Resumes the game by updating the start time to the current system time.
     */
    public void continueGame() {
        startTime = System.currentTimeMillis();
    }

    /**
     * Returns a hint for the current game.
     *
     * @return a Pair object representing the hint coordinates
     */
    public Pair<Integer, Integer> getHint() {
        ++hintsUsed;
        return board.getHint();
    }
}