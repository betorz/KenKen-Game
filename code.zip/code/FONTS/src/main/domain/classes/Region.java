/**
 * The Region class represents a region where the cells must perform a specific operation to a specific result.
 */
package main.domain.classes;

import java.util.List;

/**
 * The abstract class representing a region in a grid.
 */
public abstract class Region {
    protected int result;
    protected char operation;
    protected int numCells;

    /**
     * Constructs a new Region object with the specified result, operation, and number of cells.
     *
     * @param result    the result that the cells in this region must perform to.
     * @param operation the operation that the cells in this region must perform.
     * @param numCells  the number of cells in this region.
     */
    public Region(int result, char operation, int numCells) {
        this.result = result;
        this.operation = operation;
        this.numCells = numCells;
    }

    /**
     * Gets the operation of this Region object.
     *
     * @return the operation.
     */
    public Character getOperation() {
        return operation;
    }

    /**
     * Gets the result of this Region object.
     *
     * @return the result.
     */
    public Integer getResult() {
        return result;
    }

    /**
     * Gets the number of cells in this Region object.
     *
     * @return the number of cells.
     */
    public Integer getNumCells() {
        return numCells;
    }

    /**
     * Creates and returns a copy of this Region object.
     *
     * @return a clone of this Region object.
     */
    public abstract Region copy();

    /**
     * Checks if the operation on the given values is equal to the result of this Region object.
     *
     * @param values a list of integer values to check.
     * @return true if the operation on the values is equal to the result, false otherwise.
     */
    public abstract boolean checkResult(List<Integer> values);

    /**
     * Gets the possible values that can be assigned to the cells in this Region object.
     *
     * @param size the size of the grid.
     * @return the possible values.
     */
    public abstract int getPossibleValues(int size);
}