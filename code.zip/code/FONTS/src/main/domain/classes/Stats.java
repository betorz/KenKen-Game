/**
 * The Stats class represents the statistics of a player.
 */
package main.domain.classes;
import java.util.Arrays;

public class Stats {
    private int points;
    private int solvedPerc; //% of solved KenKens from the database
    private int solved; //# of solved kenkens
    private long[][] times; //first -> 0-6 (3x3, 4x4, 5x5, 6x6, 7x7, 8x8, 9x9). Second -> Difficulty 0-3 (easy, medium, hard, expert)
    private int[] solvedSize; //0-6 (3x3, 4x4, 5x5, 6x6, 7x7, 8x8, 9x9) -> # of solved for each size type
    private int[] solvedDifficulty; //Difficulty 0-3 (easy, medium, hard, expert) -> # of solved for each difficulty level

    public final long MAX_TIME = 99999999;

    /**
     * Constructs a new Stats object with default values.
     */
    public Stats() {
        this.points = 0;
        this.solvedPerc = 0;
        this.solved = 0;
        this.times = new long[7][4];
        for (int i = 0; i < times.length; i++) {
            Arrays.fill(times[i], MAX_TIME);
        }
        this.solvedSize = new int[7];
        this.solvedDifficulty = new int[4];
    }

    /**
     * Constructs a new Stats object with the specified values.
     *
     * @param points the number of points.
     * @param solved the number of solved kenkens.
     * @param times the times for each size and difficulty.
     * @param solvedSize the number of solved kenkens for each size.
     * @param solvedDifficulty the number of solved kenkens for each difficulty.
     */
    public Stats(int points, int solved, long[][] times, int[] solvedSize, int[] solvedDifficulty) {
        this.points = points;
        this.solved = solved;
        this.times = times;
        this.solvedSize = solvedSize;
        this.solvedDifficulty = solvedDifficulty; 
        updateSolvedPerc();
    }

    /**
     * Sets the time for a specific size and difficulty level.
     *
     * @param size       the size of the problem
     * @param difficulty the difficulty level of the problem
     * @param time       the time taken to solve the problem
     */
    public void setTime(int size, int difficulty, long time) {
        times[size][difficulty] = time;
    }

    /**
     * Returns the points.
     *
     * @return the points
     */
    public int getPoints() {
        return points;
    }

    /**
     * Returns the percentage of solved problems.
     *
     * @return the percentage of solved problems
     */
    public int getSolvedPerc() {
        return solvedPerc;
    }

    /**
     * Returns the number of solved problems.
     *
     * @return the number of solved problems
     */
    public int getSolved() {
        return solved;
    }

    /**
     * Returns the number of times a specific size and difficulty combination has been recorded.
     *
     * @param size       the size of the combination
     * @param difficulty the difficulty of the combination
     * @return the number of times the combination has been recorded
     */
    public long getTimes(int size, int difficulty) {
        return times[size][difficulty];
    }

    /**
     * Returns the times array.
     *
     * @return the times array
     */
    public long[][] getTimes() {
        return times;
    }

    /**
     * Returns the number of solved items for a given size.
     *
     * @param size the size of the items
     * @return the number of solved items for the given size
     */
    public int getSolvedSize(int size) {
        return solvedSize[size];
    }

    /**
     * Returns the array of solved sizes.
     *
     * @return the array of solved sizes
     */
    public int[] getSolvedSize() {
        return solvedSize;
    }

    /**
     * Returns the number of solved problems for a given difficulty level.
     *
     * @param difficulty the difficulty level of the problems
     * @return the number of solved problems for the given difficulty level
     */
    public int getSolvedDifficulty(int difficulty) {
        return solvedDifficulty[difficulty];
    }

    /**
     * Returns an array representing the solved difficulty levels.
     *
     * @return an array of integers representing the solved difficulty levels.
     */
    public int[] getSolvedDifficulty() {
        return solvedDifficulty;
    }

    /**
     * Updates the points of the stats by adding the specified amount of points.
     *
     * @param points the amount of points to be added
     */
    public void updatePoints(int points) {
        this.points += points;
    }

    /**
     * Updates the percentage of solved puzzles based on the total number of puzzles.
     * The percentage is calculated by dividing the number of solved puzzles by the total number of puzzles and multiplying by 100.
     * Note: The total number of puzzles is currently set to 28. Modify the calculation if the number of puzzles changes.
     */
    public void updateSolvedPerc() {
        solvedPerc = (int)(((double)solved/28)*100);
    }

    /**
     * Updates the count of solved problems for a given size.
     *
     * @param size the size of the problem
     */
    public void updateSolvedSize(int size) {
        solvedSize[size]++;
    }

    /**
     * Updates the count of solved problems for a specific difficulty level.
     *
     * @param difficulty the difficulty level of the solved problem
     */
    public void updateSolvedDifficulty(int difficulty) {
        solvedDifficulty[difficulty]++;
    }

    /**
     * Updates the statistics based on the given parameters.
     * If the level has already been completed, it updates the points, solved difficulty, solved size,
     * solved percentage, and time for the given size and difficulty.
     * If the level has not been completed yet, it updates the time for the given size and difficulty
     * only if the new time is less than the current time.
     *
     * @param size       the size of the level
     * @param difficulty the difficulty of the level
     * @param time       the time taken to complete the level
     * @param points     the points earned for completing the level
     */
    public void updateStats(int size, int difficulty, long time, int points) {
        if(times[size][difficulty] == MAX_TIME) {   

            updatePoints(points);
            updateSolvedDifficulty(difficulty);
            updateSolvedSize(size);
            ++solved;
            updateSolvedPerc();
            setTime(size, difficulty, time);
        }
        else {
            if(time < times[size][difficulty]) setTime(size, difficulty, time);
        }
    }
}