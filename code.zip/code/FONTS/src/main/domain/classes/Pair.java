/**
 * The Pair class represents a pair of two objects.
 *
 * @param <X> the type of the first object in the pair.
 * @param <Y> the type of the second object in the pair.
 */
package main.domain.classes;

public class Pair<X, Y> {
    private X x;
    private Y y;

    /**
     * Constructs a new Pair object with the specified values.
     *
     * @param x the value of the first object in the pair.
     * @param y the value of the second object in the pair.
     */
    public Pair(X x, Y y) {
        this.x = x;
        this.y = y;
    }

    /**
     * Gets the value of the first object in the pair.
     *
     * @return the value of the first object.
     */
    public X getX() {
        return x;
    }

    /**
     * Gets the value of the second object in the pair.
     *
     * @return the value of the second object.
     */
    public Y getY() {
        return y;
    }

    /**
     * Sets the value of the first object in the pair.
     *
     * @param x the new value of the first object.
     */
    public void setX(X x) {
        this.x = x;
    }

    /**
     * Sets the value of the second object in the pair.
     *
     * @param y the new value of the second object.
     */
    public void setY(Y y) {
        this.y = y;
    }
}