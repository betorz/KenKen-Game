/**
 * The Equal class represents a region where the cells must be equal to a specific result.
 * It extends the Region class.
 */
package main.domain.classes;

import java.util.List;

public class Equal extends Region {

    /**
     * Constructs a new Equal object with the specified result and number of cells.
     *
     * @param result the result that the cells in this region must be equal to.
     * @param numCells the number of cells in this region.
     */
    public Equal(int result, int numCells) {
        super(result, '=', numCells);
    }

    /**
     * Creates and returns a copy of this Equal object.
     *
     * @return a clone of this Equal object.
     */
    public Region copy () {
        return new Equal(this.result, this.numCells);
    }

    /**
     * Checks if the first value in the given list is equal to the result of this Equal object.
     *
     * @param values a list of integer values to check.
     * @return true if the first value is equal to the result, false otherwise.
     */
    public boolean checkResult(List<Integer> values) {
        return (values.get(0) == result);
    }

    /**
     * Gets the number of possible values that can be used to reach the result of this Equal object.
     *
     * @param size the size of the region.
     * @return the number of possible values.
     */
    public int getPossibleValues(int size) {
        return 1;
    }
}