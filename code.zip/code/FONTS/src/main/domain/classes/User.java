/**
 * The User class represents a user with a username, password, and statistics.
 */
package main.domain.classes;

public class User {
    
    private String username;
    private String password;

    private Stats stats;
    
    /**
     * Constructs a new User object with the specified username and password.
     * A new Stats object is created for this user.
     *
     * @param username the username of the user.
     * @param password the password of the user.
     */
    public User(String username, String password) {
        this.username = username;
        this.password = password;
        this.stats = new Stats();
    }

    /**
     * Constructs a new User object with the specified username, password, and Stats object.
     *
     * @param username the username of the user.
     * @param password the password of the user.
     * @param newStats the Stats object of the user.
     */
    public User(String username, String password, Stats newStats) {
        this.username = username;
        this.password = password;
        this.stats = newStats;
    }

    /**
     * Returns the username of the user.
     *
     * @return the username of the user
     */
    public String getUsername() {
        return username;
    }

    /**
     * Returns the password of the user.
     *
     * @return the password of the user
     */
    public String getPassword() {
        return password;
    }

    /**
     * Represents the statistics of a user.
     */
    public Stats getStats() {
        return stats;
    }
    
    /**
     * Sets the password for the user.
     *
     * @param password the new password to set
     */
    public void setPassword(String password) {
        this.password = password;
    }
}
