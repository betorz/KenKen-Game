# Projecte KenKen - Exceptions

Aquest directori conté les classes d'excepcions específiques del projecte KenKen. A continuació es descriu breument el propòsit de cada fitxer i les classes que conté.

## Fitxers i Classes

1. **ExceptionGame.java**
   - Classe per gestionar excepcions relacionades amb el joc en general. Aquesta excepció es llença quan es produeixen errors generals en el funcionament del joc.

2. **ExceptionUser.java**
   - Classe per gestionar excepcions relacionades amb l'usuari. Aquesta excepció es llença quan hi ha problemes específics amb les dades o accions de l'usuari.

3. **ExceptionBoard.java**
   - Classe per gestionar excepcions relacionades amb el tauler del joc. Aquesta excepció es llença quan es produeixen errors en la manipulació o configuració del tauler.

4. **ExceptionRankingEmpty.java**
   - Classe per gestionar excepcions quan el rànquing està buit. Aquesta excepció es llença quan es realitza una operació que requereix dades del rànquing i aquest es troba buit.
