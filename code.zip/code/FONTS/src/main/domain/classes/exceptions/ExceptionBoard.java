/**
 * ExceptionBoard is a custom exception class that extends the Java Exception class.
 * It is used to handle exceptions specific to the Board domain.
 */
package main.domain.classes.exceptions;

public class ExceptionBoard extends Exception {

    /**
     * Constructs a new ExceptionBoard with a specified detail message.
     * @param message the detail message. The detail message is saved for 
     *                later retrieval by the Throwable.getMessage() method.
     */
    public ExceptionBoard(String message) {
        super(message);
    }
    
}