/**
 * ExceptionGame is a custom exception class that extends the Java Exception class.
 * It is used to handle exceptions specific to the Game domain.
 */
package main.domain.classes.exceptions;

public class ExceptionGame extends Exception {

    /**
     * Constructs a new ExceptionGame with a specified detail message.
     * @param message the detail message. The detail message is saved for 
     *                later retrieval by the Throwable.getMessage() method.
     */
    public ExceptionGame(String message) {
        super(message);
    }
    
}