/**
 * ExceptionRankingEmpty is a custom exception class that extends the Java Exception class.
 * It is used to handle exceptions specific to an empty Ranking.
 */
package main.domain.classes.exceptions;

public class ExceptionRankingEmpty extends Exception {

    /**
     * Constructs a new ExceptionRankingEmpty with a predefined detail message.
     * The detail message is "Ranking exception: The ranking is empty".
     */
    public ExceptionRankingEmpty() {
        super("\nRanking exception: The ranking is empty");
    }
    
}