/**
 * The Board class represents a game board.
 */
package main.domain.classes;

import java.util.List;
import java.util.Queue;
import java.util.Random;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Collections;

import main.domain.classes.exceptions.ExceptionBoard;


public class Board {
    private static int nextId = 0;
    private int id;
    private int size;
    private int difficulty; //1->EASY, 2->MEDIUM, 3->HARD, 4->EXPERT
    private List<Region> regions;
    private Cell[][] cells;

       
    /**
     * Constructs a new Board object with the specified size.
     * 
     * @param size the size of the board
     */
    public Board(int size) {
        this.id = getNextId();
        this.size = size;
        this.regions = new ArrayList<>();
        this.cells = new Cell[size][size];
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                cells[i][j] = new Cell(i, j, 0);
            }
        }
    }   
    
    /**
     * Constructs a new Board object with the specified size and id.
     * 
     * @param size the size of the board
     * @param id the id of the board
     */
    public Board(int size, int id) {
        this.id = id;
        this.size = size;
        this.regions = new ArrayList<>();
        this.cells = new Cell[size][size];
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                cells[i][j] = new Cell(i, j, 0);
            }
        }
    }

    /**
     * Creates a deep copy of the current board.
     * 
     * @return A new instance of the Board class that is an exact copy of the current board.
     */
    public Board copy() {
        Board bcopy = new Board(size, id);
        
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                Cell ccopy = cells[i][j].copyCell();
                bcopy.setCell(i, j, ccopy);
            }
        }
        for (Region region : regions) {
            Region rcopy = region.copy();
            bcopy.addRegion(rcopy);
        }
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                Cell nextCell = cells[i][j].getNextCell();
                int rNext = nextCell.getRow();
                int cNext = nextCell.getColumn();
                Cell copyNextCell = bcopy.getCell(rNext, cNext);
                Cell copyCell = bcopy.getCell(i, j);
                copyCell.setNextCell(copyNextCell);
            }
        }
        bcopy.calculateDifficulty();
        return bcopy;
    }

    /**
     * Adds a region to the board.
     *
     * @param r the region to be added
     */
    public void addRegion(Region r) {
        regions.add(r);
    }

    /**
     * Creates a new region based on the given operation, result, and coordinate cells.
     * Adds the new region to the list of regions and updates the cells accordingly.
     *
     * @param op          the operation code for the region
     * @param result      the result value for the region
     * @param coordCells  the list of coordinate cells that belong to the region
     */
    public void makeRegion(int op, int result, List<Pair<Integer, Integer>> coordCells) {
        int numCells = coordCells.size();
        Region newRegion = null;
        switch (op) {
            case 0:
                newRegion = new Equal(result, numCells);
                break;
            case 1:
                newRegion = new Addition(result, numCells);
                break;
            case 2:
                newRegion = new Subtraction(result, numCells);
                break;
            case 3:
                newRegion = new Multiplication(result, numCells);
                break;
            case 4:
                newRegion = new Division(result, numCells);
                break;
            case 5:
                newRegion = new Module(result, numCells);
                break;
            case 6:
                newRegion = new Power(result, numCells);
                break;
        }
        regions.add(newRegion);
        int regId = regions.size() - 1;
        for (int i = 0; i < numCells; ++i) {
            Pair<Integer, Integer> p = coordCells.get(i);
            int r = p.getX() - 1;
            int c = p.getY() - 1;
            Cell cell = cells[r][c];
            cell.setRegId(regId);

            Pair<Integer, Integer> pNext = coordCells.get((i + 1)%numCells);
            int rNext = pNext.getX() - 1;
            int cNext = pNext.getY() - 1;
            cell.setNextCell(cells[rNext][cNext]);
        }
      
    }

    /**
     * Creates a new board based on the given board information.
     *
     * @param boardInfo   the list of integers containing the board information
     * @param boardId     the ID of the board
     * @param difficulty  the difficulty level of the board
     * @return a new Board object
     */
    public Board makeBoard(List<Integer> boardInfo, int boardId, int difficulty) {
        int size = boardInfo.get(0);
        Board board = new Board(size, boardId);
        int numRegions = boardInfo.get(1);
        int p = 2;
        for (int i = 0; i < numRegions; ++i) {
            int op = boardInfo.get(p);
            int result = boardInfo.get(p+1);
            int numCells = boardInfo.get(p+2);
            p += 3;
            List<Pair<Integer, Integer>> cells = new ArrayList<>();

            for (int j = 0; j < numCells; ++j) {
                int r = boardInfo.get(p);
                int c = boardInfo.get(p+1);
                p += 2;
                cells.add(new Pair<>(r, c));
                if  (p < boardInfo.size() && boardInfo.get(p) == -1) {
                    ++p;
                    if (p < boardInfo.size()) modifyCellValue(boardInfo.get(p), r, c);      
                    p+=2;
                }
                
            }
            board.makeRegion(op, result, cells);
        }
        if (difficulty == -1) {
            board.calculateDifficulty();;
        }
        else {
            board.setDifficulty(difficulty);
        }
        return board;
        
    }

    /**
     * Returns the next available ID for a board.
     *
     * @return the next available ID
     */
    private static int getNextId() {
        return nextId++;
    }

    /**
     * Returns the ID of the board.
     *
     * @return the ID of the board
     */
    public int getId() {
        return id;
    }

    /**
     * Returns the difficulty level of the board.
     *
     * @return the difficulty level of the board
     */
    public int getDifficulty() {
        return difficulty;
    }

    /**
     * Returns the size of the board.
     *
     * @return the size of the board
     */
    public int getSize() {
        return size;
    }

    /**
     * Returns the number of possible values for a given region index.
     *
     * @param i the index of the region
     * @return the number of possible values for the region
     */
    public int getNumPossibleValues(int i) {
        return regions.get(i).getPossibleValues(size);
    }

    /**
     * Returns the number of regions in the board.
     *
     * @return the number of regions
     */
    public int getNumRegions() {
        return regions.size();
    }

    /**
     * Returns the operation of the region at the specified index.
     *
     * @param i the index of the region
     * @return the operation of the region
     */
    public char getRegionOp(int i) {
        return regions.get(i).getOperation();
    }

    /**
     * Returns the result of the region at the specified index.
     *
     * @param i the index of the region
     * @return the result of the region at the specified index
     */
    public int getRegionResult(int i) {
        return regions.get(i).getResult();
    }

    /**
     * Returns the region ID of the cell at the specified row and column.
     *
     * @param r the row index of the cell
     * @param c the column index of the cell
     * @return the region ID of the cell
     */
    public int getRegId(int r, int c) {
        return cells[r][c].getRegId();
    }

    /**
     * Sets the difficulty level of the board.
     *
     * @param difficulty the difficulty level to be set
     */
    public void setDifficulty(int difficulty) {
        this.difficulty = difficulty;
    }

    /**
     * Calculates the difficulty of the board based on the regions and their results.
     * The difficulty is determined by the number of unique operations and the size of the regions.
     * The difficulty is capped at a maximum value of 4.
     */
    public void calculateDifficulty() {
        difficulty = 1;
        HashSet<Character> operations = new HashSet<>();
        for (Region region : regions) {
            operations.add(region.getOperation());
            if(region.getResult() >= size*3) ++difficulty;
        }
        if (operations.size() >= 4) ++difficulty;
        difficulty = Math.min(difficulty, 4);

    }

    /**
     * Retrieves the value of the cell at the specified row and column.
     *
     * @param r The row index of the cell.
     * @param c The column index of the cell.
     * @return The value of the cell at the specified row and column, or -1 if the row or column is out of bounds.
     */
    public int getCellValue(int r, int c) {
        if (r >= 0 && r < size && c >= 0 && c < size) {
            return cells[r][c].getValue();
        }
        return -1;
    }

    /**
     * Returns the cell at the specified row and column.
     *
     * @param r the row index of the cell
     * @param c the column index of the cell
     * @return the cell at the specified row and column
     */
    public Cell getCell(int r, int c) {
        return cells[r][c];
    }

    /**
     * Sets the specified cell at the given row and column coordinates.
     *
     * @param r    the row index of the cell
     * @param c    the column index of the cell
     * @param cell the cell to be set
     */
    public void setCell(int r, int c, Cell cell) {
        cells[r][c] = cell;
    }

    /**
     * Modifies the value of a cell at the specified row and column.
     *
     * @param value the new value to set for the cell
     * @param r the row index of the cell
     * @param c the column index of the cell
     */
    public void modifyCellValue(int value, int r, int c) {
            cells[r][c].setValue(value);
    }

    /**
     * Clears the value of the cell at the specified row and column.
     *
     * @param r the row index of the cell
     * @param c the column index of the cell
     */
    public void clearCellValue(int r, int c) {
        cells[r][c].clear();
    }

    /**
     * Checks if the given value satisfies the row and column rule at the specified position.
     *
     * @param r The row index.
     * @param c The column index.
     * @param v The value to be checked.
     * @return {@code true} if the value satisfies the row and column rule, {@code false} otherwise.
     */
    public boolean checkRowColRule(int r, int c, int v) {
        if (v != 0) {
            for (int i = 0; i < size; i++) {
                if (i != c && cells[r][i].getValue() == v)
                    return false;

                if (i != r && cells[i][c].getValue() == v)
                    return false;
            }
        }
        return true;
    }  

    /**
     * Checks the operation rule for a specific cell in the board.
     * 
     * @param r The row index of the cell.
     * @param c The column index of the cell.
     * @return true if the operation rule is satisfied for the cell, false otherwise.
     */
    public boolean checkOpRule(int r, int c) {
        Cell cell = cells[r][c];
        int regId = cell.getRegId();
        Region region = regions.get(regId);

        int numCells = region.getNumCells();
        List<Integer> values = new ArrayList<>(numCells);
        for (int i = 0; i < numCells; ++i) {
            int value = cell.getValue();
            if (value != 0) values.add(value);
            cell = cell.getNextCell();
        }
        return region.checkResult(values);
    }

    /**
     * Returns a matrix containing the values of each cell in the board.
     *
     * @return a 2D array of integers representing the cell values matrix.
     */
    public int[][] getCellValuesMatrix() {
        int[][] values = new int[size][size];
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                values[i][j] = cells[i][j].getValue();
            }
        }
        return values;
    }

    /**
     * Returns a matrix containing the region IDs of each cell in the board.
     *
     * @return a 2D array of integers representing the region IDs of each cell
     */
    public int[][] getCellRegIdsMatrix() {
        int[][] regIds = new int[size][size];
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                regIds[i][j] = cells[i][j].getRegId();
            }
        }
        return regIds;
    }
    
    /**
     * Checks if the current board configuration is a valid solution.
     * 
     * @return true if the board is a valid solution, false otherwise.
     */
    public boolean checkSolution() {
        HashSet<Integer> regionsId = new HashSet<>();
        for (int i = 0; i < size; i++) {
            HashSet<Integer> rowValues = new HashSet<>();
            HashSet<Integer> colValues = new HashSet<>();
            for (int j = 0; j < size; j++) {
                int rowValue = cells[i][j].getValue();
                int colValue = cells[j][i].getValue();
                if (rowValue == 0 || colValue == 0 || !rowValues.add(rowValue) || !colValues.add(colValue)) {
                    return false;
                }
                
                if (regionsId.add(cells[i][j].getRegId())) {
                    if (!checkOpRule(i, j)) {
                        return false;
                    }
                }
            }
        }
        return true;
    }
    
    /**
     * Solves the board using a solver object.
     * 
     * @return true if the board is solvable, false otherwise.
     */
    public boolean solveBoard() {
        Solver solver = new Solver(this);
        return solver.solve();
    }

    /**
     * Retrieves a hint for the current board state.
     * 
     * @return A Pair object representing the row and column indices of the hint cell.
     */
    public Pair<Integer,Integer> getHint() {
        Board copyBoard = copy();
        copyBoard.solveBoard();
        Random rand = new Random();
        int size = copyBoard.getSize();
        int row = rand.nextInt(size);
        int col = rand.nextInt(size);
        boolean found = false;
        int solValue = copyBoard.getCellValue(row, col);
    
        int value = getCellValue(row, col);
        while (!found) { 

            if (value != solValue) {
                found = true;
            } 
            else {
                ++col;
                if (col >= size) {
                    col = 0;
                    row = (row+1)%size;
                }
            }
            solValue = copyBoard.getCellValue(row, col);
            value = getCellValue(row, col);
        }
        modifyCellValue(solValue, row, col);
        return new Pair<Integer,Integer>(row, col);
    }

    /**
     * Generates a new board with the given size, regions information, and predetermined operations.
     *
     * @param size the size of the board.
     * @param regionsInfo a list of integers representing the sizes of the regions.
     * @param predOps a set of integers representing the predetermined operations.
     * @return a new Board object.
     * @throws ExceptionBoard if the region size is greater than the board size.
     */
    public Board generateBoard(int size, List<Integer> regionsInfo, HashSet<Integer> predOps) throws ExceptionBoard {
        Board board = new Board(size, -1);
        board.fillBoard();
        Collections.sort(regionsInfo, Collections.reverseOrder());
        board.generateRegions(regionsInfo, predOps);
        for (int i = 0; i < size; ++i) {
            for (int j = 0; j < size; ++j) {
                board.modifyCellValue(0, i, j);
            }
        }
        return board;
    }

    /**
     * Fills the board with possible values for each cell.
     * 
     * @throws RuntimeException if the board cannot be filled.
     */
    private void fillBoard() {
        int size = getSize();
        @SuppressWarnings("unchecked")
        List<Integer>[][] possibleValues = new ArrayList[size][size];
    
        // Inicializar listas de valores posibles
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                possibleValues[i][j] = new ArrayList<>();
                for (int value = 1; value <= size; value++) {
                    possibleValues[i][j].add(value);
                }
            }
        }
    
        // Intentar llenar el tablero
        if (!fillBoardRecursively(0, 0, possibleValues)) {
            throw new RuntimeException("No se pudo llenar el tablero.");
        }
    }

    /**
     * Recursively fills the board with valid values.
     *
     * @param row             the current row index
     * @param col             the current column index
     * @param possibleValues  the possible values for each cell in the board
     * @return                true if the board is successfully filled, false otherwise
     */
    private boolean fillBoardRecursively(int row, int col, List<Integer>[][] possibleValues) {
        int size = getSize();
        if (col == size) {
            col = 0;
            row++;
        }

        if (row == size) {
            return true;
        }
    
        List<Integer> possible = new ArrayList<>(possibleValues[row][col]);
        Collections.shuffle(possible);

        for (int value : possible) {
            if (checkRowColRule(row, col, value)) {
                modifyCellValue(value, row, col);
                List<Integer>[][] newPossibleValues = copyPossibleValues(possibleValues);
                updatePossibleValues(row, col, value, newPossibleValues);
    
                if (fillBoardRecursively(row, col + 1, newPossibleValues)) {
                    return true;
                }
    
                modifyCellValue(0, row, col);
            }
        }
    
        return false;
    }

    /**
     * Updates the possible values for a given cell in the board.
     *
     * @param row            the row index of the cell
     * @param col            the column index of the cell
     * @param value          the value to be removed from the possible values
     * @param possibleValues the 2D array representing the possible values for each cell
     */
    private void updatePossibleValues(int row, int col, int value, List<Integer>[][] possibleValues) {
        int size = getSize();
    
        for (int i = 0; i < size; i++) {
            possibleValues[row][i].remove((Integer) value);
            possibleValues[i][col].remove((Integer) value);
        }
    }
    
    /**
     * Creates a deep copy of the given 2D array of possible values.
     *
     * @param possibleValues the original 2D array of possible values
     * @return a new 2D array containing a deep copy of the original possible values
     */
    private List<Integer>[][] copyPossibleValues(List<Integer>[][] possibleValues) {
        int size = getSize();
        @SuppressWarnings("unchecked")
        List<Integer>[][] newPossibleValues = new ArrayList[size][size];
    
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                newPossibleValues[i][j] = new ArrayList<>(possibleValues[i][j]);
            }
        }
    
        return newPossibleValues;
    }

    /**
     * Generates regions on the board based on the given regions information and predetermined operations.
     * 
     * @param regionsInfo A list of integers representing the sizes of the regions.
     * @param predOps A set of integers representing the predetermined operations.
     * @throws ExceptionBoard if the region size is greater than the board size.
     */
    private void generateRegions(List<Integer> regionsInfo, HashSet<Integer> predOps) throws ExceptionBoard {
        boolean[][] visited = new boolean[size][size]; 
        boolean[][] visitedCopy = new boolean[size][size];

        List<Pair<Integer, Integer>> allCells = new ArrayList<>();
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                if (!visited[i][j]) {
                    allCells.add(new Pair<>(i, j));
                }
            }
        }
        Collections.shuffle(allCells);

        for (Pair<Integer, Integer> p : allCells) {
            int row = p.getX();
            int col = p.getY();

            if (!visited[row][col]) {
                int regionSize = -1;
                if (!regionsInfo.isEmpty()) {
                    regionSize = regionsInfo.get(0);
                    regionsInfo.remove(0);
                    if (regionSize > size) {
                        throw new ExceptionBoard("Region size cant be > board size");
                    }
                }
                List<Pair<Integer, Integer>> regionCells = exploreRegion(row, col, visitedCopy, regionSize);
                for (Pair<Integer, Integer> regionCell : regionCells) {
                    visited[regionCell.getX()-1][regionCell.getY()-1] = true;
                }
                visitedCopy = visited;
                int op = determineOperation(regionCells, predOps);
                int result = calculateResult(regionCells, op);
                makeRegion(op, result, regionCells);
            }
        }
    }

    /**
     * Determines the operation to be performed based on the given list of cells and set of predetermined operations.
     * 
     * @param cells    the list of cells
     * @param predOps  the set of predetermined operations
     * @return         the selected operation
     */
    private int determineOperation(List<Pair<Integer, Integer>> cells, HashSet<Integer> predOps) {
        Random random = new Random();
        int regionSize = cells.size();
        int[] possibleOperations;
        if (regionSize == 1) {
            possibleOperations = new int[]{0};
        }
        
        else if (regionSize == 2) {
            Pair<Integer, Integer> p1 = cells.get(0);
            Pair<Integer, Integer>  p2 = cells.get(1);
            int value1 = getCellValue(p1.getX()-1, p1.getY()-1);
            int value2 = getCellValue(p2.getX()-1, p2.getY()-1);
            if ((value1 / value2 != 0 && value1%value2 == 0) || (value2 / value1 != 0 && value2%value1 == 0)) {
                possibleOperations = new int[]{1, 2, 3, 4, 5, 6, 2, 4, 5, 6};
            }
            else {
                possibleOperations = new int[]{1, 2, 3, 5, 6, 2, 5, 6};
            }
        }
        else {
            possibleOperations = new int[]{1, 3}; 
        }
        int selectedOperation = possibleOperations[random.nextInt(possibleOperations.length)];

        while (!predOps.contains(selectedOperation)) {
            selectedOperation = possibleOperations[random.nextInt(possibleOperations.length)];
        } 
        
        return selectedOperation;
    }

    /**
     * Calculates the result of a given region operation on a list of cells.
     *
     * @param regionCells The list of cells in the region.
     * @param regionOp The region operation to be performed.
     *                 - 0: Return the value of the first cell.
     *                 - 1: Return the sum of all cell values.
     *                 - 2: Return the absolute difference between the values of the first two cells.
     *                 - 3: Return the product of all cell values.
     *                 - 4: Return the integer division of the first cell value by the second cell value.
     *                 - 5: Return the remainder of the integer division of the first cell value by the second cell value.
     *                 - 6: Return the first cell value raised to the power of the second cell value.
     * @return The result of the region operation.
     */
    int calculateResult(List<Pair<Integer, Integer>> regionCells, int regionOp) {
        List<Integer> values = new ArrayList<>();
        for (Pair<Integer, Integer> p : regionCells) {
            values.add(getCellValue(p.getX()-1, p.getY()-1));
        }
        int result = 0;
        if (regionOp == 0) {
            result = values.get(0);
        }
        else if (regionOp == 1){
            for (int v : values) {
                result += v;
            }
        }
        else if (regionOp == 2){
            int v1 = values.get(0);
            int v2 = values.get(1);
            if (v1 > v2) result = v1 - v2;
            else result = v2 -v1;
        }
        else if (regionOp == 3){
            result = 1;
            for (int v : values) {
                result *= v;
            }
        }
        else if (regionOp == 4){
            int v1 = values.get(0);
            int v2 = values.get(1);
            if (v1 % v2 == 0) result = v1/v2;
            else result = v2/v1;
        }
        else if (regionOp == 5){
            int v1 = values.get(0);
            int v2 = values.get(1);
            result = v1%v2;
        }
        else if (regionOp == 6){
            int v1 = values.get(0);
            int v2 = values.get(1);
            result = (int) Math.pow(v1, v2);
        }
        return result;
    }

    /**
     * Explores a region starting from the specified cell (i, j) on the board.
     * Returns a list of cells in the explored region.
     *
     * @param i           the row index of the starting cell
     * @param j           the column index of the starting cell
     * @param visited     a 2D boolean array indicating whether a cell has been visited or not
     * @param regionSize  the desired size of the region to explore, or -1 to explore the entire region
     * @return a list of cells in the explored region
     */
    private List<Pair<Integer, Integer>> exploreRegion(int i, int j, boolean[][] visited, int regionSize) {
        List<Pair<Integer, Integer>> regionCells = new ArrayList<>();
        Queue<Pair<Integer, Integer>> queue = new LinkedList<>();
        queue.add(new Pair<>(i, j));

        while (!queue.isEmpty() && regionCells.size() < size) {
            Pair<Integer, Integer> cell = queue.poll();
            int row = cell.getX();
            int col = cell.getY();
            regionCells.add(new Pair<>(row + 1, col + 1));
            if (regionSize != -1 && regionCells.size() == regionSize) {
                break;
            }
            visited[row][col] = true;
            Random random = new Random();
            

            int[][] directions = {{0, 1}, {1, 0}, {0, -1}, {-1, 0}};
            List<int[]> shuffledDirections = Arrays.asList(directions);
            Collections.shuffle(shuffledDirections);

            for (int[] direction : shuffledDirections) {
                int newRow = row + direction[0];
                int newCol = col + direction[1];
                if (newRow >= 0 && newRow < size && newCol >= 0 && newCol < size && !visited[newRow][newCol]) {
                    double probability;
                    int actualRegionSize = regionCells.size() + queue.size();
                    probability = size / actualRegionSize;
                    probability = probability /size;
                    probability = probability * 0.5;
                    
                    if (random.nextDouble() < probability || regionSize != -1) {
                        queue.add(new Pair<>(newRow, newCol));
                    }
                }
            }
        }
        return regionCells;
    }
}