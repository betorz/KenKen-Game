/**
 * The Power class represents a region where the cells must be raised to the power of each other to a specific result.
 * It extends the Region class.
 */
package main.domain.classes;

import java.util.List;

public class Power extends Region {

    /**
     * Constructs a new Power object with the specified result and number of cells.
     *
     * @param result the result that the cells in this region must power to.
     * @param numCells the number of cells in this region.
     */
    public Power(int result, int numCells) {
        super(result, '^', numCells);
    }

    /**
     * Creates and returns a copy of this Power object.
     *
     * @return a clone of this Power object.
     */
    public Region copy () {
        return new Power(this.result, this.numCells);
    }

    /**
     * Checks if the power of the first two values in the given list is equal to the result of this Power object.
     *
     * @param values a list of integer values to check.
     * @return true if the power of the first two values is equal to the result, false otherwise.
     */
    public boolean checkResult(List<Integer> values) {
        if (values.size() < numCells) return true;
        int value1 = values.get(0);
        int value2 = values.get(1);
        return (Math.pow(value1, value2) == result) || (Math.pow(value2, value1) == result);
    }

    /**
     * Gets the number of possible values that can be used to reach the result of this Power object.
     *
     * @param size the size of the region.
     * @return the number of possible values.
     */
    public int getPossibleValues(int size) {
        int count = 0;
        for (int i = 1; i <= size; i++) {
            for (int j = 1; j <= size; j++) {
                if (Math.pow(i, j) == result ||  Math.pow(j, i) == result){
                    count++;
                    break;
                }
            }
        }
        return count;
    }
}