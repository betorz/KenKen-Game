/**
 * The Multiplication class represents a region where the cells must multiply to a specific result.
 * It extends the Region class.
 */
package main.domain.classes;

import java.util.List;

public class Multiplication extends Region {

    /**
     * Constructs a new Multiplication object with the specified result and number of cells.
     *
     * @param result the result that the cells in this region must multiply to.
     * @param numCells the number of cells in this region.
     */
    public Multiplication(int result, int numCells) {
        super(result, '*', numCells);
    }

    /**
     * Creates and returns a copy of this Multiplication object.
     *
     * @return a clone of this Multiplication object.
     */
    public Region copy () {
        return new Multiplication(this.result, this.numCells);
    }

    /**
     * Checks if the multiplication of the given values is equal to the result of this Multiplication object.
     *
     * @param values a list of integer values to check.
     * @return true if the multiplication of the values is equal to the result, false otherwise.
     */
    public boolean checkResult(List<Integer> values) {
        int multiplication = 1;
        for (int value : values) {
            
            multiplication *= value;
            if (multiplication > result) return false;
        }
        if (values.size() < numCells) return true;
        return result == multiplication;
    }

    /**
     * Gets the number of possible values that can be used to reach the result of this Multiplication object.
     *
     * @param size the size of the region.
     * @return the number of possible values.
     */
    public int getPossibleValues(int size) {
        int count = 0;
        for (int i = 1; i <= size; i++) {
            if (result % i == 0) {
                count++;
            }
        }
        return count;
    }
}