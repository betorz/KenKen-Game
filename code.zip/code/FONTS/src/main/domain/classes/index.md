# Projecte KenKen - Domini - Classes

Aquest directori conté les classes del domini del projecte KenKen. Aquestes classes s'encarreguen de la lògica de negoci del joc. A continuació es descriu breument el propòsit de cada fitxer i les classes que conté.

## Fitxers i Classes

1. **Stats.java**
   - Classe per gestionar les estadístiques del joc, com el temps jugat, moviments realitzats, etc.

2. **Addition.java**
   - Classe per representar l'operació d'addició en el joc.

3. **Division.java**
   - Classe per representar l'operació de divisió en el joc.

4. **Solver.java**
   - Classe encarregada de la lògica per resoldre els puzles de KenKen.

5. **Game.java**
   - Classe principal del joc que gestiona la lògica central del mateix.

6. **Board.java**
   - Classe que representa el tauler del joc.

7. **Subtraction.java**
   - Classe per representar l'operació de sostracció en el joc.

8. **Equal.java**
   - Classe per representar l'operació d'igualtat en el joc.

9. **Multiplication.java**
   - Classe per representar l'operació de multiplicació en el joc.

10. **Power.java**
    - Classe per representar l'operació de potenciació en el joc.

11. **User.java**
    - Classe que gestiona la informació de l'usuari del joc.

12. **Cell.java**
    - Classe que representa una cel·la del tauler.

13. **Module.java**
    - Classe que gestiona els mòduls del joc, possiblement relacionats amb diferents nivells o seccions del tauler.

14. **Region.java**
    - Classe per representar les regions del tauler on s'apliquen les regles de les operacions.

15. **Pair.java**
    - Classe auxiliar per gestionar parells de valors, possiblement utilitzada en la lògica del joc.

## Carpeta d'Excepcions

Aquest directori també conté una carpeta anomenada `exceptions`, que inclou classes per gestionar les excepcions específiques del joc. Per a més detalls, consulteu el fitxer `index.txt` dins de la carpeta `exceptions`.


