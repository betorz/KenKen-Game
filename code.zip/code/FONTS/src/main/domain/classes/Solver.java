/**
 * The Solver class represents a solver for a game board.
 */
package main.domain.classes;

import java.util.PriorityQueue;
import java.util.Comparator;
import java.util.List;
import java.util.ArrayList;

public class Solver {
    private Board board;

    /**
     * Constructs a new Solver object with the specified board.
     *
     * @param board the game board to solve.
     */
    public Solver(Board board) {
        this.board = board;
    }

    /**
     * Attempts to solve the game board.
     *
     * @return true if the board is solvable, false otherwise.
     */
    public boolean solve() {
        PriorityQueue<Pair<Integer, Integer>> prioQueue = makePrioQueue();
        return solve(prioQueue); 

    }

    /**
     * Creates a priority queue of pairs of integers, where each pair represents a cell in the board.
     * The priority of each cell is determined by the number of possible values that can be placed in the cell.
     *
     * @return the created priority queue.
     */
    private PriorityQueue<Pair<Integer, Integer>> makePrioQueue() {
        
        List<Integer> numPossibleValues = new ArrayList<>();
        int numRegions = board.getNumRegions();
        for (int i = 0; i < numRegions; i++) {
            numPossibleValues.add(board.getNumPossibleValues(i));
        }

        Comparator<Pair<Integer, Integer>> comparator =
        Comparator.comparing((Pair<Integer, Integer> pair) -> {
                      int regId = board.getRegId(pair.getX(), pair.getY());
                      return numPossibleValues.get(regId);
                     })
                  .thenComparing((Pair<Integer, Integer> pair) -> {
                      return board.getRegId(pair.getX(), pair.getY());
                  });
        PriorityQueue<Pair<Integer, Integer>> prioQueue = new PriorityQueue<>(comparator);

        int size = board.getSize();
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                prioQueue.add(new Pair<>(i, j));
            }
        }
        
        return prioQueue;
    }

    /**
     * Recursively solves the puzzle using backtracking algorithm.
     * 
     * @param prioQueue the priority queue containing the coordinates of the cells to be filled
     * @return true if the puzzle is solved, false otherwise
     */
    private boolean solve(PriorityQueue<Pair<Integer, Integer>> prioQueue) {
        if (prioQueue.isEmpty()) {
            return true;
        }
        
        Pair<Integer, Integer> coords = prioQueue.poll();
        int row = coords.getX();
        int col = coords.getY();
        for (int i = 1; i <= board.getSize(); i++) {
            if (validValue(i, row, col)) {
                PriorityQueue<Pair<Integer, Integer>> prioQueueCopy = new PriorityQueue<>(prioQueue);
                if (solve(prioQueueCopy)) {
                    return true;
                }
                board.modifyCellValue(0, row, col); 
            }
        }
        return false;
    }

    /**
     * Checks if a given value is valid for a specific cell in the board.
     * 
     * @param value the value to be checked
     * @param row the row index of the cell
     * @param col the column index of the cell
     * @return true if the value is valid, false otherwise
     */
    private boolean validValue(int value, int row, int col) {
        int oldValue = board.getCellValue(row, col);
        board.modifyCellValue(value, row, col); 
        boolean valid = board.checkRowColRule(row, col, value) && 
                          board.checkOpRule(row, col); 
        if (!valid) {
            board.modifyCellValue(oldValue, row, col); 
        }
        return valid;
    }
}