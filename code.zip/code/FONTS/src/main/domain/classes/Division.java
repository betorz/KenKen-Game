/**
 * The Division class represents a region where the cells must divide to a specific result.
 * It extends the Region class.
 */
package main.domain.classes;

import java.util.List;

public class Division extends Region {

    /**
     * Constructs a new Division object with the specified result and number of cells.
     *
     * @param result the result that the cells in this region must divide to.
     * @param numCells the number of cells in this region.
     */
    public Division(int result, int numCells) {
        super(result, '/', numCells);
    }

    /**
     * Creates and returns a copy of this Division object.
     *
     * @return a clone of this Division object.
     */
    public Region copy () {
        return new Division(this.result, this.numCells);
    }

    /**
     * Checks if the division of the given values is equal to the result of this Division object.
     *
     * @param values a list of integer values to check.
     * @return true if the division of the values is equal to the result, false otherwise.
     */
    public boolean checkResult(List<Integer> values) {
        if (values.size() < numCells) return true;
        int value1 = values.get(0);
        int value2 = values.get(1);
        if (value1 > value2) return (value1%value2 == 0) && (value1/value2 == result);
        else return (value2%value1 == 0) && (value2/value1 == result);
    }

    /**
     * Gets the number of possible values that can be used to reach the result of this Division object.
     *
     * @param size the size of the region.
     * @return the number of possible values.
     */
    public int getPossibleValues(int size) {
        int count = 0;
        for (int i = 1; i <= size; i++) {
            for (int j = 1; j <= size; j++) {
                if ((i > j && i/j == result && i%j == 0) || (j > i && j/i == result && j%i == 0)) {
                    count++;
                    break;
                }
            }
        }
        return count;
    }
}