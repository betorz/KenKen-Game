/**
 * The Cell class represents a cell in a game board.
 */
package main.domain.classes;

public class Cell {
    private int row;
    private int column;
    private int value;
    private int regId;
    private Cell nextCell;

    /**
     * Constructs a new Cell object with the specified row, column, and value.
     *
     * @param row the row index of the cell.
     * @param column the column index of the cell.
     * @param value the value of the cell.
     */
    public Cell(int row, int column, int value) {
        this.row = row;
        this.column = column;
        this.value = value;
    }

    /**
     * Creates and returns a copy of this Cell object.
     *
     * @return a clone of this Cell object.
     */
    public Cell copyCell() {
        Cell copy = new Cell(row, column, 0);
        copy.setNextCell(getNextCell());
        copy.setRegId(getRegId());
        return copy;
    }

    /**
     * Returns the row index of the cell.
     *
     * @return the row index of the cell
     */
    public int getRow() {
        return row;
    }

    /**
     * Returns the column index of the cell.
     *
     * @return the column index of the cell
     */
    public int getColumn() {
        return column;
    }

    /**
     * Returns the value of the cell.
     *
     * @return the value of the cell
     */
    public int getValue() {
        return value;
    }

    
    /**
     * Returns the region ID of the cell.
     *
     * @return the region ID of the cell
     */
    public int getRegId() {
        return regId;
    }
        
    /**
     * Returns the next cell in the data structure.
     *
     * @return the next cell
     */
    public Cell getNextCell() {
        return nextCell;
    }

    /**
     * Sets the value of the cell.
     *
     * @param value the new value for the cell
     */
    public void setValue(int value) {
       this.value = value;
    }

    /**
     * Sets the next cell in the linked list.
     * 
     * @param nextCell the next cell to be set
     */
    public void setNextCell(Cell nextCell) {
        this.nextCell = nextCell;
    }

    /**
     * Sets the registration ID for the cell.
     *
     * @param regId the registration ID to set
     */
    public void setRegId(int regId) {
        this.regId = regId;
    }

    /**
     * Clears the value of the cell.
     */
    public void clear() {
        this.value = 0;
    }
}