/**
 * The CtrlBoard class represents a controller for a game board.
 */
package main.domain.controllers;

import main.domain.classes.Board;
import main.domain.classes.Pair;
import main.domain.classes.exceptions.ExceptionBoard;
import java.util.*;

public class CtrlBoard {
    private Board currentBoard = null;


    /**
     * Sets the current board to the specified board.
     * 
     * @param board the board to set as the current board
     */
    public void setCurrentBoard(Board board) {
        currentBoard = board;
    }

    /**
     * Returns the matrix of cell values in the current board.
     *
     * @return the matrix of cell values
     */
    public int[][] getCellValuesMatrix() {
        return currentBoard.getCellValuesMatrix();
    }

    /**
     * Retrieves the cell region IDs matrix for a given board.
     *
     * @param iboard the ID of the board
     * @return the cell region IDs matrix
     */
    public int[][] getCellRegIdsMatrix(Board board) {
        return board.getCellRegIdsMatrix();
    }

    /**
     * Retrieves the information about the regions in a board.
     *
     * @param iboard the identifier of the board
     * @return a list of pairs, where each pair contains the operation and result of a region
     */
    public List<Pair<Character, Integer>> getRegionsInfo(Board board) {
        int numRegions = board.getNumRegions();
        List<Pair<Character, Integer>> pairs = new ArrayList<>();
        for (int i = 0; i < numRegions; ++i) {
            char op = board.getRegionOp(i);
            int result = board.getRegionResult(i);
            pairs.add(new Pair<>(op, result));
        }
        return pairs;
    }
    
    /**
     * Solves the current board.
     */
    public void solveBoard() {
        currentBoard.solveBoard();
    }


    /**
     * Returns the ID of the current board.
     *
     * @return the ID of the current board
     */
    public int getCurrentBoardId() {
        return currentBoard.getId();
    }

    public Board getCurrentBoard() {
        return currentBoard;
    }

    /**
     * Checks if the specified board has a solution.
     *
     * @param iboard the index of the board to check
     * @return true if the board has a solution, false otherwise
     */
    public boolean hasSolution(Board board) {
        boolean solved = board.solveBoard();
        if (solved) {
            int size = board.getSize();
            for (int i = 0; i < size; ++i) {
                for (int j = 0; j < size; ++j) {
                    board.clearCellValue(i, j);
                }
            }
        }
        return solved;
    }

    /**
     * Generates a new game board with the specified size, predefined regions, and predefined operations.
     *
     * @param size              The size of the game board.
     * @param predefinedRegions A list of predefined regions for the game board.
     * @param predOps           A set of predefined operations for the game board.
     * @return The generated game board.
     * @throws ExceptionBoard if an error occurs while generating the game board.
     */
    public Board generateBoard(int size, List<Integer> predefinedRegions, HashSet<Integer> predOps) throws ExceptionBoard {

        Board board = new Board(1);
        board = board.generateBoard(size, predefinedRegions, predOps);
        return board;
    }

    /**
     * Checks if a given value satisfies the row-column rule in the current board.
     *
     * @param r the row index
     * @param c the column index
     * @param v the value to be checked
     * @return true if the value satisfies the row-column rule, false otherwise
     */
    public boolean checkRowColRule(int r, int c, int v) {
        return currentBoard.checkRowColRule(r,  c,  v);
    }

    /**
     * Checks if the specified row and column satisfy the operation rule.
     *
     * @param r the row index
     * @param c the column index
     * @return true if the operation rule is satisfied, false otherwise
     */
    public boolean checkOpRule(int r, int c) {
        return currentBoard.checkOpRule(r, c);
    }

}
