# Projecte KenKen - Domini - Controladors

Aquest directori conté les classes de control del domini del projecte KenKen. Aquestes classes s'encarreguen de gestionar la lògica de negoci i coordinar les operacions entre diferents parts del sistema. A continuació es descriu breument el propòsit de cada fitxer i les classes que conté.

## Fitxers i Classes

1. **CtrlDomini.java**
   - Classe de control que gestiona la lògica del domini del joc. S'encarrega de coordinar les operacions entre les diferents parts del sistema.

2. **CtrlBoard.java**
   - Classe de control que gestiona les operacions relacionades amb el tauler del joc. Inclou funcions per inicialitzar, modificar i validar el tauler.

3. **CtrlUser.java**
   - Classe de control que gestiona les operacions relacionades amb els usuaris del joc. Inclou funcions per crear, modificar i eliminar usuaris, així com gestionar les seves dades.

4. **CtrlGame.java**
   - Classe de control que gestiona les operacions generals del joc. Inclou funcions per iniciar, pausar, reprendre i finalitzar partides, així com per gestionar les estadístiques del joc.

