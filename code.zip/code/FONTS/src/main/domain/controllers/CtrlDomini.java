/**
 * The `CtrlDomini` class is responsible for controlling the domain logic of the application.
 * It manages the interaction between the user interface and the underlying data and business logic.
 * This class provides methods for managing boards, games, users, and rankings.
 */
package main.domain.controllers;

import main.domain.classes.*;
import main.domain.classes.exceptions.*;
import main.persistence.controllers.CtrlPersistencia;
import java.util.*;

public class CtrlDomini {

    private CtrlPersistencia ctrlPersistencia;
    private CtrlBoard ctrlBoard;
    private CtrlGame ctrlGame;
    private CtrlUser ctrlUser;

    /**
     * Constructs a new instance of the CtrlDomini class.
     * Initializes the necessary controllers for the domain layer.
     */
    public CtrlDomini() {
        ctrlPersistencia = new CtrlPersistencia();
        ctrlBoard = new CtrlBoard();
        ctrlGame = new CtrlGame();
        ctrlUser = new CtrlUser();
    }

   

    /////////////////////////////////BOARD FUNCTIONS/////////////////////////////////////

    /**
     * Creates a new board based on the given board information and sets it as the current board.
     * Throws an ExceptionBoard if the board does not have a solution.
     *
     * @param boardInfo the list of integers representing the board information
     * @throws ExceptionBoard if the board does not have a solution
     */
    public void makeBoard (List<Integer> boardInfo) throws ExceptionBoard {
        Board board = new Board(1, -1);
        board = board.makeBoard(boardInfo, -1, -1);
        ctrlBoard.setCurrentBoard(board);
        if (!ctrlBoard.hasSolution(board)) {
            throw new ExceptionBoard("Board without solution");
        }
    }

    /**
     * Checks if the given board has a solution.
     *
     * @param board the board to check for a solution
     * @return true if the board has a solution, false otherwise
     */
    public boolean hasSolution(Board board) {
        return ctrlBoard.hasSolution(board);
    }

    //////////////////////////////////////////////////////////////////////////////////

    /////////////////////////////////GAME FUNCTIONS/////////////////////////////////////

    /**
     * Starts a new game on the specified board for the current user.
     * This method delegates the start game operation to the `ctrlGame` object.
     *
     * @param iboard the index of the board to start the game on
     */
    public void startGame(int boardId) throws ExceptionGame, ExceptionUser, ExceptionBoard {

        User user = ctrlUser.getCurrentUser();
        String username = user.getUsername();
        if (ctrlPersistencia.userHaveSolvedBoard(username, boardId)) {
            throw new ExceptionGame("This board is alredy solved");
        }
       
        else {
            Game game = ctrlPersistencia.getSavedGame(user, boardId);
            if (game != null) {  
                ctrlBoard.setCurrentBoard(game.getBoard());
                ctrlGame.continueGame(game);
            }
            else {
                Board board = ctrlPersistencia.getBoard(boardId);
                ctrlBoard.setCurrentBoard(board);
                ctrlGame.startGame(board, user);
            }
        }
    }

    /**
     * Starts a custom game using the current user and board.
     */
    public void startCustomGame() {
        User user = ctrlUser.getCurrentUser();
        Board board =  ctrlBoard.getCurrentBoard();
        ctrlGame.startGame(board, user);
    }

    /**
     * Makes a move in the game.
     * This method delegates the move operation to the `ctrlGame` object.
     *
     * @param r The row index of the move.
     * @param c The column index of the move.
     * @param v The value of the move.
     * @return The result of the move.
     */
    public void makeMove(int r, int c, int v) throws ExceptionGame{
        ctrlGame.makeMove(r, c, v);
    }

    /**
     * Solves the board by calling the solveBoard method of the CtrlBoard instance.
     */
    public void solveBoard() {
        ctrlBoard.solveBoard();
    }
    
    /**
     * Stops the current game being played.
     * This method delegates the stop playing operation to the `ctrlGame` object.
     */
    public void stopPlaying() {
        String username = ctrlUser.getCurrentUser().getUsername();
        Game game = ctrlGame.getCurrentGame();
        int boardId = ctrlBoard.getCurrentBoardId();
        
        ctrlGame.stopPlaying();
        if (boardId != -1) {
            ctrlPersistencia.addGameToUser(username, game);
        }
    }

    /**
     * Checks if the current solution is correct.
     *
     * @return true if the solution is correct, false otherwise.
     */
    public boolean checkSolution() {
        return ctrlGame.checkSolution();
    }

    /**
     * Finishes the current game and performs necessary operations such as removing the game from the user,
     * adding the solved board to the user's records, and updating the user's statistics.
     *
     * @throws ExceptionUser if there is an error while finishing the game.
     */
    public void finishGame() throws ExceptionUser {
        ctrlGame.finishGame();
        int boardId = ctrlBoard.getCurrentBoardId();
        User user = ctrlUser.getCurrentUser();
        String username = user.getUsername(); 
        ctrlPersistencia.removeGameFromUser(username, boardId);
        if (boardId != -1) {
            ctrlPersistencia.addSolvedBoard(username, boardId);
            ctrlPersistencia.updateUserStats(username, user.getStats());
        }
    }

    /**
     * Returns a hint for the current game.
     * This method delegates the hint operation to the `ctrlGame` object.
     *
     * @return true if a hint is available, false otherwise
     */
    public Pair<Integer, Integer> getHint() {
        return ctrlGame.getHint();
    }

    /**
     * Checks if the current user has solved the specified board.
     *
     * @param boardId the ID of the board to check
     * @return true if the current user has solved the board, false otherwise
     * @throws ExceptionUser if there is an error retrieving the current username
     */
    public boolean isFinished(int boardId) throws ExceptionUser {
        return ctrlPersistencia.userHaveSolvedBoard(getCurrentUsername(), boardId);
    }

    /**
     * Checks if the game has started.
     *
     * @return true if the game has started, false otherwise.
     */
    public boolean isStarted() {
        return ctrlGame.isStarted();
    }

    /**
     * Retrieves a saved game with the specified board ID.
     *
     * @param boardId The ID of the board associated with the saved game.
     * @return The saved game object.
     * @throws ExceptionUser If there is an error retrieving the current user.
     * @throws ExceptionBoard If there is an error retrieving the saved game with the specified board ID.
     */
    public Game getSavedGame(int boardId) throws ExceptionUser, ExceptionBoard {
        return ctrlPersistencia.getSavedGame(ctrlUser.getCurrentUser(), boardId);
    }
    ////////////////////////////////////////////////////////////////////////////////////

    /////////////////////////////////USER FUNCTIONS/////////////////////////////////////
    /**
     * Creates a new user with the specified username and password.
     * This method delegates the registration operation to the `ctrlUser` object.
     *
     * @param username The username of the user.
     * @param password The password of the user.
     * @param password2 The confirmation of the password.
     * @throws ExceptionUser 
     */
    public void createUser(String username, String password, String password2) throws ExceptionUser {
        if (username == null || username.isEmpty()) {
            throw new ExceptionUser("Username cannot be empty");
        }

        if (password == null || password.isEmpty()) {
            throw new ExceptionUser("Password cannot be empty");
        }

        if (password2 == null || password2.isEmpty()) {
            throw new ExceptionUser("Password confirmation cannot be empty");
        }

        if (ctrlPersistencia.existsUser(username)) {
            throw new ExceptionUser("Username already exists");
        }

        if (!password.equals(password2)) {
            throw new ExceptionUser("Passwords do not match");
        }

        User currentUser = this.ctrlUser.createUser(username, password, password2);
        ctrlPersistencia.addUser(currentUser);
    }

    /**
     * Logs in the user with the specified username and password.
     * This method delegates the login operation to the `ctrlUser` object.
     *
     * @param username The username of the user.
     * @param password The password of the user.
     * @throws ExceptionUser 
     */
    public void login(String username, String password) throws ExceptionUser {
        if (username == null || username.isEmpty()) {
            throw new ExceptionUser("Username cannot be empty");
        }

        if (password == null || password.isEmpty()) {
            throw new ExceptionUser("Password cannot be empty");
        }

        if (!ctrlPersistencia.existsUser(username)) {
            throw new ExceptionUser("User does not exist");
        }
        if (!ctrlPersistencia.getUser(username).getPassword().equals(password)) {
            throw new ExceptionUser("Incorrect password");
        }
        this.ctrlUser.login(username, password, ctrlPersistencia.getUser(username));
    }
    

    /**
     * Changes the password of the user.
     * This method delegates the change password operation to the `ctrlUser` object.
     * 
     * @param password     the current password of the user
     * @param newPassword  the new password to set
     * @param newPassword2 the confirmation of the new password
     * @throws ExceptionUser 
     */
    public void changePassword(String password, String newPassword, String newPassword2) throws ExceptionUser {
        if (password == null || password.isEmpty()) {
            throw new ExceptionUser("Password cannot be empty");
        }

        if (newPassword == null || newPassword.isEmpty()) {
            throw new ExceptionUser("New password cannot be empty");
        }

        if (newPassword.equals(password)) {
            throw new ExceptionUser("New password cannot be the same as the current password");
        }

        if (newPassword2 == null || newPassword2.isEmpty()) {
            throw new ExceptionUser("New password confirmation cannot be empty");
        }

        if (!newPassword.equals(newPassword2)) {
            throw new ExceptionUser("New passwords do not match");
        }
        if(this.ctrlUser.changePassword(password, newPassword, newPassword2)) {
            ctrlPersistencia.changePassword(ctrlUser.getCurrentUser().getUsername(), newPassword);
        }
    }

    /**
     * Logs out the current user.
     * This method delegates the logout operation to the `ctrlUser` object.
     * @throws ExceptionUser 
     */
    public void logout() throws ExceptionUser {
        String username = ctrlUser.getCurrentUser().getUsername();        
        ctrlPersistencia.updateUserStats(username, ctrlUser.getCurrentUser().getStats());
        ctrlUser.logout();
    }

    /**
     * Deletes a user from the system.
     * This method delegates the delete user operation to the `ctrlUser` object.
     * 
     * @param username the username of the user to be deleted
     * @throws ExceptionUser 
     */
    public void deleteUser(String password) throws ExceptionUser {
        if (password == null || password.isEmpty()) {
            throw new ExceptionUser("Password cannot be empty");
        }
        this.ctrlPersistencia.deleteUser(this.ctrlUser.deleteUser(password, null));        
    }
    /////////////////////////////////////////////////////////////////////////////////////////

    //////////////////////////////RANKING FUNCTIONS/////////////////////////////////////////
    /**
     * Orders the ranking by points.
     * This method delegates the order ranking by points operation to the `ctrlRanking` object.
     * @throws ExceptionRankingEmpty 
     */
    public List<Pair<String, Integer>> orderRankingByPoints() throws ExceptionUser {
        return ctrlPersistencia.orderRankingByPoints();
    }

    /**
     * Orders the ranking by name.
     * This method delegates the order ranking by name operation to the `ctrlRanking` object.
     * @throws ExceptionRankingEmpty 
     */

    public List<Pair<String, Integer>> orderRankingByUsername() throws ExceptionUser {
        return ctrlPersistencia.orderRankingByUsername();
    }

    /**
     * Orders the ranking list by time for a given KenKen size and difficulty.
     * This method delegates the order ranking by time operation to the `ctrlRanking` object.
     *
     * @param kenkenSize the size of the KenKen puzzle
     * @param difficulty the difficulty level of the KenKen puzzle
     * @throws ExceptionRankingEmpty 
     */
    public List<Pair<String, Long>> orderRankingByTime(int kenkenSize, int difficulty) throws ExceptionUser { //ordena la llista pel temps 
        return ctrlPersistencia.orderRankingByTime(kenkenSize, difficulty);
    }

    /**
     * Orders the ranking list by difficulty.
     * This method delegates the order ranking by difficulty operation to the `ctrlRanking` object.
     * @throws ExceptionRankingEmpty 
     */
    public List<Pair<String, Integer>> orderRankingByDifficulty(int kenkenDifficulty) throws ExceptionUser { //ordena la llista per dificultat??
        return ctrlPersistencia.orderRankingByDifficulty(kenkenDifficulty);
    }

    /**
     * Orders the ranking list by the number of solved Kenkens for a given Kenken size.
     * This method delegates the order ranking by number of solved operation to the `ctrlRanking` object.
     * 
     * @param kenkenSize the size of the Kenken puzzles
     * @throws ExceptionRankingEmpty 
     */
    public List<Pair<String, Integer>> orderRankingByNumberOfSolved(int kenkenSize) throws ExceptionUser { 
        return ctrlPersistencia.orderRankingByNumberOfSolved(kenkenSize);
    }
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    /**
     * Updates the statistics of the current user.
     *
     * @throws ExceptionUser if there is an error updating the user statistics.
     */
    public void updateUserStats() throws ExceptionUser {
        User cu = ctrlUser.getCurrentUser();
        Stats s = cu.getStats();
        String username = cu.getUsername();
        ctrlPersistencia.updateUserStats(username, s);
    }

    /**
     * Generates a new board with the specified size, predefined regions, and predefined operations.
     *
     * @param size              The size of the board.
     * @param predefinedRegions The list of predefined regions.
     * @param predOps           The set of predefined operations.
     * @return The generated board.
     * @throws ExceptionBoard if the generated board does not have a solution.
     */
    public Board generateBoard(int size, List<Integer> predefinedRegions, HashSet<Integer> predOps) throws ExceptionBoard {

        Board board = ctrlBoard.generateBoard(size, predefinedRegions, predOps);
        ctrlBoard.setCurrentBoard(board);
        if (!ctrlBoard.hasSolution(board)) {
            throw new ExceptionBoard("Board without solution");
        }
        return board;
    }

    /**
     * Retrieves the statistics of the current user.
     *
     * @return The statistics of the current user.
     * @throws ExceptionUser If there is an error retrieving the user or their statistics.
     */
    public Stats getStats() throws ExceptionUser {
        return ctrlPersistencia.getUser(ctrlUser.getCurrentUser().getUsername()).getStats();
    }

    /**
     * Returns the current username.
     *
     * @return the current username as a String.
     */
    public String getCurrentUsername() {
        return ctrlUser.getCurrentUser().getUsername();
    }

    /**
     * Returns the number of boards.
     *
     * @return the number of boards
     * @throws ExceptionBoard if an error occurs while retrieving the number of boards
     */
    public int getNumBoards() throws ExceptionBoard {
        return ctrlPersistencia.getNumBoards();
    }

    /**
     * Returns the size of the board for a given index.
     *
     * @param i the index of the board
     * @return the size of the board
     * @throws ExceptionBoard if an error occurs while retrieving the board size
     */
    public int getBoardSize(int i) throws ExceptionBoard {
        return ctrlPersistencia.getBoardSize(i);
    }

    /**
     * Retrieves the difficulty of a board with the specified index.
     *
     * @param i The index of the board.
     * @return The difficulty of the board.
     * @throws ExceptionBoard If an error occurs while retrieving the board difficulty.
     */
    public int getBoardDifficulty(int i) throws ExceptionBoard {
        return ctrlPersistencia.getBoardDifficulty(i);
    }

    /**
     * Returns the current board.
     *
     * @return the current board.
     */
    public Board getCurrentBoard() {
        return ctrlBoard.getCurrentBoard();
    }

    /**
     * Checks if the given value satisfies the row-column rule at the specified position.
     *
     * @param r The row index.
     * @param c The column index.
     * @param v The value to be checked.
     * @return true if the value satisfies the row-column rule, false otherwise.
     */
    public boolean checkRowColRule(int r, int c, int v) {
        return ctrlBoard.checkRowColRule(r, c, v);
    }

    /**
     * Checks if the given row and column satisfy the operation rule.
     *
     * @param r The row index.
     * @param c The column index.
     * @return True if the operation rule is satisfied, false otherwise.
     */
    public boolean checkOpRule(int r, int c) {
        return ctrlBoard.checkOpRule(r, c);
    }

    /**
     * Returns the current time of the game.
     *
     * @return the current time of the game.
     */
    public double getTime() {
        return ctrlGame.getTime();
    }

}

