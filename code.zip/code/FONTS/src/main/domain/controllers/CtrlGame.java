/**
 * The `CtrlGame` class is responsible for controlling the game logic of the application.
 * It manages the current game and provides methods for starting and continuing games.
 */
package main.domain.controllers;

import main.domain.classes.Game;
import main.domain.classes.Pair;
import main.domain.classes.Board;
import main.domain.classes.User;
import main.domain.classes.exceptions.*;


public class CtrlGame {

    private Game currentGame;

    /**
     * Constructs a new CtrlGame object.
     * The current game is initially set to null.
     */
    public CtrlGame() {
        currentGame = null;
    }

    /**
     * Gets the current game.
     *
     * @return the current game.
     */
    public Game getCurrentGame() {
        return currentGame;
    }

    /**
     * Starts a new game with the given board and user.
     *
     * @param board The board for the game.
     * @param user The user playing the game.
     */
    public void startGame(Board board, User user) {
        currentGame = new Game(board, user);
        currentGame.startGame();
    }

    /**
     * Continues the game with the given game object.
     * 
     * @param game The game object to continue.
     */
    public void continueGame(Game game) {
        currentGame = game;
        currentGame.continueGame();
    }

    /**
     * Makes a move in the current game by setting the value of a cell at the specified row and column.
     *
     * @param r The row index of the cell.
     * @param c The column index of the cell.
     * @param v The value to be set in the cell.
     * @throws ExceptionGame if an error occurs while making the move.
     */
    public void makeMove(int r, int c, int v) throws ExceptionGame{
        currentGame.makeMove(r, c, v);
    }
    
    /**
     * Stops the current game being played.
     * This method calls the stopPlaying method of the current game and sets the currentGame variable to null.
     */
    public void stopPlaying() {

        currentGame.stopPlaying();
        currentGame = null;
    }

    /**
     * Returns a pair of integers representing a hint for the current game.
     *
     * @return a pair of integers representing a hint
     */
    public Pair<Integer, Integer> getHint() {
        return currentGame.getHint();
    }

    /**
     * Checks if the current game's solution is correct.
     *
     * @return true if the solution is correct, false otherwise.
     */
    public boolean checkSolution() {
        return currentGame.checkSolution();
    }

    /**
     * Finishes the current game.
     */
    public void finishGame() {
        currentGame.finish();
    }

    /**
     * Checks if the game has started.
     *
     * @return true if the game has started, false otherwise.
     */
    public boolean isStarted() {
        return currentGame.isStarted();
    }

    /**
     * Returns the current time of the game.
     *
     * @return the current time of the game
     */
    public double getTime() {
        return currentGame.getTime();
    }

}
