# Projecte KenKen - Main

Aquest directori conté les carpetes principals del projecte KenKen. A continuació es descriu breument el propòsit de cada subcarpeta.

## Subcarpetes

### domain
- Aquest directori conté les classes i controladors del domini del joc. Per a més detalls, consulteu el fitxer `index.txt` dins de la carpeta `domain`.

### persistence
- Aquest directori conté les classes i controladors de persistència del joc. Per a més detalls, consulteu el fitxer `index.txt` dins de la carpeta `persistence`.

### presentation
- Aquest directori conté les classes i controladors de presentació del joc. Per a més detalls, consulteu el fitxer `index.txt` dins de la carpeta `presentation`.


