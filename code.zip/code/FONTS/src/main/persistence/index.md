# Projecte KenKen - Persistència

Aquest directori conté les classes i controladors de persistència del projecte KenKen. Aquestes classes i controladors s'encarreguen de gestionar l'emmagatzematge i la recuperació de dades.

## Subcarpetes i Fitxers

### classes
- Aquest directori conté les classes que gestionen l'emmagatzematge i la recuperació de dades. Per a més detalls, consulteu el fitxer `index.txt` dins de la carpeta `classes`.

### controllers
- Aquest directori conté els controladors que gestionen les operacions de persistència. Per a més detalls, consulteu el fitxer `index.txt` dins de la carpeta `controllers`.


