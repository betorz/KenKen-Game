# Projecte KenKen - Persistència - Classes

Aquest directori conté les classes de persistència del projecte KenKen. Aquestes classes s'encarreguen de gestionar l'emmagatzematge i la recuperació de dades. A continuació es descriu breument el propòsit de cada fitxer i les classes que conté.

## Fitxers i Classes

1. **UsersManagement.java**
   - Classe per gestionar l'emmagatzematge i la recuperació de les dades dels usuaris. Inclou funcions per guardar, carregar i actualitzar la informació dels usuaris.

2. **RankingManagement.java**
   - Classe per gestionar l'emmagatzematge i la recuperació del rànquing del joc. Inclou funcions per guardar, carregar i actualitzar el rànquing dels jugadors.

3. **BoardsManagement.java**
   - Classe per gestionar l'emmagatzematge i la recuperació dels taulers del joc. Inclou funcions per guardar, carregar i actualitzar els diferents taulers de joc.
