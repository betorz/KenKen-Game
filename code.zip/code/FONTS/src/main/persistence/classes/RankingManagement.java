package main.persistence.classes;

import main.domain.classes.Pair;
import main.domain.classes.Stats;
import main.domain.classes.exceptions.ExceptionUser;

import org.json.JSONObject;
import org.json.JSONArray;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import org.json.JSONException;
import java.util.*;


/**
 * This class provides management functionalities for ranking users,
 * including ordering rankings by various criteria such as points, username,
 * time, difficulty, and number of solved KenKens.
 */
public class RankingManagement {

    private static final String FILE_PATH = "./../data/users.json";

    /**
     * Retrieves a list of user statistics from the JSON file.
     *
     * @return A list of pairs where each pair contains a username and the corresponding stats.
     * @throws ExceptionUser If there is an error with the users JSON file.
     */
    private List<Pair<String, Stats>> getUsersStats() throws ExceptionUser {
        List<Pair<String, Stats>> usersStats = new ArrayList<>();
        try {
              String content = new String(Files.readAllBytes(Paths.get(FILE_PATH)));
              JSONArray jsonUsers = new JSONArray(content);
  
              for (int i = 0; i < jsonUsers.length(); i++) {
                    JSONObject jsonUser = jsonUsers.getJSONObject(i);

                    String username = jsonUser.getString("username");
                    int points = jsonUser.getInt("points");
                    int solved = jsonUser.getInt("solved");
                    JSONArray jsonTimes = jsonUser.getJSONArray("times");
                    long[][] times = new long[jsonTimes.length()][];
                    for (int j = 0; j < jsonTimes.length(); j++) {
                        JSONArray jsonRow = jsonTimes.getJSONArray(j);
                        times[j] = new long[jsonRow.length()];
                        for (int k = 0; k < jsonRow.length(); k++) {
                            times[j][k] = jsonRow.getLong(k);
                        }
                    }
                    JSONArray jsonSolvedSize = jsonUser.getJSONArray("solvedSize");
                    int[] solvedSize = new int[jsonSolvedSize.length()];
                    for (int j = 0; j < jsonSolvedSize.length(); j++) {
                        solvedSize[j] = jsonSolvedSize.getInt(j);
                    }
                    JSONArray jsonSolvedDifficulty = jsonUser.getJSONArray("solvedDifficulty");
                    int[] solvedDifficulty = new int[jsonSolvedDifficulty.length()];
                    for (int j = 0; j < jsonSolvedDifficulty.length(); j++) {
                        solvedDifficulty[j] = jsonSolvedDifficulty.getInt(j);
                    }
                    Stats stats = new Stats(points, solved, times, solvedSize, solvedDifficulty);
                    usersStats.add(new Pair<>(username, stats));            
              }
          } catch (IOException | JSONException e) {
                throw new ExceptionUser("Error with users json");
            } 
          return usersStats;
    }

    /**
     * Orders the ranking by points.
     *
     * @return A list of pairs where each pair contains a username and the corresponding points, ordered by points.
     * @throws ExceptionUser If there is an error with the users JSON file.
     */
    public List<Pair<String, Integer>> orderRankingByPoints() throws ExceptionUser {
        List<Pair<String, Integer>> rankingList = new ArrayList<>();
        List<Pair<String, Stats>> usersStats = getUsersStats();
        for (Pair<String, Stats> pair : usersStats) {
            String username = pair.getX();
            Stats stats = pair.getY();
            int points = stats.getPoints();
            rankingList.add(new Pair<>(username, points));
        }

        rankingList.sort(new Comparator<Pair<String, Integer>>() {
            @Override
            public int compare(Pair<String, Integer> o1, Pair<String, Integer> o2) {
                return o2.getY().compareTo(o1.getY());
            }
        });

        return rankingList;
    }

    /**
     * Orders the ranking by username.
     *
     * @return A list of pairs where each pair contains a username and the corresponding points, ordered by username.
     * @throws ExceptionUser If there is an error with the users JSON file.
     */
    public List<Pair<String, Integer>> orderRankingByUsername() throws ExceptionUser {
        List<Pair<String, Integer>> rankingList = new ArrayList<>();
        List<Pair<String, Stats>> usersStats = getUsersStats();
        for (Pair<String, Stats> pair : usersStats) {
            String username = pair.getX();
            Stats stats = pair.getY();
            int points = stats.getPoints();
            rankingList.add(new Pair<>(username, points));
        }
    
        rankingList.sort(new Comparator<Pair<String, Integer>>() {
            @Override
            public int compare(Pair<String, Integer> o1, Pair<String, Integer> o2) {
                return o1.getX().toLowerCase().compareTo(o2.getX().toLowerCase());
            }
        });
    
        return rankingList;
    }

    /**
     * Orders the ranking by time for a specific KenKen size and difficulty.
     *
     * @param kenkenSize The size of the KenKen puzzle.
     * @param difficulty The difficulty of the KenKen puzzle.
     * @return A list of pairs where each pair contains a username and the corresponding time, ordered by time.
     * @throws ExceptionUser If there is an error with the users JSON file.
     */
    public List<Pair<String, Long>> orderRankingByTime(int kenkenSize, int difficulty) throws ExceptionUser {
        List<Pair<String, Long>> rankingList = new ArrayList<>();
        List<Pair<String, Stats>> usersStats = getUsersStats();
        for (Pair<String, Stats> pair : usersStats) {
            String username = pair.getX();
            Stats stats = pair.getY();
            long time = stats.getTimes(kenkenSize, difficulty);
            rankingList.add(new Pair<>(username, time));
        }
    
        rankingList.sort(new Comparator<Pair<String, Long>>() {
            @Override
            public int compare(Pair<String, Long> o1, Pair<String, Long> o2) {
                return Long.compare(o1.getY(), o2.getY());
            }
        });
    
        return rankingList;
    }

    /**
     * Orders the ranking by the number of KenKen solved of a specific difficulty.
     *
     * @param kenkenDifficulty The difficulty of the KenKen puzzles.
     * @return A list of pairs where each pair contains a username and the corresponding number of solved KenKen of the specified difficulty, ordered by number of solved KenKens.
     * @throws ExceptionUser If there is an error with the users JSON file.
     */
    public List<Pair<String, Integer>> orderRankingByDifficulty(int kenkenDifficulty) throws ExceptionUser {
        List<Pair<String, Integer>> rankingList = new ArrayList<>();
        List<Pair<String, Stats>> usersStats = getUsersStats();
        for (Pair<String, Stats> pair : usersStats) {
            String username = pair.getX();
            Stats stats = pair.getY();
            int solvedDifficulty = stats.getSolvedDifficulty(kenkenDifficulty);
            rankingList.add(new Pair<>(username, solvedDifficulty));
        }
    
        rankingList.sort(new Comparator<Pair<String, Integer>>() {
            @Override
            public int compare(Pair<String, Integer> o1, Pair<String, Integer> o2) {
                return Integer.compare(o2.getY(), o1.getY());
            }
        });
    
        return rankingList;
    }

    /**
     * Orders the ranking by the number of puzzles solved of a specific size.
     *
     * @param kenkenSize The size of the KenKen puzzles.
     * @return A list of pairs where each pair contains a username and the corresponding number of solved KenKens of the specified size, ordered by number of solved KenKen.
     * @throws ExceptionUser If there is an error with the users JSON file.
     */    
    public List<Pair<String, Integer>> orderRankingByNumberOfSolved(int kenkenSize) throws ExceptionUser {
        List<Pair<String, Integer>> rankingList = new ArrayList<>();
        List<Pair<String, Stats>> usersStats = getUsersStats();
        for (Pair<String, Stats> pair : usersStats) {
            String username = pair.getX();
            Stats stats = pair.getY();
            int solvedSize = stats.getSolvedSize(kenkenSize);
            rankingList.add(new Pair<>(username, solvedSize));
        }
    
        rankingList.sort(new Comparator<Pair<String, Integer>>() {
            @Override
            public int compare(Pair<String, Integer> o1, Pair<String, Integer> o2) {
                return Integer.compare(o2.getY(), o1.getY());
            }
        });
    
        return rankingList;
    }
    

}
