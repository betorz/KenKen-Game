package main.persistence.classes;

import main.domain.classes.User;
import main.domain.classes.Stats;
import main.domain.classes.Game;
import main.domain.classes.Board;
import main.domain.classes.exceptions.ExceptionUser;
import main.domain.classes.exceptions.ExceptionBoard;
import org.json.JSONObject;
import org.json.JSONArray;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

import org.json.JSONException;
import java.util.*;

/**
 * This class manages the operations related to users in the persistence layer, including 
 * adding, removing, updating users and their games, and retrieving user information.
 */
public class UsersManagement {

    private static final String FILE_PATH = "./../data/users.json";

    /**
     * Adds a game to the specified user.
     * 
     * @param username the username of the user
     * @param game the game to add
     * @throws ExceptionUser if there is an error with the users JSON file
     */
    public void addGameToUser(String username, Game game) throws ExceptionUser {
        File file = new File(FILE_PATH);
        if (file.exists() && file.length() > 0) {
            try {
                String content = new String(Files.readAllBytes(Paths.get(FILE_PATH)));
                JSONArray jsonUsers = new JSONArray(content);
                for (int i = 0; i < jsonUsers.length(); i++) {
                    JSONObject jsonUser = jsonUsers.getJSONObject(i);
                    if (jsonUser.getString("username").equals(username)) {
                        JSONArray jsonGames = jsonUser.optJSONArray("games");
                        if (jsonGames == null) {
                            jsonGames = new JSONArray();
                        }
                        Board board = game.getBoard();
                        int idBoard = board.getId();
                        boolean gameFound = false;
                        for (int j = 0; j < jsonGames.length(); j++) {
                            JSONObject jsonGame = jsonGames.getJSONObject(j);
                            if(jsonGame.getInt("idBoard") == idBoard) {
                                jsonGame.put("time", game.getTime());
                                jsonGame.put("Hints Used", game.getHintsUsed());
                                JSONArray jsonValues = new JSONArray();
                                int [][] values = board.getCellValuesMatrix();
                                for (int[] row : values) {
                                    for (int value : row) {
                                        jsonValues.put(value);
                                    }
                                }
                                jsonGame.put("board values", jsonValues);
                                gameFound = true;
                                break;
                            }
                        }
                        if (!gameFound) {
                            JSONObject jsonGame = new JSONObject();
                            jsonGame.put("idBoard", idBoard);
                            jsonGame.put("time", game.getTime());
                            jsonGame.put("Hints Used", game.getHintsUsed());
                            JSONArray jsonValues = new JSONArray();
                            int [][] values = board.getCellValuesMatrix();
                            for (int[] row : values) {
                                for (int value : row) {
                                    jsonValues.put(value);
                                }
                            }
                            jsonGame.put("board values", jsonValues);
                            jsonGames.put(jsonGame);
                        }
                        jsonUser.put("games", jsonGames);
                        try (FileWriter fileWriter = new FileWriter(FILE_PATH)) {
                            fileWriter.write(jsonUsers.toString(4));
                        }
                        break;
                    }
                      
                }

            } catch (IOException | JSONException e) {
                throw new ExceptionUser("Error with users json");
            } 
        }
    }

    /**
     * Removes a game from the specified user.
     * 
     * @param username the username of the user
     * @param boardId the ID of the board associated with the game to remove
     * @throws ExceptionUser if there is an error with the users JSON file
     */
    public void removeGameFromUser(String username, int boardId) throws ExceptionUser {
        File file = new File(FILE_PATH);
        if (file.exists() && file.length() > 0) {
            try {
                String content = new String(Files.readAllBytes(Paths.get(FILE_PATH)));
                JSONArray jsonUsers = new JSONArray(content);
                for (int i = 0; i < jsonUsers.length(); i++) {
                    JSONObject jsonUser = jsonUsers.getJSONObject(i);
                    if (jsonUser.getString("username").equals(username)) {
                        JSONArray jsonGames = jsonUser.optJSONArray("games");
                        if (jsonGames != null) {
                            for (int j = 0; j < jsonGames.length(); j++) {
                                JSONObject jsonGame = jsonGames.getJSONObject(j);
                                if (jsonGame.getInt("idBoard") == boardId) {
                                    jsonGames.remove(j);
                                    break;
                                }
                            }
                            jsonUser.put("games", jsonGames);
                            try (FileWriter fileWriter = new FileWriter(FILE_PATH)) {
                            fileWriter.write(jsonUsers.toString(4));
                            }
                        }
                    }     
                }

            } catch (IOException | JSONException e) {
                throw new ExceptionUser("Error with users json");
            } 
        }
    }

    /**
     * Adds a new user.
     * 
     * @param user the user to add
     * @throws ExceptionUser if there is an error with the users JSON file
     */
    public void addUser(User user) throws ExceptionUser {
        File file = new File(FILE_PATH);
        JSONArray jsonUsers = new JSONArray();

        if (file.exists() && file.length() > 0) {
            try {
                String content = new String(Files.readAllBytes(Paths.get(FILE_PATH)));
                jsonUsers = new JSONArray(content);
            } catch (IOException | JSONException e) {
                jsonUsers = new JSONArray();
            } 
        }

        JSONObject jsonUser = new JSONObject();
        jsonUser.put("username", user.getUsername());
        jsonUser.put("password", user.getPassword());
        Stats stats = user.getStats();
        jsonUser.put("points", stats.getPoints());
        jsonUser.put("solved", stats.getSolved());
        long[][] times = stats.getTimes();
        JSONArray jsonTimes = new JSONArray();
        for (long[] row : times) {
            JSONArray jsonRow = new JSONArray();
            for (long time : row) {
                jsonRow.put(time);
            }
            jsonTimes.put(jsonRow);
        }
        jsonUser.put("times", jsonTimes);
        int[] solvedSize = stats.getSolvedSize();
        JSONArray jsonSolvedSize = new JSONArray();
        for (int sz : solvedSize) {
            jsonSolvedSize.put(sz);
        }
        jsonUser.put("solvedSize", jsonSolvedSize);
        int[] solvedDifficulty = stats.getSolvedDifficulty();
        JSONArray jsonSolvedDifficulty = new JSONArray();
        for (int sd : solvedDifficulty) {
            jsonSolvedDifficulty.put(sd);
        }
        jsonUser.put("solvedDifficulty", jsonSolvedDifficulty);

        jsonUsers.put(jsonUser);

        try (FileWriter fileWriter = new FileWriter(FILE_PATH)) {
            fileWriter.write(jsonUsers.toString(7));
        } catch (IOException e) {
            throw new ExceptionUser("Error with users json");
        } 
    }

    /**
     * Retrieves a user by username.
     * 
     * @param username the username of the user to retrieve
     * @return the user if found, otherwise null
     * @throws ExceptionUser if there is an error with the users JSON file
     */
    public User getUser(String username) throws ExceptionUser {
      try {
            String content = new String(Files.readAllBytes(Paths.get(FILE_PATH)));
            JSONArray jsonUsers = new JSONArray(content);

            for (int i = 0; i < jsonUsers.length(); i++) {
                JSONObject jsonUser = jsonUsers.getJSONObject(i);
                if (jsonUser.getString("username").equals(username)) {
                    String password = jsonUser.getString("password");

                    // Leer estadísticas
                    int points = jsonUser.getInt("points");
                    int solved = jsonUser.getInt("solved");
                    JSONArray jsonTimes = jsonUser.getJSONArray("times");
                    long[][] times = new long[jsonTimes.length()][];
                    for (int j = 0; j < jsonTimes.length(); j++) {
                        JSONArray jsonRow = jsonTimes.getJSONArray(j);
                        times[j] = new long[jsonRow.length()];
                        for (int k = 0; k < jsonRow.length(); k++) {
                            times[j][k] = jsonRow.getLong(k);
                        }
                    }
                    JSONArray jsonSolvedSize = jsonUser.getJSONArray("solvedSize");
                    int[] solvedSize = new int[jsonSolvedSize.length()];
                    for (int j = 0; j < jsonSolvedSize.length(); j++) {
                        solvedSize[j] = jsonSolvedSize.getInt(j);
                    }
                    JSONArray jsonSolvedDifficulty = jsonUser.getJSONArray("solvedDifficulty");
                    int[] solvedDifficulty = new int[jsonSolvedDifficulty.length()];
                    for (int j = 0; j < jsonSolvedDifficulty.length(); j++) {
                        solvedDifficulty[j] = jsonSolvedDifficulty.getInt(j);
                    }
                    Stats stats = new Stats(points, solved, times, solvedSize, solvedDifficulty);

                    User user = new User(username, password, stats);
                    return user;
                }
            }
        } catch (IOException | JSONException e) {
            throw new ExceptionUser("Error with users json");
        }
        return null;
    }

    /**
     * Checks if a user exists by username.
     * 
     * @param username the username to check
     * @return true if the user exists, otherwise false
     * @throws ExceptionUser if there is an error with the users JSON file
     */
    public boolean existsUser(String username) throws ExceptionUser {
        File file = new File(FILE_PATH);
        if (!file.exists() || file.length() == 0) {
            return false;
        }
        try {
            String content = new String(Files.readAllBytes(Paths.get(FILE_PATH)));
            JSONArray jsonUsers = new JSONArray(content);

            for (int i = 0; i < jsonUsers.length(); i++) {
                JSONObject jsonUser = jsonUsers.getJSONObject(i);
                if (jsonUser.getString("username").equals(username)) {
                    return true;
                }
            }
        } catch (IOException e) {
            throw new ExceptionUser("Error with users json");
        } 
        return false;
    }


    /**
     * Deletes a user by username.
     * 
     * @param username the username of the user to delete
     * @throws ExceptionUser if there is an error with the users JSON file
     */
    public void deleteUser(String username) throws ExceptionUser {
      try {
         String content = new String(Files.readAllBytes(Paths.get(FILE_PATH)));
         JSONArray jsonUsers = new JSONArray(content);
  
         for (int i = 0; i < jsonUsers.length(); i++) {
             JSONObject jsonUser = jsonUsers.getJSONObject(i);
             if (jsonUser.getString("username").equals(username)) {
                 jsonUsers.remove(i);
                 break;
             }
          }
  
          try (FileWriter fileWriter = new FileWriter(FILE_PATH)) {
              fileWriter.write(jsonUsers.toString(7));
          } catch (IOException e) {
            throw new ExceptionUser("Error with users json");
        } 
      } catch (IOException e) {
        throw new ExceptionUser("Error with users json");
    } 
    }

    /**
     * Updates the statistics of a user.
     * 
     * @param username the username of the user
     * @param stats the new statistics to update
     * @throws ExceptionUser if there is an error with the users JSON file
     */
    public void updateUserStats(String username, Stats stats) throws ExceptionUser {
        try {
            // Llegir users.json
            String content = new String(Files.readAllBytes(Paths.get(FILE_PATH)));
            JSONArray jsonUsers = new JSONArray(content);

            // Buscar user
            for (int i = 0; i < jsonUsers.length(); i++) {
                JSONObject jsonUser = jsonUsers.getJSONObject(i);
                if (jsonUser.getString("username").equals(username)) {
                
                    jsonUser.put("points", stats.getPoints());
                    jsonUser.put("solvedPerc", stats.getSolvedPerc());
                    jsonUser.put("solved", stats.getSolved());
                    jsonUser.put("times", new JSONArray(stats.getTimes()));
                    jsonUser.put("solvedSize", new JSONArray(stats.getSolvedSize()));
                    jsonUser.put("solvedDifficulty", new JSONArray(stats.getSolvedDifficulty()));

                    Files.write(Paths.get(FILE_PATH), jsonUsers.toString(7).getBytes());
                    return;
                }
            }
        } catch (IOException e) {
            throw new ExceptionUser("Error with users json");
        } 
    }

    /**
     * Adds a solved board to the specified user.
     * 
     * @param username the username of the user
     * @param boardId the ID of the board that was solved
     * @throws ExceptionUser if there is an error with the users JSON file
     */
    public void addSolvedBoard(String username, int boardId) throws ExceptionUser {
        try {
            String content = new String(Files.readAllBytes(Paths.get(FILE_PATH)));
            JSONArray jsonUsers = new JSONArray(content);
    
            for (int i = 0; i < jsonUsers.length(); i++) {
                JSONObject jsonUser = jsonUsers.getJSONObject(i);
                if (jsonUser.getString("username").equals(username)) {
                    JSONArray jsonSolvedBoards = jsonUser.optJSONArray("solvedBoards");
                    if (jsonSolvedBoards == null) {
                        jsonSolvedBoards = new JSONArray();
                        jsonUser.put("solvedBoards", jsonSolvedBoards);
                    }
                    jsonSolvedBoards.put(boardId);
                    try (FileWriter fileWriter = new FileWriter(FILE_PATH)) {
                        fileWriter.write(jsonUsers.toString(4));
                    }
                }
            }
        } catch (IOException e) {
            throw new ExceptionUser("Error with users json");
        } 
    }

    /**
     * Checks if a user has solved a specific board.
     * 
     * @param username the username of the user
     * @param boardId the ID of the board to check
     * @return true if the user has solved the board, otherwise false
     * @throws ExceptionUser if there is an error with the users JSON file
     */
    public boolean userHaveSolvedBoard(String username, int boardId) throws ExceptionUser {
        try {
            String content = new String(Files.readAllBytes(Paths.get(FILE_PATH)));
            JSONArray jsonUsers = new JSONArray(content);
            for (int i = 0; i < jsonUsers.length(); i++) {
                JSONObject jsonUser = jsonUsers.getJSONObject(i);
                if (jsonUser.getString("username").equals(username)) {
                    JSONArray jsonSolvedBoards = jsonUser.optJSONArray("solvedBoards");
                    if (jsonSolvedBoards != null) {
                        for (int j = 0; j < jsonSolvedBoards.length(); j++) {
                            if (jsonSolvedBoards.getInt(j) == boardId) {
                                return true;
                            }
                        }
                    }
                    break;
                }
            }
        } catch (IOException e) {
            throw new ExceptionUser("Error with users json");
        } 
        return false;
    }

    /**
     * Retrieves a saved game for the specified user and board.
     * 
     * @param user the user to retrieve the game for
     * @param boardId the ID of the board associated with the game
     * @return the saved game if found, otherwise null
     * @throws ExceptionUser if there is an error with the users JSON file
     * @throws ExceptionBoard if there is an error with the board
     */
    public Game getSavedGame(User user, Integer boardId) throws ExceptionUser, ExceptionBoard {
        
        String username = user.getUsername();
        
        try {
            String content = new String(Files.readAllBytes(Paths.get(FILE_PATH)));
            JSONArray jsonUsers = new JSONArray(content);
            for (int i = 0; i < jsonUsers.length(); i++) {
                JSONObject jsonUser = jsonUsers.getJSONObject(i);
                if (jsonUser.getString("username").equals(username)) {
                    JSONArray jsonGames = jsonUser.optJSONArray("games");
                    if (jsonGames != null) {
                        for (int j = 0; j < jsonGames.length(); j++) {
                            JSONObject jsonGame = jsonGames.getJSONObject(j);
                            if (jsonGame.getInt("idBoard") == boardId) {
                                BoardsManagement cbs = new BoardsManagement();
                                Board board = cbs.getBoard(boardId);
                                long time = jsonGame.getLong("time");
                                int hintsUsed = jsonGame.getInt("Hints Used");
                                JSONArray jsonValues = jsonGame.getJSONArray("board values");
                                List<Integer> arrayValues = jsonArrayToList(jsonValues);
                                int size = board.getSize();
                                for (int x = 0; x < size; ++x) {
                                    for (int y = 0; y < size; ++y) {
                                        int value = arrayValues.get(x*size + y);
                                        if (value != 0) {
                                            board.modifyCellValue(value, x, y);
                                        }
                                    }
                                }
                                Game game = new Game(board, user, time, hintsUsed);
                                return game;
                            }
                        }
                    }
                    return null;
                }
            }
            return null;
        } catch (IOException e) {
            throw new ExceptionUser("Error with users json");
        } 
    }
    /**
     * Converts a JSONArray to a List of Integers.
     * 
     * @param jsonArray the JSONArray to convert
     * @return a List of Integers
     * @throws ExceptionUser if there is an error during conversion
     */
    private List<Integer> jsonArrayToList(JSONArray jsonArray) throws ExceptionUser {
        List<Integer> list = new ArrayList<>();
        for (int i = 0; i < jsonArray.length(); i++) {
            list.add(jsonArray.getInt(i));
        }
        return list;
    }
    /**
     * Changes the password for the specified user.
     * 
     * @param user the username of the user
     * @param password the new password
     * @throws ExceptionUser if there is an error with the users JSON file
     */
    public void changePassword(String user, String password) throws ExceptionUser {
        File file = new File(FILE_PATH);
        if (file.exists() && file.length() > 0) {
            try {
                String content = new String(Files.readAllBytes(Paths.get(FILE_PATH)));
                JSONArray jsonUsers = new JSONArray(content);
                for (int i = 0; i < jsonUsers.length(); i++) {
                    JSONObject jsonUser = jsonUsers.getJSONObject(i);
                    if (jsonUser.getString("username").equals(user)) {
                        jsonUser.put("password", password);
                        try (FileWriter fileWriter = new FileWriter(FILE_PATH)) {
                            fileWriter.write(jsonUsers.toString(4));
                        }
                        return;
                    }
                }     
            } catch (IOException | JSONException e) {
                throw new ExceptionUser("Error with users json");
            } 
        }
    }
}
