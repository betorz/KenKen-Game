package main.persistence.classes;

import main.domain.classes.Board;
import main.domain.classes.exceptions.ExceptionBoard;
import org.json.JSONObject;
import org.json.JSONArray;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

import org.json.JSONException;
import java.util.*;

/**
 * This class provides management functionalities for boards,
 * including adding, retrieving, and getting information about boards.
 */
public class BoardsManagement {
    
    private static final String FILE_PATH = "./../data/boards.json";

        /**
     * Adds a new board with the provided information.
     *
     * @param boardInfo A list containing the information of the board.
     * @throws ExceptionBoard If there is an error with the boards JSON file.
     */
    public void addBoard(List<Integer> boardInfo) throws ExceptionBoard {
        File file = new File(FILE_PATH);
        JSONArray jsonArray = new JSONArray();
        try {
            String content = new String(Files.readAllBytes(Paths.get(FILE_PATH)));
            jsonArray = new JSONArray(content);
        } catch (IOException | JSONException e) {
            throw new ExceptionBoard("Error with boards json");
        } 

        JSONArray jsonBoardInfo = new JSONArray(boardInfo);
        JSONObject jsonBoard = new JSONObject();

        jsonBoard.put("board info", jsonBoardInfo);
        jsonArray.put(jsonBoard);

        try (FileWriter fileWriter = new FileWriter(file)) {
            fileWriter.write(jsonArray.toString(4));
        } catch (IOException e) {
            throw new ExceptionBoard("Error with boards json");
        }
    }

    /**
     * Retrieves a board based on the board ID.
     *
     * @param boardId The ID of the board to retrieve.
     * @return A Board object representing the board.
     * @throws ExceptionBoard If there is an error with the boards JSON file.
     */
    public Board getBoard(int boardId) throws ExceptionBoard {
        try {
            String content = new String(Files.readAllBytes(Paths.get(FILE_PATH)));
            JSONArray jsonBoards = new JSONArray(content);
            JSONObject jsonBoard = jsonBoards.getJSONObject(boardId);
            JSONArray jsonArray = jsonBoard.getJSONArray("board info");
            List<Integer> boardInfo = jsonArrayToList(jsonArray);
            int difficulty = jsonBoard.getInt("difficulty");
            Board board = new Board(1, boardId);
            return board.makeBoard(boardInfo, boardId, difficulty);
        } catch (IOException | JSONException e) {
            throw new ExceptionBoard("Error with boards json");
        }
    }

    /**
     * Converts a JSONArray to a List of Integers.
     *
     * @param jsonArray The JSONArray to convert.
     * @return A List of Integers.
     */  
    private List<Integer> jsonArrayToList(JSONArray jsonArray) {
        List<Integer> list = new ArrayList<>();
        for (int i = 0; i < jsonArray.length(); i++) {
            list.add(jsonArray.getInt(i));
        }
        return list;
    }

    /**
     * Gets the number of boards.
     *
     * @return The number of boards.
     * @throws ExceptionBoard If there is an error with the boards JSON file.
     */
    public int getNumBoards() throws ExceptionBoard {
        try {
            String content = new String(Files.readAllBytes(Paths.get(FILE_PATH)));
            JSONArray jsonBoards = new JSONArray(content);
            return jsonBoards.length();
        } catch (IOException | JSONException e) {
            throw new ExceptionBoard("Error with boards json");
        }
    }

        /**
     * Gets the size of the specified board.
     *
     * @param i The index of the board.
     * @return The size of the board.
     * @throws ExceptionBoard If there is an error with the boards JSON file.
     */
    public int getBoardSize(int i) throws ExceptionBoard {
        try {
            String content = new String(Files.readAllBytes(Paths.get(FILE_PATH)));
            JSONArray jsonBoards = new JSONArray(content);
            JSONObject jsonBoard = jsonBoards.getJSONObject(i);
            JSONArray jsonArray = jsonBoard.getJSONArray("board info");
            return jsonArray.getInt(0);
        } catch (IOException | JSONException e) {
            throw new ExceptionBoard("Error with boards json");
        }
    }

    /**
     * Gets the difficulty of the specified board.
     *
     * @param i The index of the board.
     * @return The difficulty of the board.
     * @throws ExceptionBoard If there is an error with the boards JSON file.
     */
    public int getBoardDifficulty(int i) throws ExceptionBoard {
        try {
            String content = new String(Files.readAllBytes(Paths.get(FILE_PATH)));
            JSONArray jsonBoards = new JSONArray(content);
            JSONObject jsonBoard = jsonBoards.getJSONObject(i);
            return jsonBoard.getInt("difficulty"); 
        } catch (IOException | JSONException e) {
            throw new ExceptionBoard("Error with boards json");
        }
    }
}