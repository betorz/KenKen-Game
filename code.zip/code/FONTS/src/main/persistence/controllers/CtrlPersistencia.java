package main.persistence.controllers;

import main.domain.classes.Board;
import main.domain.classes.User;
import main.domain.classes.Game;
import main.domain.classes.Pair;
import main.domain.classes.Stats;
import main.persistence.classes.*;
import main.domain.classes.exceptions.ExceptionBoard;
import main.domain.classes.exceptions.ExceptionUser;

import java.util.*;


/**
 * The `CtrlPersistencia` class is responsible for managing the persistence of boards and users.
 * It provides methods to add, remove, and retrieve boards, as well as add, retrieve, and delete users.
 */
public class CtrlPersistencia {

    private BoardsManagement boardsManagement;
    private UsersManagement usersManagement;
    private RankingManagement rankingManagement;
    /**
     * Constructs a new `CtrlPersistencia` instance and initializes the management classes.
     */
    public CtrlPersistencia() {
        boardsManagement = new BoardsManagement();
        usersManagement = new UsersManagement();
        rankingManagement = new RankingManagement();
    }


    /**
     * Adds a new board to the storage.
     *
     * @param boardInfo the information of the board to be added
     * @throws ExceptionBoard if there is an error adding the board
     */
    public void addBoard(List<Integer> boardInfo) throws ExceptionBoard {
        boardsManagement.addBoard(boardInfo);
    }
    /**
     * Retrieves the Board object at the specified index.
     *
     * @param i the index of the Board object to retrieve
     * @return the Board object at the specified index
     * @throws ExceptionBoard if there is an error retrieving the board
     */
    public Board getBoard(int i) throws ExceptionBoard {
        return boardsManagement.getBoard(i);
    }
    /**
     * Adds a user to the storage.
     *
     * @param user the user to be added
     * @throws ExceptionUser if there is an error adding the user
     */
    public void addUser(User user) throws ExceptionUser {
        usersManagement.addUser(user);
    }

    /**
     * Retrieves a user by their username.
     *
     * @param username the username of the user to retrieve
     * @return the User object corresponding to the given username, or null if no user is found
     * @throws ExceptionUser if there is an error retrieving the user
     */
    public User getUser(String username) throws ExceptionUser {
        return usersManagement.getUser(username);
    }

    /**
     * Checks if a user with the given username exists.
     *
     * @param username the username to check
     * @return true if the user exists, false otherwise
     * @throws ExceptionUser if there is an error checking the user's existence
     */
    public boolean existsUser(String username) throws ExceptionUser {
        return usersManagement.existsUser(username);
    }

    /**
     * Deletes a user with the specified username.
     *
     * @param username the username of the user to be deleted
     * @throws ExceptionUser if there is an error deleting the user
     */
    public void deleteUser(String username) throws ExceptionUser {
        usersManagement.deleteUser(username);
    }
    /**
     * Adds a game to the specified user.
     *
     * @param username the username of the user
     * @param game the game to add
     */
    public void addGameToUser(String username, Game game) {
        try {
            usersManagement.addGameToUser(username, game);
        } catch (ExceptionUser e) {
            System.out.println("Error");
        }
    }
    /**
     * Updates the statistics of a user.
     *
     * @param username the username of the user
     * @param stats the new statistics to update
     * @throws ExceptionUser if there is an error updating the user's statistics
     */
    public void updateUserStats(String username, Stats stats) throws ExceptionUser {
        usersManagement.updateUserStats(username, stats);
    }
    /**
     * Removes a game from the specified user.
     *
     * @param username the username of the user
     * @param boardId the ID of the board associated with the game to remove
     * @throws ExceptionUser if there is an error removing the game
     */
    public void removeGameFromUser(String username, int boardId) throws ExceptionUser {
        usersManagement.removeGameFromUser(username, boardId);
    }
    /**
     * Adds a solved board to the specified user.
     *
     * @param username the username of the user
     * @param boardId the ID of the board that was solved
     * @throws ExceptionUser if there is an error adding the solved board
     */
    public void addSolvedBoard(String username, int boardId) throws ExceptionUser {
        usersManagement.addSolvedBoard(username, boardId);
    }
    /**
     * Checks if a user has solved a specific board.
     *
     * @param username the username of the user
     * @param boardId the ID of the board to check
     * @return true if the user has solved the board, otherwise false
     * @throws ExceptionUser if there is an error checking if the user has solved the board
     */
    public boolean userHaveSolvedBoard(String username, int boardId) throws ExceptionUser {
        return usersManagement.userHaveSolvedBoard(username, boardId);
    }
    /**
     * Retrieves a saved game for the specified user and board.
     *
     * @param user the user to retrieve the game for
     * @param boardId the ID of the board associated with the game
     * @return the saved game if found, otherwise null
     * @throws ExceptionUser if there is an error retrieving the saved game
     * @throws ExceptionBoard if there is an error with the board
     */
    public Game getSavedGame(User user, Integer boardId) throws ExceptionUser, ExceptionBoard {
        return usersManagement.getSavedGame(user, boardId);
    }
    /**
     * Changes the password for the specified user.
     *
     * @param username the username of the user
     * @param password the new password
     * @throws ExceptionUser if there is an error changing the password
     */
    public void changePassword(String username, String password) throws ExceptionUser {
        usersManagement.changePassword(username, password);
    }
    /**
     * Orders the ranking by points.
     *
     * @return a list of pairs containing usernames and their points, ordered by points
     * @throws ExceptionUser if there is an error ordering the ranking
     */
    public List<Pair<String, Integer>> orderRankingByPoints() throws ExceptionUser {
        return rankingManagement.orderRankingByPoints();
    }
    /**
     * Orders the ranking by username.
     *
     * @return a list of pairs containing usernames and their points, ordered by username
     * @throws ExceptionUser if there is an error ordering the ranking
     */
    public List<Pair<String, Integer>> orderRankingByUsername() throws ExceptionUser {
        return rankingManagement.orderRankingByUsername();
    }

    /**
     * Orders the ranking by time for a specified KenKen size and difficulty.
     *
     * @param kenkenSize the size of the KenKen board
     * @param difficulty the difficulty level
     * @return a list of pairs containing usernames and their times, ordered by time
     * @throws ExceptionUser if there is an error ordering the ranking
     */
    public List<Pair<String, Long>> orderRankingByTime(int kenkenSize, int difficulty) throws ExceptionUser {
        return rankingManagement.orderRankingByTime(kenkenSize, difficulty);
    }
    /**
     * Orders the ranking by difficulty.
     *
     * @param difficulty the difficulty level
     * @return a list of pairs containing usernames and their points, ordered by difficulty
     * @throws ExceptionUser if there is an error ordering the ranking
     */
    public List<Pair<String, Integer>> orderRankingByDifficulty(int difficulty) throws ExceptionUser {
        return rankingManagement.orderRankingByDifficulty(difficulty);
    }
    /**
     * Orders the ranking by number of solved boards for a specified KenKen size.
     *
     * @param kenkenSize the size of the KenKen board
     * @return a list of pairs containing usernames and their number of solved boards, ordered by number of solved boards
     * @throws ExceptionUser if there is an error ordering the ranking
     */
    public List<Pair<String, Integer>> orderRankingByNumberOfSolved(int kenkenSize) throws ExceptionUser {
        return rankingManagement.orderRankingByNumberOfSolved(kenkenSize);
    }
    /**
     * Retrieves the number of boards in the system.
     *
     * @return the number of boards
     * @throws ExceptionBoard if there is an error retrieving the number of boards
     */
    public int getNumBoards() throws ExceptionBoard {
        return boardsManagement.getNumBoards();
    }
    /**
     * Retrieves the size of the board at the specified index.
     *
     * @param i the index of the board
     * @return the size of the board at the specified index
     * @throws ExceptionBoard if there is an error retrieving the board size
     */
    public int getBoardSize(int i) throws ExceptionBoard {
        return boardsManagement.getBoardSize(i);
    }
    /**
     * Retrieves the difficulty of the board at the specified index.
     *
     * @param i the index of the board
     * @return the difficulty of the board at the specified index
     * @throws ExceptionBoard if there is an error retrieving the board difficulty
     */
    public int getBoardDifficulty(int i) throws ExceptionBoard {
        return boardsManagement.getBoardDifficulty(i);
    }
    
}
