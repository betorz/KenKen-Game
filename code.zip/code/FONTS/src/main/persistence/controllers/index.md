# Projecte KenKen - Persistència - Controladors

Aquest directori conté les classes de control de persistència del projecte KenKen. Aquestes classes s'encarreguen de gestionar l'emmagatzematge i la recuperació de dades a través dels controladors. A continuació es descriu breument el propòsit de cada fitxer i les classes que conté.

## Fitxers i Classes

1. **CtrlPersistencia.java**
   - Classe de control per gestionar les operacions de persistència de dades. Inclou funcions per interaccionar amb les classes de persistència i coordinar l'emmagatzematge i la recuperació de dades dels usuaris, rànquing i taulers.

