# Projecte KenKen - Presentació

Aquest directori conté les classes i controladors de presentació del projecte KenKen. Aquestes classes i controladors s'encarreguen de gestionar la interfície gràfica d'usuari (GUI) i la interacció amb l'usuari.

## Subcarpetes i Fitxers

### controllers
- Aquest directori conté els controladors que gestionen les operacions de presentació. Per a més detalls, consulteu el fitxer `index.txt` dins de la carpeta `controllers`.

### views
- Aquest directori conté les vistes que gestionen la interfície gràfica d'usuari. Per a més detalls, consulteu el fitxer `index.txt` dins de la carpeta `views`.


