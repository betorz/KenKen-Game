package main.presentation.controllers;

import javax.swing.JLabel;
import javax.swing.JTextField;

import main.domain.classes.Stats;
import main.domain.classes.exceptions.ExceptionBoard;
import main.domain.classes.exceptions.ExceptionGame;
import main.domain.classes.exceptions.ExceptionUser;
import main.domain.classes.Board;
import main.domain.classes.Game;
import main.domain.classes.Pair;
import main.domain.controllers.CtrlDomini;
import main.presentation.views.*;

import java.awt.*;
import java.util.HashSet;
import java.util.List;

/**
 * The CtrlPresentation class is responsible for controlling the presentation layer of the application.
 * It interacts with the CtrlDomini class to perform various operations related to user management, game management, and statistics.
 */
public class CtrlPresentation {

    private CtrlDomini ctrlDomini;
    private MainView vistaPrincipal;

    /**
     * Constructs a new instance of the CtrlPresentation class.
     * Initializes the CtrlDomini object and the MainView object.
     */
    public CtrlPresentation(){
        ctrlDomini = new CtrlDomini();
        vistaPrincipal = new MainView(this);
    }

    /**
     * Initializes the presentation by making the main view visible.
     */
    public void initializePresentation() {
        vistaPrincipal.setVisible(true);
    }

    /**
     * Registers a new user with the given username and password.
     *
     * @param user     the username of the user to register
     * @param password the password of the user to register
     * @param password2 the confirmation password for the user to register
     * @throws ExceptionUser if there is an error during user registration
     */
    public void register(String user, String password, String password2) throws ExceptionUser {
        ctrlDomini.createUser(user, password, password2);
    }

    /**
     * Logs in the user with the specified username and password.
     *
     * @param user     the username of the user
     * @param password the password of the user
     * @throws ExceptionUser if there is an error during the login process
     */
    public void login(String user, String password) throws ExceptionUser {
        ctrlDomini.login(user, password);
    }

    /**
     * Returns the current username.
     *
     * @return the current username as a String.
     */
    public String getCurrentUsername() {
        return ctrlDomini.getCurrentUsername();
    }

    /**
     * Logs out the current user.
     *
     * @throws ExceptionUser if an error occurs during the logout process.
     */
    public void logout() throws ExceptionUser {
        ctrlDomini.logout();
    }

    /**
     * Changes the password of the user.
     *
     * @param password    The current password of the user.
     * @param newpassword The new password to be set.
     * @param newpassword2 The confirmation of the new password.
     * @throws ExceptionUser If the password change fails.
     */
    public void changePassword(String password, String newpassword, String newpassword2) throws ExceptionUser {
        ctrlDomini.changePassword(password, newpassword, newpassword2);
    }

    /**
     * Deletes the user profile with the specified password.
     *
     * @param password the password of the user profile to be deleted
     * @throws ExceptionUser if an error occurs while deleting the user profile
     */
    public void deleteProfile(String password) throws ExceptionUser {
        ctrlDomini.deleteUser(password);
    }

    /**
     * Retrieves the statistics of the application.
     *
     * @return The statistics of the application.
     * @throws ExceptionUser if there is an error retrieving the statistics.
     */
    public Stats getStats() throws ExceptionUser {
        return ctrlDomini.getStats();
    }

    /**
     * Retrieves the ranking of users by their usernames.
     *
     * @return A list of pairs, where each pair contains a username and an integer representing the user's ranking.
     * @throws ExceptionUser if there is an error retrieving the ranking.
     */
    public List<Pair<String, Integer>> getRankingByUsername() throws ExceptionUser {
        return ctrlDomini.orderRankingByUsername();
    }

    /**
     * Retrieves the ranking of players based on their points.
     *
     * @return A list of pairs containing the player's name and their corresponding points.
     * @throws ExceptionUser if there is an error retrieving the ranking.
     */
    public List<Pair<String, Integer>> getRankingByPoints() throws ExceptionUser {
        return ctrlDomini.orderRankingByPoints();
    }

    /**
     * Retrieves a ranking of players based on their completion time for a given difficulty level.
     *
     * @param size       The number of players to include in the ranking.
     * @param difficulty The difficulty level for which to retrieve the ranking.
     * @return A list of pairs, where each pair contains the player's name and their completion time.
     * @throws ExceptionUser if there is an error retrieving the ranking.
     */
    public List<Pair<String, Long>> getRankingByTime(int size, int difficulty) throws ExceptionUser {
        return ctrlDomini.orderRankingByTime(size, difficulty);
    }

    /**
     * Retrieves the ranking of Kenken puzzles solved by difficulty level.
     *
     * @param difficulty The difficulty level of the puzzles.
     * @return A list of pairs containing the username and the number of puzzles solved for each user.
     * @throws ExceptionUser If there is an error retrieving the ranking.
     */
    public List<Pair<String, Integer>> getRankingByKenkenSolvedDifficulty(int difficulty) throws ExceptionUser {
        return ctrlDomini.orderRankingByDifficulty(difficulty);
    }

    /**
     * Retrieves the ranking of players based on the number of Kenken puzzles solved of a specific size.
     *
     * @param size The size of the Kenken puzzles.
     * @return A list of pairs containing the player names and the number of puzzles solved.
     * @throws ExceptionUser if there is an error retrieving the ranking.
     */
    public List<Pair<String, Integer>> getRankingByKenkenSolvedSize(int size) throws ExceptionUser {
        return ctrlDomini.orderRankingByNumberOfSolved(size);
    }

    /**
     * Configures the appearance of a text field.
     * Sets the background color to white, the foreground color to black,
     * the caret color to black, and the font to Arial with a plain style and size 18.
     *
     * @param txtField the text field to configure
     */
    public void configureTextField(JTextField txtField) {
        txtField.setBackground(Color.WHITE);
        txtField.setForeground(Color.BLACK);
        txtField.setCaretColor(Color.BLACK);
        txtField.setFont(new Font("ARIAL", Font.PLAIN, 18));
    }

    /**
     * Creates and configures a JLabel with the specified text and size.
     * 
     * @param text the text to be displayed on the label
     * @param size the font size of the label
     * @return the configured JLabel
     */
    public JLabel configureLabel(String text, int size) {
        JLabel label = new JLabel(text);
        label.setForeground(new Color(6,6,6));
        label.setFont(new Font("ARIAL", Font.PLAIN, size));
        return label;
    }

    /**
     * Returns the number of boards.
     *
     * @return the number of boards
     * @throws ExceptionBoard if an error occurs while retrieving the number of boards
     */
    public int getNumBoards() throws ExceptionBoard {
        return ctrlDomini.getNumBoards();
    }

    /**
     * Retrieves the difficulty of a board.
     *
     * @param i The index of the board.
     * @return The difficulty of the board.
     * @throws ExceptionBoard If an error occurs while retrieving the board difficulty.
     */
    public int getBoardDifficulty(int i) throws ExceptionBoard {
        return ctrlDomini.getBoardDifficulty(i);
    }

    /**
     * Returns the size of the board for the specified index.
     *
     * @param i the index of the board
     * @return the size of the board
     * @throws ExceptionBoard if an error occurs while retrieving the board size
     */
    public int getBoardSize(int i) throws ExceptionBoard {
        return ctrlDomini.getBoardSize(i);
    }

    /**
     * Starts a new game with the specified level number.
     *
     * @param levelNum the level number to start the game with
     * @throws ExceptionGame if there is an error during the game execution
     * @throws ExceptionUser if there is an error with the user input
     * @throws ExceptionBoard if there is an error with the game board
     */
    public void startGame(int levelNum) throws ExceptionGame, ExceptionUser, ExceptionBoard {
        ctrlDomini.startGame(levelNum);
    }

    /**
     * Returns the current board.
     *
     * @return the current board.
     */
    public Board getCurrentBoard() {
        return ctrlDomini.getCurrentBoard();
    }

    /**
     * Makes a move in the game by specifying the row, column, and number.
     *
     * @param row The row index of the cell where the move is made.
     * @param col The column index of the cell where the move is made.
     * @param number The number to be placed in the cell.
     * @throws ExceptionGame if an error occurs during the move.
     */
    public void makeMove(int row, int col, int number) throws ExceptionGame {
        ctrlDomini.makeMove(row, col, number); 
    }

    /**
     * Creates a new board based on the given board information.
     *
     * @param boardInfo the list of integers representing the board information
     * @throws ExceptionBoard if an error occurs while creating the board
     */
    public void makeBoard(List<Integer> boardInfo) throws ExceptionBoard {
        ctrlDomini.makeBoard(boardInfo);
    }

    /**
     * Starts a custom game.
     */
    public void startCustomGame() {
        ctrlDomini.startCustomGame();
    }

    /**
     * Generates a board with the specified size, predefined regions, and predefined operations.
     *
     * @param size              The size of the board.
     * @param predefinedRegions The list of predefined regions.
     * @param predOps           The set of predefined operations.
     * @throws ExceptionBoard if an error occurs while generating the board.
     */
    public void generateBoard(int size, List<Integer> predefinedRegions, HashSet<Integer> predOps) throws ExceptionBoard {
        ctrlDomini.generateBoard(size, predefinedRegions, predOps);
    }

    /**
     * Checks if a board with the specified ID is finished.
     *
     * @param boardId the ID of the board to check
     * @return true if the board is finished, false otherwise
     * @throws ExceptionUser if there is an error while checking the board's status
     */
    public boolean isFinished(int boardId) throws ExceptionUser {
        return ctrlDomini.isFinished(boardId);
    }

    /**
     * Checks if the presentation controller is started.
     *
     * @return true if the presentation controller is started, false otherwise.
     */
    public boolean isStarted() {
        return ctrlDomini.isStarted();
    }

    /**
     * Retrieves a saved game with the specified board ID.
     *
     * @param boardId the ID of the board associated with the saved game
     * @return the saved game object
     * @throws ExceptionUser if there is an error related to the user
     * @throws ExceptionBoard if there is an error related to the board
     */
    public Game getSavedGame(int boardId) throws ExceptionUser, ExceptionBoard {
        return ctrlDomini.getSavedGame(boardId);
    }

    /**
     * Checks the solution by calling the corresponding method in the domain controller.
     * 
     * @return true if the solution is correct, false otherwise.
     */
    public boolean checkSolution() {
        return ctrlDomini.checkSolution();
    }

    /**
     * Finish the current game.
     *
     * @throws ExceptionUser if there is an error finishing the game.
     */
    public void finishGame() throws ExceptionUser {
        ctrlDomini.finishGame();
    }

    /**
     * Retrieves a hint from the domain controller.
     *
     * @return A Pair object representing the hint, where the first element is the row index and the second element is the column index.
     */
    public Pair<Integer, Integer> getHint() {
        return ctrlDomini.getHint();
    }

    /**
     * Solves the board by calling the corresponding method in the domain controller.
     */
    public void solveBoard() {
        ctrlDomini.solveBoard();
    }

    /**
     * Updates the user statistics.
     *
     * @throws ExceptionUser if there is an error updating the user statistics.
     */
    public void updateUserStats() throws ExceptionUser {
        ctrlDomini.updateUserStats();
    }

    /**
     * Checks if the given value is valid for the specified row and column according to the game rules.
     *
     * @param r The row index.
     * @param c The column index.
     * @param v The value to be checked.
     * @return True if the value is valid for the row and column, false otherwise.
     */
    public boolean checkRowColRule(int r, int c, int v) {
        return ctrlDomini.checkRowColRule(r, c, v);
    }

    /**
     * Checks if the given operation rule is valid for the specified row and column.
     *
     * @param r The row index.
     * @param c The column index.
     * @return true if the operation rule is valid, false otherwise.
     */
    public boolean checkOpRule(int r, int c) {
        return ctrlDomini.checkOpRule(r, c);
    }

    /**
     * Stops the current playing process.
     */
    public void stopPlaying() {
        ctrlDomini.stopPlaying();
    }

    /**
     * Returns the current time.
     *
     * @return the current time in double format.
     */
    public double getTime() {
        return ctrlDomini.getTime();
    }

    /**
     * Checks if the given board has a solution.
     *
     * @param board the board to check for a solution
     * @return true if the board has a solution, false otherwise
     */
    public boolean hasSolution(Board board) {
        return ctrlDomini.hasSolution(board);
    }

}