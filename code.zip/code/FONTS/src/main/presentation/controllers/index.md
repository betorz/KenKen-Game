# Projecte KenKen - Presentació - Controladors

Aquest directori conté les classes de control de la presentació del projecte KenKen. Aquestes classes s'encarreguen de gestionar la lògica i les operacions relacionades amb la interfície gràfica d'usuari (GUI). A continuació es descriu breument el propòsit de cada fitxer i les classes que conté.

## Fitxers i Classes

1. **CtrlPresentation.java**
   - Classe de control que gestiona les operacions de presentació. S'encarrega de coordinar les interaccions entre la lògica de negoci i la interfície gràfica d'usuari, assegurant una experiència d'usuari coherent i fluida.
