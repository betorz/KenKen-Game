package main.presentation.views;

import javax.swing.*;
import main.presentation.controllers.CtrlPresentation;
import main.domain.classes.Pair;
import main.domain.classes.exceptions.ExceptionUser;

import java.awt.*;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Represents a ranking view in the presentation layer.
 * This view is responsible for displaying the ranking of players.
 * 
 * @param pCtrlPresentation The presentation controller.
 * @param menuView The menu view.
 */
public class RankingView extends JFrame {
    private CtrlPresentation iCtrlPresentation;
    private MenuView menuView;

    private JLabel lblTitle;
    private JButton buttonBack;
    private JButton buttonExit;
    private JPanel topPanel;
    private JPanel centerPanel;

    private JButton buttonSortByName;
    private JButton buttonSortByPoints;
    private JButton buttonSortByTime;
    private JButton buttonSortByKenkenSolvedDifficulty;
    private JButton buttonSortByKenkenSolvedSize;

    private JPanel buttonPanel;
    private JPanel rankingPanel;
    private JPanel rankingContainer;
    private JPanel rankingTypePanel;

    private JScrollPane scrollPane;

    private JLabel emptyRankingLabel; 
    private JLabel sortingRankingTypeLabel;  

    /**
     * Represents a ranking view in the presentation layer.
     * This view is responsible for displaying the ranking of players.
     * @param pCtrlPresentation The presentation controller.
     * @param menuView The menu view.
     */
    public RankingView(CtrlPresentation pCtrlPresentation, MenuView menuView) {
        this.iCtrlPresentation = pCtrlPresentation;
        this.menuView = menuView;
        initializeComponents();
    }

    /**
     * Initializes the components of the RankingView.
     * This method sets up the labels, buttons, panels, and other UI elements required for the RankingView.
     * It also configures the frame and adds event listeners to the buttons.
     */
    private void initializeComponents() {
        lblTitle = new JLabel("Ranking", SwingConstants.CENTER);
        buttonBack = new JButton("Back");
        buttonBack.setBackground(Color.WHITE);
        buttonExit = new JButton("Exit");
        buttonExit.setBackground(Color.WHITE);
        topPanel = new JPanel(new BorderLayout());
        centerPanel = new JPanel(new BorderLayout());
        buttonSortByName = new JButton("By Name");
        buttonSortByName.setBackground(Color.WHITE);
        buttonSortByName.setFont(new Font("Arial", Font.PLAIN, 12));
        buttonSortByPoints = new JButton("By Points");
        buttonSortByPoints.setBackground(Color.WHITE);
        buttonSortByPoints.setFont(new Font("Arial", Font.PLAIN, 12));
        buttonSortByTime = new JButton("By Time");
        buttonSortByTime.setBackground(Color.WHITE);
        buttonSortByTime.setFont(new Font("Arial", Font.PLAIN, 12));
        buttonSortByKenkenSolvedDifficulty = new JButton("#Solved By Difficulty");
        buttonSortByKenkenSolvedDifficulty.setBackground(Color.WHITE);
        buttonSortByKenkenSolvedDifficulty.setFont(new Font("Arial", Font.PLAIN, 12));
        buttonSortByKenkenSolvedSize = new JButton("#Solved By Size");
        buttonSortByKenkenSolvedSize.setBackground(Color.WHITE);
        buttonSortByKenkenSolvedSize.setFont(new Font("Arial", Font.PLAIN, 12));
        
        rankingPanel = new JPanel();
        rankingPanel.setLayout(new BoxLayout(rankingPanel, BoxLayout.Y_AXIS));
        rankingPanel.setBackground(new Color(249, 249, 249));
        
        emptyRankingLabel = new JLabel("Ranking is empty (users must play at least one game to appear here)");
        emptyRankingLabel.setForeground(new Color(6,6,6));
        emptyRankingLabel.setHorizontalAlignment(SwingConstants.CENTER);
        
        sortingRankingTypeLabel = new JLabel("");
        sortingRankingTypeLabel.setForeground(new Color(6,6,6));
        sortingRankingTypeLabel.setHorizontalAlignment(SwingConstants.CENTER);
        sortingRankingTypeLabel.setFont(new Font("Arial", Font.ITALIC, 16));

        setTitle("Ranking");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(768, 576);
        setResizable(false);
        setLocationRelativeTo(null);
        getContentPane().setBackground(new Color(249, 249, 249));
        setLayout(new BorderLayout());

        lblTitle.setFont(new Font("Arial", Font.BOLD, 30));
        lblTitle.setForeground(Color.WHITE);
        topPanel.setBackground(new Color(2, 136, 209));
        topPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        topPanel.add(buttonBack, BorderLayout.WEST);
        topPanel.add(lblTitle, BorderLayout.SOUTH);
        topPanel.add(buttonExit, BorderLayout.EAST);
        add(topPanel, BorderLayout.NORTH);

        buttonPanel = new JPanel(new FlowLayout());
        buttonPanel.setBackground(new Color(249,249, 249));
        buttonPanel.add(buttonSortByName);
        buttonPanel.add(buttonSortByPoints);
        buttonPanel.add(buttonSortByTime);
        buttonPanel.add(buttonSortByKenkenSolvedDifficulty);
        buttonPanel.add(buttonSortByKenkenSolvedSize);
        centerPanel.add(buttonPanel, BorderLayout.NORTH);

        rankingContainer = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.NORTH;
        gbc.weightx = 1;
        gbc.weighty = 1;
        rankingContainer.setBackground(new Color(249, 249, 249));
        rankingContainer.add(rankingPanel, gbc);
        scrollPane = new JScrollPane(rankingContainer);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());
        centerPanel.add(scrollPane, BorderLayout.CENTER);

        rankingTypePanel = new JPanel();
        rankingTypePanel.setBackground(new Color(249, 249, 249));
        rankingTypePanel.add(sortingRankingTypeLabel);
        centerPanel.add(rankingTypePanel, BorderLayout.SOUTH);

        add(centerPanel, BorderLayout.CENTER);

        buttonBack.addActionListener(e -> {
            menuView.setVisible(true);
            dispose();
        });

        buttonExit.addActionListener(e -> {
            System.exit(0);
        });

        buttonSortByName.addActionListener(e -> {
            List<Pair<String, Integer>> ranking;
            try {
                ranking = iCtrlPresentation.getRankingByUsername();
            } catch (ExceptionUser e1) {
                JOptionPane.showMessageDialog(this, e1.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            updateRankingPanel(ranking, "points", "Sorted by Name");
        });

        buttonSortByPoints.addActionListener(e -> {
            List<Pair<String, Integer>> ranking;
            try {
                ranking = iCtrlPresentation.getRankingByPoints();
            } catch (ExceptionUser e1) {
                JOptionPane.showMessageDialog(this, e1.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            updateRankingPanel(ranking, "points", "Sorted by Points");
        });

        buttonSortByTime.addActionListener(e -> {
            showRankingByTime();
        });

        buttonSortByKenkenSolvedDifficulty.addActionListener(e -> {
            showRankingByKenkenSolvedDifficulty();
        });

        buttonSortByKenkenSolvedSize.addActionListener(e -> {
            showRankingByKenkenSolvedSize();
        });
    }

    /**
     * Displays a dialog box to select the board size and difficulty for ranking by time.
     * Retrieves the ranking data based on the selected size and difficulty, and updates the ranking panel accordingly.
     */
    private void showRankingByTime() {
        String[] sizes = {"3x3", "4x4", "5x5", "6x6", "7x7", "8x8", "9x9"};
        String[] difficulties = {"easy", "medium", "hard", "extreme"};

        JPanel panel = new JPanel(new GridLayout(2, 2));
        JComboBox<String> sizeComboBox = new JComboBox<>(sizes);
        JComboBox<String> difficultyComboBox = new JComboBox<>(difficulties);
        panel.add(new JLabel("Select Size:"));
        panel.add(sizeComboBox);
        panel.add(new JLabel("Select Difficulty:"));
        panel.add(difficultyComboBox);

        int result = JOptionPane.showConfirmDialog(this, panel, "Select Board Size and Difficulty", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (result == JOptionPane.OK_OPTION) {
            int selectedSize = sizeComboBox.getSelectedIndex();
            int selectedDifficulty = difficultyComboBox.getSelectedIndex();

            List<Pair<String, Long>> ranking;
            try {
                ranking = iCtrlPresentation.getRankingByTime(selectedSize, selectedDifficulty);
            } catch (ExceptionUser e) {
                JOptionPane.showMessageDialog(this, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            String rankingType = String.format("Sorted by Time (Size: %s, Difficulty: %s)", sizes[selectedSize], difficulties[selectedDifficulty]);
            updateRankingPanelByTime(ranking, rankingType);
        }
    }

    /**
     * Displays a dialog to select the difficulty level and updates the ranking panel based on the selected difficulty.
     */
    private void showRankingByKenkenSolvedDifficulty() {
        String[] difficulties = {"easy", "medium", "hard", "extreme"};

        JPanel panel = new JPanel(new GridLayout(1, 2));
        JComboBox<String> difficultyComboBox = new JComboBox<>(difficulties);
        panel.add(new JLabel("Select Difficulty:"));
        panel.add(difficultyComboBox);

        int result = JOptionPane.showConfirmDialog(this, panel, "Select Difficulty", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (result == JOptionPane.OK_OPTION) {
            int selectedDifficulty = difficultyComboBox.getSelectedIndex();

            List<Pair<String, Integer>> ranking;
            try {
                ranking = iCtrlPresentation.getRankingByKenkenSolvedDifficulty(selectedDifficulty);
            } catch (ExceptionUser e) {
                JOptionPane.showMessageDialog(difficultyComboBox, e, getTitle(), selectedDifficulty);
                return;
            }
            String rankingType = String.format("Sorted by Kenkens Solved (Difficulty: %s)", difficulties[selectedDifficulty]);
            updateRankingPanel(ranking, "kenkens", rankingType);
        }
    }

    /**
     * Displays a dialog to select the size for ranking by Kenken solved.
     * Retrieves the ranking based on the selected size and updates the ranking panel accordingly.
     */
    private void showRankingByKenkenSolvedSize() {
        String[] sizes = {"3x3", "4x4", "5x5", "6x6", "7x7", "8x8", "9x9"};

        JPanel panel = new JPanel(new GridLayout(1, 2));
        JComboBox<String> sizeComboBox = new JComboBox<>(sizes);
        panel.add(new JLabel("Select Size:"));
        panel.add(sizeComboBox);

        int result = JOptionPane.showConfirmDialog(this, panel, "Select Board Size", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (result == JOptionPane.OK_OPTION) {
            int selectedSize = sizeComboBox.getSelectedIndex();

            List<Pair<String, Integer>> ranking;
            try {
                ranking = iCtrlPresentation.getRankingByKenkenSolvedSize(selectedSize);
            } catch (ExceptionUser e) {
                JOptionPane.showMessageDialog(this, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            String rankingType = String.format("Sorted by Kenkens Solved (Size: %s)", sizes[selectedSize]);
            updateRankingPanel(ranking, "kenkens", rankingType);
        }
    }

    /**
     * Updates the ranking panel with the given ranking data, unit, and rankingType.
     * 
     * @param ranking The list of pairs representing the ranking data, where each pair contains a player name and their score.
     * @param unit The unit of measurement for the scores.
     * @param rankingType The sorting rankingType for the ranking.
     */
    private void updateRankingPanel(List<Pair<String, Integer>> ranking, String unit, String rankingType) {
        rankingPanel.removeAll();

        List<Pair<String, Integer>> filteredRanking = ranking.stream()
                .filter(entry -> entry.getY() > 0)
                .collect(Collectors.toList());

        if (filteredRanking.isEmpty()) {
            rankingPanel.add(emptyRankingLabel);
        } else {
            for (int i = 0; i < filteredRanking.size(); i++) {
                Pair<String, Integer> entry = filteredRanking.get(i);
                String text = String.format("%d. %s - %d %s", i + 1, entry.getX(), entry.getY(), unit);
                JLabel label = iCtrlPresentation.configureLabel(text, 18);
                rankingPanel.add(label);
                rankingPanel.add(Box.createVerticalStrut(10)); 
            }
        }
        sortingRankingTypeLabel.setText(rankingType);
        rankingPanel.revalidate();
        rankingPanel.repaint();
        scrollPane.getVerticalScrollBar().setValue(0); 
    }

    /**
     * Updates the ranking panel based on the given ranking list and rankingType.
     * 
     * @param ranking The list of pairs containing player names and their corresponding times.
     * @param rankingType The sorting rankingType for the ranking.
     */
    private void updateRankingPanelByTime(List<Pair<String, Long>> ranking, String rankingType) {
        rankingPanel.removeAll();

        //Filter out scores equal to 99999999
        List<Pair<String, Long>> filteredRanking = ranking.stream()
                .filter(entry -> entry.getY() != 99999999L)
                .collect(Collectors.toList());

        if (filteredRanking.isEmpty()) {
            rankingPanel.add(emptyRankingLabel);
        } else {
            for (int i = 0; i < filteredRanking.size(); i++) {
                Pair<String, Long> entry = filteredRanking.get(i);
                String text = String.format("%d. %s - %s", i + 1, entry.getX(), formatTime(entry.getY()));
                JLabel label = iCtrlPresentation.configureLabel(text, 18);
                rankingPanel.add(label);
                rankingPanel.add(Box.createVerticalStrut(10)); //Add space between elements
            }
        }
        sortingRankingTypeLabel.setText(rankingType);
        rankingPanel.revalidate();
        rankingPanel.repaint();
        scrollPane.getVerticalScrollBar().setValue(0); 
    }

    /**
     * Formats the given time in milliseconds into a string representation.
     * If the time is less than 1 minute, it is formatted as seconds with two decimal places.
     * Otherwise, it is formatted as minutes and seconds.
     *
     * @param timeInMilliseconds the time to format in milliseconds
     * @return the formatted time as a string
     */
    private String formatTime(long timeInMilliseconds) {
        if (timeInMilliseconds < 60000) {  
            return String.format("%.2f", timeInMilliseconds / 1000.0) + "s";
        } else {
            long totalSeconds = timeInMilliseconds / 1000; // Convert milliseconds to seconds
            long minutes = totalSeconds / 60;            
            long seconds = totalSeconds % 60;             
    
            return String.format("%dm %02ds", minutes, seconds);
        }
    }
}
