package main.presentation.views;

import javax.swing.*;
import javax.swing.border.*;

import java.awt.*;
import java.awt.event.*;

import java.util.List;
import java.util.ArrayList;

import main.presentation.controllers.CtrlPresentation;

/**
 * Represents a view for creating a game.
 * This class extends the JFrame class and provides a graphical user interface for creating a game.
 * It allows the user to select panels on a grid, specify region results, and perform operations on the regions.
 */
public class CreateGameView extends JFrame {

    private CtrlPresentation ctrlPresentation;
    private CreateMenuView createMenuView;

    private int size;
    private int regionId;

    private JButton buttonBack;
    private JButton buttonExit;

    private JPanel topPanel;
    private JPanel centerPanel;
    private JPanel bottomPanel;
    private JPanel rightPanel;
    private JPanel leftPanel;

    private List<JPanel> panelSelection;
    private List<List <JPanel>> regions;
    private int[][] regionsMatrix;

    /**
     * Represents a view for creating a game.
     */
    public CreateGameView(CtrlPresentation ictrlPresentation, CreateMenuView createMenuView) {

        this.ctrlPresentation = ictrlPresentation;
        this.createMenuView = createMenuView;
        this.setTitle("Create Menu");
        this.setSize(768, 768);

        size = 3;
        regionId = 1;
        regions = new ArrayList<>();

        initializeComponents();

        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null);
        this.setVisible(true);
    }

    /**
     * Initializes the components of the CreateGameView.
     * This method creates and initializes the necessary components for the CreateGameView,
     * such as the center panel, top panel, right panel, left panel, and bottom panel.
     */
    private void initializeComponents() {

        centerPanel = new JPanel(new GridLayout(size, size));
        panelSelection = new ArrayList<>();

        initTopPanel();
        initCenterPanel();
        initRightPanel();
        initLeftPanel();
        initBottomPanel();

    }

    /**
     * Initializes the center panel of the CreateGameView.
     * This method sets up the layout, background color, and font size of the cells in the center panel.
     * It also adds mouse click listeners to the cells for user interaction.
     */
    private void initCenterPanel() {

        centerPanel.removeAll();
        centerPanel.revalidate();

        regionsMatrix = new int[size][size];

        centerPanel.setLayout(new GridLayout(size, size));
        centerPanel.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));
        centerPanel.setBackground(new Color(249,249,249));

        for (int i = 0; i < size; ++i) {
            for (int j = 0; j < size; ++j) {
                
                JPanel cell = new JPanel(new BorderLayout());
                cell.setBackground(new Color(238,238,238));
                JLabel numberLabel = new JLabel();

                switch (size) {
                    case 3:
                    numberLabel.setFont(new Font("Arial", Font.PLAIN, 50));
                    break;
                case 4:
                    numberLabel.setFont(new Font("Arial", Font.PLAIN, 40));
                    break;
                case 5:
                    numberLabel.setFont(new Font("Arial", Font.PLAIN, 33));
                    break;
                case 6:
                    numberLabel.setFont(new Font("Arial", Font.PLAIN, 28));
                    break;
                case 7:
                    numberLabel.setFont(new Font("Arial", Font.PLAIN, 25));
                    break;
                case 8:
                    numberLabel.setFont(new Font("Arial", Font.PLAIN, 22));
                    break;
                case 9:
                    numberLabel.setFont(new Font("Arial", Font.PLAIN, 20));
                    break;
                }
                numberLabel.setHorizontalAlignment(SwingConstants.CENTER);
                numberLabel.setVerticalAlignment(SwingConstants.CENTER);
                cell.putClientProperty("row", i);
                cell.putClientProperty("col", j);
                cell.putClientProperty("regionId", 0);


                cell.add(numberLabel, BorderLayout.CENTER);

                cell.addMouseListener(new MouseAdapter() {

                    

                    @Override
                    public void mouseClicked(MouseEvent e) {

                        if (panelSelection.contains(cell)) {
                            panelSelection.remove(cell);
                            if (cell.getClientProperty("regionId").equals(0)) {
                                cell.setBackground(new Color(238,238,238));
                            } else {
                                cell.setBackground(new Color(173,216,230));
                            }
                        } else {
                            panelSelection.add(cell);
                            cell.setBackground(new Color(211,211,211));
                        }
                    }
                });

                centerPanel.add(cell);
            }
        }
        
        paintBoard();
        CreateGameView.this.add(centerPanel, BorderLayout.CENTER);
    }

    /**
     * Initializes the bottom panel of the CreateGameView.
     * This panel contains various components such as size selector, type of operation selector,
     * region result field, add region button, and validate board button.
     * The method sets up the event listeners and handles user interactions with these components.
     */
    private void initBottomPanel() {

        bottomPanel = new JPanel(new BorderLayout());
        bottomPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        bottomPanel.setBackground(new Color(249,249,249));

        String[] sizeOptions = {"3x3", "4x4", "5x5", "6x6", "7x7", "8x8", "9x9"};
        JComboBox<String> sizeSelector = new JComboBox<>(sizeOptions);

        sizeSelector.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String selectedSize = (String) sizeSelector.getSelectedItem();
                size = Integer.parseInt(selectedSize.substring(0, 1));
                regionId = 1;
                regions.clear();
                panelSelection.clear();
                initCenterPanel();
            }
        });

        JPanel centerBottomPanel = new JPanel(new GridLayout(1,3, 5, 0));
        centerBottomPanel.setBackground(new Color(249,249,249));

        JComboBox<String> typeOfOperation = new JComboBox<>(new String[] {"=", "+", "-", "*", "/", "%", "^"});
        JTextField regionResultField = new JTextField();
        regionResultField.setText("Region result:");

        regionResultField.addFocusListener(new FocusAdapter() {
            @Override
            public void focusGained(FocusEvent e) {
                regionResultField.setText("");
            }
            public void focusLost(FocusEvent e) {
                if (regionResultField.getText().isEmpty()) {
                    regionResultField.setText("Region result:");
                }
            }
        });


        JButton addRegionButton = new JButton("Add Region");
        addRegionButton.setBackground(Color.WHITE);

        addRegionButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                if (panelSelection.isEmpty()) {
                    JOptionPane.showMessageDialog(null, 
                    "No panel selected", 
                    "Warning", 
                    JOptionPane.ERROR_MESSAGE);
                    return;
                }

                if (isPanelAlreadySelected()) {
                    JOptionPane.showMessageDialog(null, 
                    "Panel already used", 
                    "Warning", 
                    JOptionPane.ERROR_MESSAGE);
                    repaintPanel();
                    panelSelection.clear();
                    return;
                }

                if (!isPanelConected()) {
        
                    JOptionPane.showMessageDialog(null, 
                    "Regions are not adjacent",  //could add time
                    "Warning", 
                    JOptionPane.ERROR_MESSAGE);
                    repaintPanel();
                    panelSelection.clear();
                    return;
                }

                if (regionResultField.getText().isEmpty() || regionResultField.getText().equals("Region result:")) {
                    JOptionPane.showMessageDialog(null, 
                    "Region result is empty", 
                    "Warning", 
                    JOptionPane.ERROR_MESSAGE);
                    repaintPanel();
                    panelSelection.clear();
                    return;
                }

                try {
                    int regionResult = Integer.parseInt(regionResultField.getText());

                    if (regionResult < 1) {
                        JOptionPane.showMessageDialog(null, 
                        "Region result has to be bigger than 0", 
                        "Warning", 
                        JOptionPane.ERROR_MESSAGE);
                        repaintPanel();
                        panelSelection.clear();
                        return;
                    }


                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, 
                    "Region result is not a number", 
                    "Warning", 
                    JOptionPane.ERROR_MESSAGE);
                    repaintPanel();
                    panelSelection.clear();
                    return;
                }

                switch ((String) typeOfOperation.getSelectedItem()) {
                    case "=":
                        if (panelSelection.size() != 1) {
                            JOptionPane.showMessageDialog(null, 
                            "Region with operation = must have only one cell", 
                            "Warning", 
                            JOptionPane.ERROR_MESSAGE);
                            repaintPanel();
                            panelSelection.clear();
                            return;
                        }
                        break;
                    case "-":
                    case "/":
                    case "%":
                    case "^":
                        if (panelSelection.size() != 2) {
                            JOptionPane.showMessageDialog(null, 
                            "Region with operation " + (String) typeOfOperation.getSelectedItem() + " must have two cells", 
                            "Warning", 
                            JOptionPane.ERROR_MESSAGE);
                            repaintPanel();
                            panelSelection.clear();
                            return;
                        }
                        break;
                    case "+":
                    case "*":
                        if (panelSelection.size() < 2) {
                            JOptionPane.showMessageDialog(null, 
                            "Region with operation " + (String) typeOfOperation.getSelectedItem() + " must have at least two cells", 
                            "Warning", 
                            JOptionPane.ERROR_MESSAGE);
                            repaintPanel();
                            panelSelection.clear();
                            return;
                        }
                        break;
                }
                for (JPanel p : panelSelection) {
                    p.putClientProperty("regionId", regionId);
                    p.putClientProperty("regionOp", (String) typeOfOperation.getSelectedItem());
                    p.putClientProperty("regionResult", Integer.parseInt(regionResultField.getText()));
                    regionsMatrix[(int) p.getClientProperty("row")][(int) p.getClientProperty("col")] = regionId;
                    p.setBackground(new Color(173,216,230));
                }
                regions.add(new ArrayList<>(panelSelection));
                ++regionId;
                paintBoard();
                panelSelection.clear();
            }
        });

        centerBottomPanel.add(typeOfOperation);
        centerBottomPanel.add(regionResultField);
        centerBottomPanel.add(addRegionButton);

        JButton validateBoardButton = new JButton("Validate");
        validateBoardButton.setBackground(Color.WHITE);

        validateBoardButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (!isBoardOkay()) {
                    JOptionPane.showMessageDialog(null, 
                    "Some cells are not in a region", 
                    "Warning", 
                    JOptionPane.ERROR_MESSAGE);
                    return;
                }

                List<Integer> boardInfo = createBoard();

                try {
                    ctrlPresentation.makeBoard(boardInfo);
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, 
                    ex.getMessage(), 
                    "Warning", 
                    JOptionPane.ERROR_MESSAGE);
                    return;
                }

                String[] options = {"Show solution", "Play game"};

                int choice = JOptionPane.showOptionDialog(
                    null, 
                    "Your board has a solution. What do you want to do:", 
                    null, 
                    JOptionPane.DEFAULT_OPTION, 
                    JOptionPane.INFORMATION_MESSAGE, 
                    null, 
                    options, 
                    null);

                if (choice == 0) {
                    new SolvedKenkenView(ctrlPresentation, CreateGameView.this.createMenuView).setVisible(true);                
                    dispose();
                }
                else if (choice == 1) {
                    ctrlPresentation.startCustomGame();
                    new GameView(ctrlPresentation, CreateGameView.this.createMenuView).setVisible(true);
                    dispose();
                }
            }
        });


        bottomPanel.add(validateBoardButton, BorderLayout.EAST);
        bottomPanel.add(centerBottomPanel, BorderLayout.CENTER);
        bottomPanel.add(sizeSelector, BorderLayout.WEST);

        CreateGameView.this.add(bottomPanel, BorderLayout.SOUTH);
    }

    /**
     * Creates a board with the specified size and regions.
     * 
     * @return a list of integers representing the board information
     */
    protected List<Integer> createBoard() {
        List<Integer> boardInfo = new ArrayList<>();
        boardInfo.add(size);
        boardInfo.add(regions.size());
        for (List<JPanel> region : regions) {
            switch ((String) region.get(0).getClientProperty("regionOp")) {
                case "=":
                    boardInfo.add(0);
                    break;
                case "+":
                    boardInfo.add(1);
                    break;
                case "-":
                    boardInfo.add(2);
                    break;
                case "*":
                    boardInfo.add(3);
                    break;
                case "/":
                    boardInfo.add(4);
                    break;
                case "%":
                    boardInfo.add(5);
                    break;
                case "^":
                    boardInfo.add(6);
                    break;
            }
            boardInfo.add((int) region.get(0).getClientProperty("regionResult"));
            boardInfo.add(region.size());
            for (JPanel panel : region) {
                boardInfo.add((int) panel.getClientProperty("row") + 1);
                boardInfo.add((int) panel.getClientProperty("col") + 1);                
            }
        }

        return boardInfo;
    }

    /**
     * Checks if the board is okay, i.e., if all regions in the regionsMatrix are non-zero.
     *
     * @return true if the board is okay, false otherwise.
     */
    protected boolean isBoardOkay() {
        for (int i = 0; i < size; ++i) {
            for (int j = 0; j < size; ++j) {
                if (regionsMatrix[i][j] == 0) {
                    return false;
                }
            }
        }
        return true;
    }

    /**
     * Repaints the panels in the panelSelection list based on their regionId property.
     * If the regionId is 0, the panel background color is set to light gray (238,238,238).
     * Otherwise, the panel background color is set to light blue (173,216,230).
     */
    protected void repaintPanel() {
        for (JPanel panel : panelSelection) {
            if (panel.getClientProperty("regionId").equals(0)) {
                panel.setBackground(new Color(238,238,238));
            } else {
                panel.setBackground(new Color(173,216,230));
            }
        }
    }

    /**
     * Checks if any panel in the panelSelection list has already been selected.
     * A panel is considered selected if the corresponding position in the regionsMatrix is not 0.
     *
     * @return true if a panel has already been selected, false otherwise.
     */
    protected boolean isPanelAlreadySelected() {
        for (JPanel panel : panelSelection) {
            int row = (int) panel.getClientProperty("row");
            int col = (int) panel.getClientProperty("col");
            if (regionsMatrix[row][col] != 0) {
                return true;
            }
        }
        return false;
    }

    /**
     * Checks if the panels in the panelSelection list are connected.
     * 
     * @return true if the panels are connected, false otherwise.
     */
    protected boolean isPanelConected() {
        if (panelSelection.isEmpty()) {
            return false;
        }
        int firstRow = (int) panelSelection.get(0).getClientProperty("row");
        int firstCol = (int) panelSelection.get(0).getClientProperty("col");
        boolean[][] visited = new boolean[size][size];
        dfs(firstRow, firstCol, visited);
        for (JPanel panel : panelSelection) {
            int row = (int) panel.getClientProperty("row");
            int col = (int) panel.getClientProperty("col");
            if (!visited[row][col]) {
                return false;
            }
        }
        return true;
    }

    /**
     * Performs a depth-first search starting from the specified row and column.
     * Marks the visited cells in the visited array.
     *
     * @param row     the starting row
     * @param col     the starting column
     * @param visited a 2D boolean array representing the visited cells
     */
    private void dfs(int row, int col, boolean[][] visited) {
        visited[row][col] = true;
        int[][] directions = {{-1, 0}, {1, 0}, {0, -1}, {0, 1}};
        for (int[] dir : directions) {
            int newRow = row + dir[0];
            int newCol = col + dir[1];
            if (newRow >= 0 && newRow < size && newCol >= 0 && newCol < size && !visited[newRow][newCol]) {
                JPanel neighbor = (JPanel) centerPanel.getComponent(newRow * size + newCol);
                if (panelSelection.contains(neighbor)) {
                    dfs(newRow, newCol, visited);
                }
            }
        }
    }

    /**
     * Initializes the left panel of the CreateGameView.
     * The left panel is responsible for displaying certain components.
     */
    private void initLeftPanel() {
        leftPanel = new JPanel();
        leftPanel.setBorder(BorderFactory.createEmptyBorder(20, 10, 20, 10));
        leftPanel.setBackground(new Color(249,249,249));
        CreateGameView.this.add(leftPanel, BorderLayout.WEST);
    }

    /**
     * Initializes the right panel of the CreateGameView.
     * The right panel is responsible for displaying additional content
     * related to the game creation.
     */
    private void initRightPanel() {
        rightPanel = new JPanel();
        rightPanel.setBorder(BorderFactory.createEmptyBorder(20, 10, 20, 10));
        rightPanel.setBackground(new Color(249,249,249));
        CreateGameView.this.add(rightPanel, BorderLayout.EAST);
    }

    /**
     * Initializes the top panel of the CreateGameView.
     * This panel contains buttons for navigation and an informative title.
     */
    private void initTopPanel() {

        buttonBack = new JButton("Back");
        buttonBack.setBackground(Color.WHITE);
        topPanel = new JPanel(new BorderLayout());
        topPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        topPanel.setBackground(new Color(2,136,209));
        topPanel.add(buttonBack, BorderLayout.WEST);

        buttonBack.addActionListener(e -> {
            this.createMenuView.setVisible(true);
            dispose();
        });

        buttonExit = new JButton("Exit");
        buttonExit.setBackground(Color.WHITE);
        topPanel.add(buttonExit, BorderLayout.EAST);
        buttonExit.addActionListener(e-> {
            System.exit(0);
        });

        JLabel title = new JLabel("Create KenKen Board");
        title.setFont(new Font("Arial", Font.BOLD, 30));
        title.setForeground(Color.WHITE);
        title.setHorizontalAlignment(SwingConstants.CENTER);
        topPanel.add(title, BorderLayout.CENTER);

        CreateGameView.this.add(topPanel, BorderLayout.NORTH);

    }

    /**
     * Paints the game board with regions and their corresponding labels.
     * This method iterates over the cells of the game board and adds labels to cells that belong to a region.
     * It also sets borders for the cells based on the region boundaries.
     */
    private void paintBoard() {

        boolean[] checkedRegions = new boolean[regions.size()+1];

        for (int i = 0; i < size; ++i) {
            for (int j = 0; j < size; ++j) {

                int panelId = i * size + j;

                JPanel cell = (JPanel) centerPanel.getComponent(panelId);
                if (regionsMatrix[i][j] != 0 && !checkedRegions[regionsMatrix[i][j]]) {
                    
                    checkedRegions[regionsMatrix[i][j]] = true;
                    
                    String regionOp = (String) cell.getClientProperty("regionOp");
                    int regionResult = (int) cell.getClientProperty("regionResult");

    
                    JPanel topLeftPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 4, 4));
                    topLeftPanel.setOpaque(false);
                    JLabel label = new JLabel(regionOp + regionResult); 
                    label.setOpaque(false);
                    switch (size) {
                        case 3:
                            label.setFont(new Font("Arial", Font.BOLD, 20));
                            break;
                        case 4:
                            label.setFont(new Font("Arial", Font.BOLD, 19));
                            break;
                        case 5:
                            label.setFont(new Font("Arial", Font.BOLD, 18));
                            break;
                        case 6:
                            label.setFont(new Font("Arial", Font.BOLD, 17));
                            break;
                        case 7:
                            label.setFont(new Font("Arial", Font.BOLD, 16));
                            break;
                        case 8:
                            label.setFont(new Font("Arial", Font.BOLD, 14));
                            break;
                        case 9:
                            label.setFont(new Font("Arial", Font.BOLD, 12));
                            break;
                    }
                    topLeftPanel.add(label);
                    cell.add(topLeftPanel, BorderLayout.NORTH);

                    cell.revalidate();
                    cell.repaint();
                } 

                MatteBorder fullBorder = new MatteBorder(i == 0 ? 5 : 1, j == 0 ? 5 : 1,(i+1 < size) ? 1 : 5 ,(j+1 < size) ? 1 : 5,Color.BLACK);
                MatteBorder rightBorder = new MatteBorder(0,0,0,(j+1 < size && regionsMatrix[i][j] != regionsMatrix[i][j+1]) ? 4 : 0,Color.BLACK);
                MatteBorder bottomBorder = new MatteBorder(0,0,(i+1 < size && regionsMatrix[i][j]  != regionsMatrix[i+1][j]) ? 4 : 0, 0, Color.BLACK);
                Border border = BorderFactory.createCompoundBorder(fullBorder, BorderFactory.createCompoundBorder(rightBorder, bottomBorder));
                cell.setBorder(border);
            }
        }
    }
}
