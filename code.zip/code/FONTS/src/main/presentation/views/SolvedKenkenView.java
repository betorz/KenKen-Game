package main.presentation.views;

import javax.swing.*;
import java.awt.*;

import main.domain.classes.Board;
import main.presentation.controllers.CtrlPresentation;
import javax.swing.border.MatteBorder;
import javax.swing.border.Border;

public class SolvedKenkenView extends JFrame {
    
    private CtrlPresentation ctrlPresentation;
    private CreateMenuView createMenuView;

    private JButton buttonBack;
    private JButton buttonExit;

    private JPanel topPanel;
    private JPanel centerPanel;

    private Board currentBoard;
    

    /**
     * Constructs a new instance of the SolvedKenkenView class.
     * 
     * @param ctrlPresentation The CtrlPresentation object used for controlling the presentation layer.
     * @param createMenuView The CreateMenuView object used for creating the menu view.
     */
    public SolvedKenkenView(CtrlPresentation ctrlPresentation, CreateMenuView createMenuView) {
        this.ctrlPresentation = ctrlPresentation;
        this.createMenuView = createMenuView;

        this.setTitle("Solved Kenken");
        this.setSize(768, 768);
        this.setLayout(new BorderLayout());

        currentBoard = this.ctrlPresentation.getCurrentBoard();
        this.ctrlPresentation.solveBoard();

        initializeComponents();

        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null);
        this.setVisible(true);
    }

    /**
     * Initializes the components of the view.
     */
    private void initializeComponents() {

        initTopPanel();
        initCenterPanel();
    }

    /**
     * Initializes the center panel of the SolvedKenkenView.
     * This method creates a grid of cells representing the Kenken board,
     * sets the font size of the number labels based on the size of the board,
     * sets the cell values and region information, and applies borders to the cells.
     */
    private void initCenterPanel() {

        int size = currentBoard.getSize();
        int numRegions = currentBoard.getNumRegions();
        boolean[] isRegionChecked = new boolean[numRegions];

        centerPanel = new JPanel(new GridLayout(size, size));
        


        for (int i = 0; i < size; ++i) {
            for (int j = 0; j < size; ++j) {

                JPanel cell = new JPanel(new BorderLayout());
                int cellRegion = currentBoard.getRegId(i,j);

                JLabel numberLabel = new JLabel();
                switch (size) {
                    case 3:
                        numberLabel.setFont(new Font("Arial", Font.PLAIN, 50));
                        break;
                    case 4:
                        numberLabel.setFont(new Font("Arial", Font.PLAIN, 40));
                        break;
                    case 5:
                        numberLabel.setFont(new Font("Arial", Font.PLAIN, 33));
                        break;
                    case 6:
                        numberLabel.setFont(new Font("Arial", Font.PLAIN, 28));
                        break;
                    case 7:
                        numberLabel.setFont(new Font("Arial", Font.PLAIN, 25));
                        break;
                    case 8:
                        numberLabel.setFont(new Font("Arial", Font.PLAIN, 22));
                        break;
                    case 9:
                        numberLabel.setFont(new Font("Arial", Font.PLAIN, 20));
                        break;
                }
                numberLabel.setHorizontalAlignment(SwingConstants.CENTER);
                numberLabel.setVerticalAlignment(SwingConstants.CENTER);

                int cellValue = currentBoard.getCellValue(i, j); 
                numberLabel.setText(String.valueOf(cellValue));
                
                cell.add(numberLabel, BorderLayout.CENTER);

                if (!isRegionChecked[cellRegion]) {

                    isRegionChecked[cellRegion] = true;

                    char regionOp = currentBoard.getRegionOp(cellRegion);
                    int regionResult = currentBoard.getRegionResult(cellRegion);

                    JPanel topLeftPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 4, 4));
                    topLeftPanel.setOpaque(false);
                    JLabel label = new JLabel(String.valueOf(regionOp) + regionResult); //this will be region info
                    label.setOpaque(false);
                    switch (size) {
                        case 3:
                            label.setFont(new Font("Arial", Font.BOLD, 20));
                            break;
                        case 4:
                            label.setFont(new Font("Arial", Font.BOLD, 19));
                            break;
                        case 5:
                            label.setFont(new Font("Arial", Font.BOLD, 18));
                            break;
                        case 6:
                            label.setFont(new Font("Arial", Font.BOLD, 17));
                            break;
                        case 7:
                            label.setFont(new Font("Arial", Font.BOLD, 16));
                            break;
                        case 8:
                            label.setFont(new Font("Arial", Font.BOLD, 11));
                            break;
                        case 9:
                            label.setFont(new Font("Arial", Font.BOLD, 11));
                            break;
                    }
                    topLeftPanel.add(label);                    
                    cell.add(topLeftPanel, BorderLayout.NORTH);
                }

                MatteBorder fullBorder = new MatteBorder(i == 0 ? 5 : 1, j == 0 ? 5 : 1,(i+1 < size) ? 1 : 5 ,(j+1 < size) ? 1 : 5,Color.BLACK);
                MatteBorder rightBorder = new MatteBorder(0,0,0,(j+1 < size && currentBoard.getRegId(i, j) != currentBoard.getRegId(i,j+1)) ? 4 : 0,Color.BLACK);
                MatteBorder bottomBorder = new MatteBorder(0,0,(i+1 < size && currentBoard.getRegId(i, j) != currentBoard.getRegId(i+1,j)) ? 4 : 0, 0, Color.BLACK);
                Border border = BorderFactory.createCompoundBorder(fullBorder, BorderFactory.createCompoundBorder(rightBorder, bottomBorder));
                cell.setBorder(border);

                centerPanel.add(cell);
            }
        }
        centerPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        centerPanel.setBackground(new Color(249,249,249));
        SolvedKenkenView.this.add(centerPanel, BorderLayout.CENTER);;
    }

    /**
     * Initializes the top panel of the SolvedKenkenView.
     * This panel contains a "Back" button and an "Exit" button.
     * The "Back" button returns to the menu view and disposes the current view.
     * The "Exit" button exits the application.
     */
    private void initTopPanel() {

        buttonBack = new JButton("Back");
        buttonBack.setBackground(Color.WHITE);
        topPanel = new JPanel(new BorderLayout());
        topPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        topPanel.setBackground(new Color(2,136,209));
        topPanel.add(buttonBack, BorderLayout.WEST);

        buttonBack.addActionListener(e -> {
            this.createMenuView.setVisible(true);
            dispose();
        });

        buttonExit = new JButton("Exit");
        buttonExit.setBackground(Color.WHITE);
        topPanel.add(buttonExit, BorderLayout.EAST);
        buttonExit.addActionListener(e-> {
            System.exit(0);
        });

        SolvedKenkenView.this.add(topPanel, BorderLayout.NORTH);

    }
}
