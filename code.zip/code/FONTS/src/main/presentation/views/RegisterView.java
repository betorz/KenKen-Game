package main.presentation.views;

import java.awt.event.ActionListener;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import main.domain.classes.exceptions.ExceptionUser;
import main.presentation.controllers.CtrlPresentation;

public class RegisterView extends JFrame {
    private CtrlPresentation ictrlPresentation;
    private MainView mainView;

    private JTextField txtUser;
    private JPasswordField txtPassword;
    private JPasswordField txtPassword2;
    private JButton buttonRegister;
    private JPanel mainpanel;
    private JButton buttonBack;
    private JButton buttonExit;
    private JPanel centerPanel;
    private GridBagConstraints c;
    private JPanel topPanel;

    /**
     * Represents a view for user registration.
     * This view allows users to register for an account.
     */
    public RegisterView(CtrlPresentation pctrlPresentation, MainView mainView) {
        ictrlPresentation = pctrlPresentation;
        this.mainView = mainView;
        initializeComponents();
    }


    /**
     * Initializes the components of the RegisterView.
     * This method sets up the user interface components such as text fields, buttons, panels, and event listeners.
     * It also configures the appearance and behavior of the components.
     */
    public void initializeComponents() {
        txtUser = new JTextField(15);
        txtPassword = new JPasswordField(15);
        txtPassword2 = new JPasswordField(15);
        buttonRegister = new JButton("Register");
        mainpanel = new JPanel(new BorderLayout());
        buttonBack = new JButton("Back");
        buttonExit = new JButton("Exit");
        centerPanel = new JPanel(new GridBagLayout());
        c = new GridBagConstraints();
        topPanel = new JPanel(new BorderLayout());

        setTitle("Register");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(768, 576);
        setResizable(false);
        setLocationRelativeTo(null);

        mainpanel.setBackground(new Color(249, 249, 249));
        centerPanel.setBackground(new Color(249, 249, 249));
        c.insets = new Insets(10, 10, 10, 10);
        c.gridx = 0;
        c.gridy = 0;
        c.anchor = GridBagConstraints.WEST;

        ictrlPresentation.configureTextField(txtUser);
        ictrlPresentation.configureTextField(txtPassword);
        ictrlPresentation.configureTextField(txtPassword2);

        centerPanel.add(ictrlPresentation.configureLabel("User: ", 20), c);
        c.gridx++;
        centerPanel.add(txtUser, c);

        c.gridx = 0;
        c.gridy++;
        centerPanel.add(ictrlPresentation.configureLabel("Password: ", 20), c);
        c.gridx++;
        centerPanel.add(txtPassword, c);

        c.gridx = 0;
        c.gridy++;
        centerPanel.add(ictrlPresentation.configureLabel("Repeat password: ", 20), c);
        c.gridx++;
        centerPanel.add(txtPassword2, c);

        c.gridx = 0;
        c.gridy++;
        c.gridwidth = 2;
        c.anchor = GridBagConstraints.CENTER;
        buttonRegister.setFont(new Font("Arial", Font.PLAIN, 22));
        buttonRegister.setBackground(Color.WHITE);
        buttonRegister.setPreferredSize(new Dimension(200, 50));
        centerPanel.add(buttonRegister, c);

        topPanel.setBackground(new Color(2, 136, 209));
        topPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        buttonBack.setBackground(Color.WHITE);
        buttonBack.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                mainView.setVisible(true);
                dispose();
            }
        });
        topPanel.add(buttonBack, BorderLayout.WEST);

        buttonExit.setBackground(Color.WHITE);
        buttonExit.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
        topPanel.add(buttonExit, BorderLayout.EAST);

        mainpanel.add(topPanel, BorderLayout.NORTH);
        mainpanel.add(centerPanel, BorderLayout.CENTER);

        buttonRegister.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    ictrlPresentation.register(txtUser.getText(), new String(txtPassword.getPassword()), new String(txtPassword2.getPassword()));
                    mainView.setVisible(true);
                    dispose();
                } catch (ExceptionUser ex) {
                    JOptionPane.showMessageDialog(null, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        add(mainpanel);
    }
}
