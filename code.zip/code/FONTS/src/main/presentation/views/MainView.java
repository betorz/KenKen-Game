package main.presentation.views;

import javax.swing.*;
import main.presentation.controllers.*;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Represents the main view of the application.
 * This view is responsible for displaying the user interface and handling user interactions.
 */
public class MainView extends JFrame {
    private CtrlPresentation ictrlPresentation;
    private JLabel labelTitle;
    private JButton buttonRegister;
    private JButton buttonLogin;
    private JButton buttonExit;
    private JPanel buttonPanel;
    private JPanel topPanel;
    private JLabel imageLabel;
    private ImageIcon imageIcon;
    private Image scaledImage;

    /**
     * Represents the main view of the application.
     * This view is responsible for displaying the user interface and handling user interactions.
     */
    public MainView(CtrlPresentation pctrlPresentation) {
        ictrlPresentation = pctrlPresentation;
        initializeComponents();
    }

    /**
     * Initializes the components of the MainView.
     * This method sets up the labels, buttons, panels, and layout of the MainView.
     * It also configures the title, size, location, and background color of the MainView frame.
     * Additionally, it adds event listeners to the exit, register, and login buttons.
     */
    private void initializeComponents() {
        labelTitle = new JLabel("KenKen", SwingConstants.CENTER);
        buttonRegister = new JButton("Register");
        buttonLogin = new JButton("Login");
        buttonExit = new JButton("Exit");
        buttonPanel = new JPanel(new GridLayout(1, 2, 50, 0));
        topPanel = new JPanel(new BorderLayout());
        imageLabel = new JLabel();
        imageIcon = new ImageIcon("./main/presentation/views/resources/kenken.png");
        scaledImage = imageIcon.getImage().getScaledInstance(300, 300, Image.SCALE_SMOOTH);


        setTitle("KenKen");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(768, 576);
        setLocationRelativeTo(null);
        setResizable(false); 
        
        setLayout(new BorderLayout());
        getContentPane().setBackground(new Color(0, 0, 0));

        labelTitle.setFont(new Font("Arial", Font.BOLD, 50));
        labelTitle.setForeground(Color.WHITE);
        labelTitle.setHorizontalAlignment(SwingConstants.CENTER);

        topPanel.setBackground(new Color(2,136,209));
        topPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        topPanel.add(labelTitle, BorderLayout.SOUTH);
        buttonExit.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
        buttonExit.setBackground(Color.WHITE);
        topPanel.add(buttonExit, BorderLayout.EAST);
        add(topPanel, BorderLayout.NORTH);

        JPanel imagePanel = new JPanel();
        imageIcon.setImage(scaledImage);
        imageLabel.setIcon(imageIcon);
        imageLabel.setHorizontalAlignment(SwingConstants.CENTER);
        imagePanel.add(imageLabel, BorderLayout.CENTER);
        imagePanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        imagePanel.setBackground(new Color(249, 249, 249));
        add(imagePanel, BorderLayout.CENTER);

        buttonPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        buttonPanel.setBackground(new Color(249, 249, 249));
            
        buttonRegister.setFont(new Font("Arial", Font.PLAIN, 20));
        buttonRegister.setBackground(Color.WHITE);
        buttonRegister.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new RegisterView(ictrlPresentation, MainView.this).setVisible(true);
                dispose();
            }
        });
        buttonPanel.add(buttonRegister);

        buttonLogin.setFont(new Font("Arial", Font.PLAIN, 20));
        buttonLogin.setPreferredSize(new Dimension(150, 50));
        buttonLogin.setBackground(Color.WHITE);
        buttonLogin.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new LoginView(ictrlPresentation, MainView.this).setVisible(true);
                dispose();
            }
        });
        buttonPanel.add(buttonLogin);
        add(buttonPanel, BorderLayout.SOUTH);
    }
}


