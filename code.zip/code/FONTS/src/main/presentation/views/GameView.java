package main.presentation.views;

import main.domain.classes.Board;
import main.domain.classes.Pair;
import main.domain.classes.exceptions.ExceptionGame;
import main.domain.classes.exceptions.ExceptionUser;
import main.presentation.controllers.CtrlPresentation;

import javax.swing.*;
import javax.swing.border.*;

import java.awt.*;
import java.awt.event.*;
import java.util.List;
import java.util.ArrayList;

/**
 * The GameView class represents the graphical user interface for the game screen.
 * It extends the JFrame class and provides methods to initialize the game grid,
 * handle user input, and manage the top panel.
 */
public class GameView extends JFrame {

    int numRegions;
    int size;
    boolean[] isRegionChecked;
    Board currentBoard;
    int elapsedTime;
    List<Pair<Pair<Integer,Integer>,Integer>> undoArray; //pos and last value 


    private CtrlPresentation ctrlPresentation;
    private Object backObject;
    private JButton buttonBack;
    private JPanel topPanel;
    private JLabel time;
    Timer timer;
    private JPanel gameGrid;
    private JPanel bottomPanel;
    private JPanel rightPanel;
    private JButton getHintButton;
    private JButton undoButton;
    private JButton restartButton;
    private JPanel leftPanel;

    /**
     * Represents the game view of the application.
     * This view displays the game screen and handles user interactions.
     *
     * @param ctrlPresentation The controller for the presentation layer.
     * @param backObject The object representing the previous screen.
     */
    public GameView(CtrlPresentation ctrlPresentation, Object backObject) {

        this.ctrlPresentation = ctrlPresentation;
        this.backObject = backObject;

        currentBoard = this.ctrlPresentation.getCurrentBoard(); 
        size = currentBoard.getSize();
        numRegions = currentBoard.getNumRegions();
        isRegionChecked = new boolean[numRegions];
        elapsedTime = (int) (this.ctrlPresentation.getTime() / 1000);
        undoArray = new ArrayList<>(); 

        this.setTitle("Game Screen");
        this.setSize(768, 768);

        initializeComponents();

        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null);
        this.setVisible(true);

    }

    /**
     * Initializes the game grid by creating and configuring the necessary components.
     * This method sets up the layout, fonts, labels, event listeners, and borders for each cell in the grid.
     * It also populates the grid with numbers and region information based on the current board state.
     */
    public void initGameGrid() {
        gameGrid = new JPanel(new GridLayout(size, size));

        for (int i = 0; i < size; ++i) {
            for (int j = 0; j < size; ++j) {

                JPanel cell = new JPanel(new BorderLayout());
                int cellRegion = currentBoard.getRegId(i,j);

                JLabel numberLabel = new JLabel();
                switch (size) {
                    case 3:
                        numberLabel.setFont(new Font("Arial", Font.PLAIN, 50));
                        break;
                    case 4:
                        numberLabel.setFont(new Font("Arial", Font.PLAIN, 40));
                        break;
                    case 5:
                        numberLabel.setFont(new Font("Arial", Font.PLAIN, 33));
                        break;
                    case 6:
                        numberLabel.setFont(new Font("Arial", Font.PLAIN, 28));
                        break;
                    case 7:
                        numberLabel.setFont(new Font("Arial", Font.PLAIN, 25));
                        break;
                    case 8:
                        numberLabel.setFont(new Font("Arial", Font.PLAIN, 22));
                        break;
                    case 9:
                        numberLabel.setFont(new Font("Arial", Font.PLAIN, 20));
                        break;
                }
                numberLabel.setHorizontalAlignment(SwingConstants.CENTER);
                numberLabel.setVerticalAlignment(SwingConstants.CENTER);
                numberLabel.putClientProperty("row", i);
                numberLabel.putClientProperty("col", j);

                int cellValue = currentBoard.getCellValue(i, j);
                if (cellValue != 0 && cellValue != -1) {
                    numberLabel.setText(String.valueOf(cellValue));
                }
                cell.add(numberLabel, BorderLayout.CENTER);

                if (!isRegionChecked[cellRegion]) {

                    isRegionChecked[cellRegion] = true;

                    char regionOp = currentBoard.getRegionOp(cellRegion);
                    int regionResult = currentBoard.getRegionResult(cellRegion);

                    JPanel topLeftPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 4, 4));
                    topLeftPanel.setOpaque(false);
                    JLabel label = new JLabel(String.valueOf(regionOp) + regionResult); //this will be region info
                    label.setOpaque(false);
                    switch (size) {
                        case 3:
                            label.setFont(new Font("Arial", Font.BOLD, 20));
                            break;
                        case 4:
                            label.setFont(new Font("Arial", Font.BOLD, 19));
                            break;
                        case 5:
                            label.setFont(new Font("Arial", Font.BOLD, 18));
                            break;
                        case 6:
                            label.setFont(new Font("Arial", Font.BOLD, 17));
                            break;
                        case 7:
                            label.setFont(new Font("Arial", Font.BOLD, 16));
                            break;
                        case 8:
                            label.setFont(new Font("Arial", Font.BOLD, 11));
                            break;
                        case 9:
                            label.setFont(new Font("Arial", Font.BOLD, 11));
                            break;
                    }
                    topLeftPanel.add(label);                    
                    cell.add(topLeftPanel, BorderLayout.NORTH);
                }

                int row = i;
                int col = j;

                cell.addMouseListener(new MouseAdapter() {
                    @Override
                    public void mouseClicked(MouseEvent e) {
                        SwingUtilities.invokeLater(new Runnable() {
                            @Override
                            public void run() {
                                numberLabel.requestFocusInWindow();
                            }
                        });
                    }
                });

                numberLabel.addKeyListener(new KeyAdapter() {
                    @Override
                    public void keyPressed(KeyEvent e) {
                        if (e.getKeyCode() == KeyEvent.VK_BACK_SPACE) {
                            undoArray.add(new Pair<>(new Pair<>(row, col), numberLabel.getText() != "" ? Integer.parseInt(numberLabel.getText()) : 0));
                            numberLabel.setText("");
                            currentBoard.modifyCellValue(0, row, col);
                            validateGameBoard();
                        }
                        else {
                            char c = e.getKeyChar();
                        
                            if (Character.isDigit(c)) {
                                
                                int value = Character.getNumericValue(c);
                                if (value >= 1 && value <= size) { 
                                    undoArray.add(new Pair<>(new Pair<>(row, col), numberLabel.getText() != "" ? Integer.parseInt(numberLabel.getText()) : 0));
                                    moveHandler(row, col, value, numberLabel);
                                }
                                else {
                                    Toolkit.getDefaultToolkit().beep();
                                }
                            }
                            else {
                                Toolkit.getDefaultToolkit().beep();
                            }
                        }
                    }
                });

                numberLabel.addFocusListener(new FocusAdapter() {
                    @Override
                    public void focusGained(FocusEvent e) {
                        cell.setBackground(new Color(211,211,211));
                    }

                    @Override
                    public void focusLost(FocusEvent e) {
                        cell.setBackground(new Color(249,249,249));
                    }
                });


                MatteBorder fullBorder = new MatteBorder(i == 0 ? 5 : 1, j == 0 ? 5 : 1,(i+1 < size) ? 1 : 5 ,(j+1 < size) ? 1 : 5,Color.BLACK);
                MatteBorder rightBorder = new MatteBorder(0,0,0,(j+1 < size && currentBoard.getRegId(i, j) != currentBoard.getRegId(i,j+1)) ? 4 : 0,Color.BLACK);
                MatteBorder bottomBorder = new MatteBorder(0,0,(i+1 < size && currentBoard.getRegId(i, j) != currentBoard.getRegId(i+1,j)) ? 4 : 0, 0, Color.BLACK);
                Border border = BorderFactory.createCompoundBorder(fullBorder, BorderFactory.createCompoundBorder(rightBorder, bottomBorder));
                cell.setBorder(border);

                gameGrid.add(cell);
            }
        }
        gameGrid.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));
        gameGrid.setBackground(new Color(249, 249, 249));
        GameView.this.add(gameGrid, BorderLayout.CENTER);
    }

    /**
     * Initializes the top panel of the game view.
     * This panel contains a back button, a timer, and other components.
     * The back button allows the user to navigate back to the previous view.
     * The timer displays the elapsed time during the game.
     */
    public void initTopPanel() {
        buttonBack = new JButton("Back");
        buttonBack.setBackground(Color.WHITE);

        topPanel = new JPanel(new BorderLayout());
        topPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 10, 20));
        topPanel.setBackground(new Color(2, 136, 209));
        topPanel.add(buttonBack, BorderLayout.WEST);

        buttonBack.addActionListener(e -> {
            this.timer.stop();
            this.ctrlPresentation.stopPlaying();
            if (backObject instanceof LevelSelectorView) {
                ((LevelSelectorView) this.backObject).repaint();
                ((LevelSelectorView) this.backObject).revalidate();
                ((LevelSelectorView) this.backObject).setVisible(true);
                
            }
            else if (backObject instanceof CreateMenuView) {
    
                ((CreateMenuView) this.backObject).setVisible(true);
            }
            
            dispose();
        });

        time = new JLabel();
        time.setFont(new Font("Arial", Font.BOLD, 16));
        time.setForeground(Color.WHITE);
        topPanel.add(time, BorderLayout.EAST);
        updateTime();

        timer = new Timer(1000, new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                updateTime();
            }
        });
        timer.start();

        GameView.this.add(topPanel, BorderLayout.NORTH);
    }


    /**
     * Initializes the bottom panel of the game view.
     * This panel contains a grid of number buttons used for gameplay.
     */
    private void initBottomPanel() {
        bottomPanel = new JPanel(new GridLayout(1,size, 5, 0));
        bottomPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        bottomPanel.setBackground(new Color(249, 249, 249));

        for (int i = 1; i <= size; ++i) {
             JButton numberButton = new JButton(String.valueOf(i)) {
                @Override
                public Dimension getPreferredSize() {
                    Dimension size = super.getPreferredSize();
                    int newDimension = size.width;
                    return new Dimension(newDimension, newDimension);
                }
            };
            numberButton.setBackground(Color.WHITE);
            numberButton.setFocusable(false);
            numberButton.setFont(new Font("Arial", Font.PLAIN, 20));
            numberButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {

                        String buttonText = numberButton.getText();

                        Component focusedComponent = KeyboardFocusManager.getCurrentKeyboardFocusManager().getFocusOwner();
                        if (focusedComponent instanceof JLabel) {
                            JLabel label = (JLabel) focusedComponent;
                            int row = (int) label.getClientProperty("row");
                            int col = (int) label.getClientProperty("col");
                            undoArray.add(new Pair<>(new Pair<>(row, col), label.getText() != "" ? Integer.parseInt(label.getText()) : 0));
                            moveHandler(row, col, Integer.parseInt(buttonText), label);
                        }
                }
            });
            bottomPanel.add(numberButton);
        }
        GameView.this.add(bottomPanel, BorderLayout.SOUTH);

    }

    /**
     * Initializes the right panel of the game view.
     * This panel contains buttons for getting hints, undoing moves, and restarting the game.
     */
    private void initRightPanel() {

        rightPanel = new JPanel(new GridLayout(3, 1,0,5));
        rightPanel.setBackground(new Color(249, 249, 249));
        getHintButton = new JButton("Get Hint");
        getHintButton.setBackground(Color.WHITE);
        getHintButton.setFont(new Font("Arial", Font.PLAIN, 16));
        getHintButton.setFocusable(false);
        undoButton = new JButton("Undo");
        undoButton.setBackground(Color.WHITE);
        undoButton.setFont(new Font("Arial", Font.PLAIN, 16));
        undoButton.setFocusable(false);
        restartButton = new JButton("Restart");
        restartButton.setBackground(Color.WHITE);
        restartButton.setFont(new Font("Arial", Font.PLAIN, 16));
        restartButton.setFocusable(false);

        undoButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (!undoArray.isEmpty()) {
                    Pair<Pair<Integer, Integer>, Integer> posVal = undoArray.get(undoArray.size()-1);
                    int row = posVal.getX().getX();
                    int col = posVal.getX().getY();
                    int val = posVal.getY();

                    int panelId = row * size + col;
                    JLabel numberLabel = ((JLabel) ((JPanel) gameGrid.getComponent(panelId)).getComponent(0));
                    if (val == 0) {
                        numberLabel.setText("");
                    } else {
                        numberLabel.setText(String.valueOf(val));
                    }
                    currentBoard.modifyCellValue(val, row, col);
                    undoArray.remove(undoArray.size()-1);
                    validateGameBoard();
                }   
            }
        });

        restartButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                for (int i = 0; i < size; ++i) {
                    for (int j = 0; j < size; ++j) {
                        currentBoard.clearCellValue(i, j);
                        int panelId = i*size + j; 
                        JLabel numberLabel = ((JLabel) ((JPanel) gameGrid.getComponent(panelId)).getComponent(0));
                        numberLabel.setText("");
                    }
                }
                undoArray.clear(); 
                validateGameBoard();
            }
        });

        getHintButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Pair<Integer, Integer> pos = ctrlPresentation.getHint();
                int panelId = pos.getX() * size + pos.getY();
                JLabel numberLabel = ((JLabel) ((JPanel) gameGrid.getComponent(panelId)).getComponent(0));
        
                undoArray.add(new Pair<>(new Pair<>(pos.getX(), pos.getY()), numberLabel.getText() != "" ? Integer.parseInt(numberLabel.getText()) : 0));
                paintBoard(pos);
                checkIfFinished();
                validateGameBoard();

            }
        });

        rightPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        rightPanel.add(getHintButton);
        rightPanel.add(undoButton);
        rightPanel.add(restartButton);

        GameView.this.add(rightPanel, BorderLayout.EAST);

    }

    /**
     * Initializes the components of the game view.
     * This method initializes the game grid, top panel, bottom panel, right panel, and left panel.
     * The left panel is added to the game view's west border layout.
     */
    public void initializeComponents() {
        initGameGrid();
        initTopPanel();
        initBottomPanel();
        initRightPanel();
        leftPanel = new JPanel();
        leftPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        leftPanel.setBackground(new Color(249, 249, 249));
        GameView.this.add(leftPanel, BorderLayout.WEST);
    }

    /**
     * Handles the move operation in the game.
     * 
     * @param row   The row index of the move.
     * @param col   The column index of the move.
     * @param value The value to be placed in the specified position.
     * @param label The label to update with the new value.
     */
    private void moveHandler(int row, int col, int value, JLabel label) {
        try {
            ctrlPresentation.makeMove(row, col, value);
            label.setText(String.valueOf(value));
            validateGameBoard();
        } catch (ExceptionGame ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
        checkIfFinished();
    }
    
    /**
     * Validates the game board by checking for errors in each cell.
     * If a cell contains a non-zero value, it highlights the row and column errors
     * and also highlights the region errors for that cell.
     * If a cell contains a zero value, it resets the cell color.
     */
    private void validateGameBoard() {
        for (int row = 0; row < size; row++) {
            for (int col = 0; col < size; col++) {
                int value = currentBoard.getCellValue(row, col);
                if (value != 0) {
                    highlightRowAndColumnErrors(row, col, value);
                    highlightRegionErrors(row, col);
                } else {
                    resetCellColor(row, col); 
                }
            }
        }
    }

    
    /**
     * Highlights any row and column errors in the game view.
     * 
     * @param row   the row index of the cell to check for conflicts
     * @param col   the column index of the cell to check for conflicts
     * @param value the value to check for conflicts in the row and column
     */
    private void highlightRowAndColumnErrors(int row, int col, int value) {
        boolean rowConflict = false;
        boolean colConflict = false;
    
        for (int i = 0; i < size; i++) {
            JLabel labelRow = getLabelAt(row, i);
            if (i != col && labelRow.getText().equals(String.valueOf(value))) {
                rowConflict = true;
            }
        }
    
        for (int i = 0; i < size; i++) {
            JLabel labelCol = getLabelAt(i, col);
            if (i != row && labelCol.getText().equals(String.valueOf(value))) {
                colConflict = true;
            }
        }
    
        applyCellColor(row, col, rowConflict, colConflict, false);
    }
    
    
    /**
     * Highlights the cells in the region of the specified row and column, indicating any errors in the region.
     * An error in the region occurs if the operation rule is violated.
     *
     * @param row The row index of the cell.
     * @param col The column index of the cell.
     */
    private void highlightRegionErrors(int row, int col) {
        List<Pair<Integer, Integer>> regionCells = getRegionCells(row, col);
        boolean regionConflict = !ctrlPresentation.checkOpRule(row, col);
    
        for (Pair<Integer, Integer> cell : regionCells) {
            JLabel label = getLabelAt(cell.getX(), cell.getY());
            boolean rowConflict = label.getParent().getBackground().equals(Color.RED) || label.getParent().getBackground().equals(new Color(255, 165, 0));
            boolean colConflict = label.getParent().getBackground().equals(Color.RED) || label.getParent().getBackground().equals(new Color(255, 165, 0));
            applyCellColor(cell.getX(), cell.getY(), rowConflict, colConflict, regionConflict);
        }
    }
    

    
    /**
     * Applies the appropriate color to a cell in the game grid based on the conflicts present.
     * 
     * @param row the row index of the cell
     * @param col the column index of the cell
     * @param rowConflict indicates if there is a conflict in the row
     * @param colConflict indicates if there is a conflict in the column
     * @param regionConflict indicates if there is a conflict in the region
     */
    private void applyCellColor(int row, int col, boolean rowConflict, boolean colConflict, boolean regionConflict) {
        JPanel cellPanel = (JPanel) gameGrid.getComponent(row * size + col);
    
        if (rowConflict && regionConflict || colConflict && regionConflict) {
            cellPanel.setBackground(new Color(255, 165, 0)); 
        } else if (regionConflict) {
            cellPanel.setBackground(Color.ORANGE);
        } else if (rowConflict || colConflict) {
            cellPanel.setBackground(Color.RED);
        } else {
            cellPanel.setBackground(Color.WHITE); 
        }
    }

    /**
     * Resets the background color of a specific cell in the game grid.
     *
     * @param row the row index of the cell
     * @param col the column index of the cell
     */
    private void resetCellColor(int row, int col) {
        JPanel cellPanel = (JPanel) gameGrid.getComponent(row * size + col);
        cellPanel.setBackground(new Color(249,249,249)); 
    }
    
    /**
        * Returns the JLabel component at the specified row and column in the game grid.
        *
        * @param row the row index of the desired JLabel component
        * @param col the column index of the desired JLabel component
        * @return the JLabel component at the specified row and column
        */
    private JLabel getLabelAt(int row, int col) {
        JPanel cellPanel = (JPanel) gameGrid.getComponent(row * size + col);
        return (JLabel) cellPanel.getComponent(0);
    }

    /**
     * Returns a list of cells in the same region as the specified cell.
     *
     * @param row the row index of the specified cell
     * @param col the column index of the specified cell
     * @return a list of Pair objects representing the row and column indices of the cells in the same region
     */
    private List<Pair<Integer, Integer>> getRegionCells(int row, int col) {
        List<Pair<Integer, Integer>> regionCells = new ArrayList<>();
        int targetRegionId = currentBoard.getRegId(row, col);
    
        for (int r = 0; r < size; r++) {
            for (int c = 0; c < size; c++) {
                if (currentBoard.getRegId(r, c) == targetRegionId) {
                    regionCells.add(new Pair<>(r, c));
                }
            }
        }
        return regionCells;
    }

    /**
     * Checks if the game is finished by calling the checkSolution method of the Presentation Controller.
     * If the solution is correct, it stops the timer, finishes the game, and displays a congratulatory message.
     * If the backObject is an instance of LevelSelectorView or CreateMenuView, it sets the visibility of the backObject to true.
     * Finally, it disposes the current GameView.
     */
    private void checkIfFinished() {
        if (this.ctrlPresentation.checkSolution()) {
            this.timer.stop();
            try {
                this.ctrlPresentation.finishGame();
            } catch (ExceptionUser e) {
                JOptionPane.showMessageDialog(null, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
            JOptionPane.showMessageDialog(null, 
                                      "Congratulations! You won the game!",  
                                      "Game Over", 
                                      JOptionPane.INFORMATION_MESSAGE);
            if (backObject instanceof LevelSelectorView) {
                ((LevelSelectorView) this.backObject).setVisible(true);
            }
            else if (backObject instanceof CreateMenuView) {
                ((CreateMenuView) this.backObject).setVisible(true);
            }
            dispose();
        }
    }

    /**
     * Paints the board by updating the number label at the specified position with the cell value from the current board.
     * 
     * @param pos The position of the cell on the board.
     */
    private void paintBoard(Pair<Integer, Integer> pos) {

        int panelId = pos.getX() * size + pos.getY();

        JLabel numberLabel = ((JLabel) ((JPanel) gameGrid.getComponent(panelId)).getComponent(0));

        int cellValue = currentBoard.getCellValue(pos.getX(), pos.getY());
        if (cellValue != 0 && cellValue != -1) {
            numberLabel.setText(String.valueOf(cellValue));
        }
            
    }

    /**
     * Updates the time displayed in the game view.
     * The time is formatted as minutes:seconds.
     * The elapsed time is incremented by one second.
     */
    protected void updateTime() {
        int seconds = elapsedTime % 60;
        int minutes = elapsedTime/60;
        time.setText(String.format("%02d:%02d", minutes, seconds));    
        ++elapsedTime;
    }
}