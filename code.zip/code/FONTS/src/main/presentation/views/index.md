# Projecte KenKen - Presentació - Views

Aquest directori conté les vistes del projecte KenKen. Aquestes classes s'encarreguen de la interfície gràfica d'usuari (GUI) i de la interacció amb l'usuari. A continuació es descriu breument el propòsit de cada fitxer i les classes que conté.

## Fitxers i Classes

1. **CreateMenuView.java**
   - Classe que gestiona la vista per crear un nou menú.

2. **SolvedKenkenView.java**
   - Classe que mostra la vista del KenKen resolt.

3. **StatsView.java**
   - Classe que gestiona la vista de les estadístiques del joc.

4. **MainView.java**
   - Classe principal de la vista que gestiona la interfície principal del joc.

5. **GameView.java**
   - Classe que gestiona la vista del joc KenKen.

6. **LevelSelectorView.java**
   - Classe que gestiona la vista de selecció de nivell.

7. **MenuView.java**
   - Classe que gestiona la vista del menú principal.

8. **RankingView.java**
   - Classe que gestiona la vista del rànquing del joc.

9. **RegisterView.java**
   - Classe que gestiona la vista de registre d'usuari.

10. **LoginView.java**
    - Classe que gestiona la vista de login d'usuari.

11. **MenuProfileManagementView.java**
    - Classe que gestiona la vista del menú de gestió de perfil.

12. **CreateGameView.java**
    - Classe que gestiona la vista per crear un nou joc.

## Altres Fitxers

### resources
- Aquest directori conté recursos addicionals per a les vistes. Per a més detalls, consulteu el fitxer `index.txt` dins de la carpeta `resources`.

