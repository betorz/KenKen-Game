package main.presentation.views;

import main.domain.classes.Stats;
import main.domain.classes.exceptions.ExceptionUser;
import main.presentation.controllers.CtrlPresentation;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

/**
 * Represents a view for displaying statistics.
 * This class extends the JFrame class and provides a graphical user interface for displaying various statistics.
 * The statistics are retrieved from the presentation controller and populated in different panels.
 * The user can navigate between different panels using buttons.
 * 
 * @param pctrlPresentation The presentation controller.
 * @param menuView The menu view.
 */
public class StatsView extends JFrame {

    private CtrlPresentation ictrlPresentation;
    private MenuView menuView;
    private Stats stats;

    private JLabel lblTitle;
    private JPanel topPanel;
    private JPanel centerPanel;
    private JButton buttonBack;
    private JButton buttonExit;
    private JPanel buttonPanel;

    private JPanel generalPanel;
    private JPanel solvedSizePanel;
    private JPanel solvedDifficultyPanel;
    private JPanel statsPanel;
    private JPanel timesPanel;

    private CardLayout cardLayout;

    private JButton buttonGeneral;
    private JButton buttonTimes;
    private JButton buttonSolvedBySize;
    private JButton buttonSolvedByDifficulty;

    /**
     * Represents a view for displaying statistics.
     * @param pctrlPresentation The presentation controller.
     * @param menuView The menu view.
     */
    public StatsView(CtrlPresentation pctrlPresentation, MenuView menuView) {
        this.ictrlPresentation = pctrlPresentation;
        this.menuView = menuView;
        initializeComponents();
    }

    /**
     * Initializes the components of the StatsView.
     * This method sets up the UI components, configures the frame, and adds event listeners to the buttons.
     * It also retrieves the statistics data and populates the panels with the corresponding information.
     */
    private void initializeComponents() {
        lblTitle = new JLabel(ictrlPresentation.getCurrentUsername() + "'s Statistics", SwingConstants.CENTER);
        topPanel = new JPanel(new BorderLayout());
        centerPanel = new JPanel(new BorderLayout());
        buttonBack = new JButton("Back");
        buttonBack.setBackground(Color.WHITE);
        buttonExit = new JButton("Exit");
        buttonExit.setBackground(Color.WHITE);

        buttonGeneral = new JButton("General");
        buttonGeneral.setBackground(Color.WHITE);
        buttonGeneral.setFont(new Font("Arial", Font.PLAIN, 15));
        buttonTimes = new JButton("Best Times");
        buttonTimes.setBackground(Color.WHITE);
        buttonTimes.setFont(new Font("Arial", Font.PLAIN, 15));
        buttonSolvedBySize = new JButton("# Solved by Size");
        buttonSolvedBySize.setBackground(Color.WHITE);
        buttonSolvedBySize.setFont(new Font("Arial", Font.PLAIN, 15));
        buttonSolvedByDifficulty = new JButton("# Solved by Difficulty");
        buttonSolvedByDifficulty.setBackground(Color.WHITE);
        buttonSolvedByDifficulty.setFont(new Font("Arial", Font.PLAIN, 15));

        cardLayout = new CardLayout();

        buttonPanel = new JPanel(new GridLayout(1, 4, 10, 0));
        generalPanel = new JPanel(new GridLayout(3, 1, 10, 10));
        timesPanel = new JPanel(new GridLayout(7, 4, 10, 10));
        solvedSizePanel = new JPanel(new GridLayout(7, 1, 10, 10));
        solvedDifficultyPanel = new JPanel(new GridLayout(4, 1, 10, 10));
        statsPanel = new JPanel(cardLayout);

        try {
            stats = ictrlPresentation.getStats();
        } catch (ExceptionUser e) {
            JOptionPane.showMessageDialog(null, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }

        setTitle("User Statistics");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(768, 576);
        setResizable(false);
        setLocationRelativeTo(null);
        getContentPane().setBackground(new Color(249, 249, 249));
        setLayout(new BorderLayout());

        lblTitle.setFont(new Font("Arial", Font.BOLD, 30));
        lblTitle.setForeground(Color.WHITE);
        topPanel.setBackground(new Color(2,136,209));
        topPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        topPanel.add(buttonBack, BorderLayout.WEST);
        topPanel.add(lblTitle, BorderLayout.SOUTH);
        topPanel.add(buttonExit, BorderLayout.EAST);
        add(topPanel, BorderLayout.NORTH);

        buttonBack.addActionListener(e -> {
            menuView.setVisible(true);
            dispose();
        });

        buttonExit.addActionListener(e -> {
            System.exit(0);
        });

        centerPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        centerPanel.setBackground(new Color(249,249,249));

        buttonPanel.setBackground(new Color(249,249,249));
        buttonPanel.add(buttonGeneral);
        buttonPanel.add(buttonTimes);
        buttonPanel.add(buttonSolvedBySize);
        buttonPanel.add(buttonSolvedByDifficulty);
        centerPanel.add(buttonPanel, BorderLayout.NORTH);
        centerPanel.add(statsPanel, BorderLayout.CENTER);

        generalPanel.setForeground(Color.WHITE);
        generalPanel.setBackground(new Color(249,249,249));
        generalPanel.add(ictrlPresentation.configureLabel("Points: " + stats.getPoints() + " points", 20));
        generalPanel.add(ictrlPresentation.configureLabel("Solved Percentage: " + stats.getSolvedPerc() + "%", 20));
        generalPanel.add(ictrlPresentation.configureLabel("Total Solved: " + stats.getSolved() + " kenkens", 20));
        statsPanel.add(generalPanel, "General");

        timesPanel.setBackground(new Color(249,249,249));
        String[] sizes = {"3x3", "4x4", "5x5", "6x6", "7x7", "8x8", "9x9"};
        String[] difficulties = {"Easy", "Medium", "Hard", "Expert"};
        for (int i = 0; i < 7; i++) {
            for (int j = 0; j < 4; j++) {
                if (stats.getTimes(i, j) == stats.MAX_TIME) {
                    timesPanel.add(ictrlPresentation.configureLabel(sizes[i] + " " + difficulties[j] + ": N/A", 15));
                } else {
                    timesPanel.add(ictrlPresentation.configureLabel(sizes[i] + " " + difficulties[j] + ": " + formatTime(stats.getTimes(i, j)), 15));
                }
            }
        }
        statsPanel.add(timesPanel, "Best Times");

        solvedSizePanel.setBackground(new Color(249,249,249));
        for (int i = 0; i < 7; i++) {
            solvedSizePanel.add(ictrlPresentation.configureLabel(sizes[i] + ": " + stats.getSolvedSize()[i] + " kenkens", 18));
        }
        statsPanel.add(solvedSizePanel, "# Solved by Size");

        solvedDifficultyPanel = new JPanel(new GridLayout(4, 1, 5, 5));
        solvedDifficultyPanel.setBackground(new Color(249, 249, 249));
        for (int i = 0; i < 4; i++) {
            solvedDifficultyPanel.add(ictrlPresentation.configureLabel(difficulties[i] + ": " + stats.getSolvedDifficulty()[i] + " kenkens", 18));
        }
        statsPanel.add(solvedDifficultyPanel, "# Solved by Difficulty");

        add(centerPanel, BorderLayout.CENTER);

        buttonGeneral.addActionListener(this::showPanel);
        buttonTimes.addActionListener(this::showPanel);
        buttonSolvedBySize.addActionListener(this::showPanel);
        buttonSolvedByDifficulty.addActionListener(this::showPanel);

        showPanel(new ActionEvent(buttonGeneral, ActionEvent.ACTION_PERFORMED, null));
    }

    /**
     * Displays the specified panel based on the button that is clicked.
     * 
     * @param e the ActionEvent representing the button click
     */
    private void showPanel(ActionEvent e) {
        JButton clickedButton = (JButton) e.getSource();
        String panelName = clickedButton.getText();

        buttonGeneral.setEnabled(true);
        buttonTimes.setEnabled(true);
        buttonSolvedBySize.setEnabled(true);
        buttonSolvedByDifficulty.setEnabled(true);
        clickedButton.setEnabled(false);

        cardLayout.show(statsPanel, panelName);
    }

    /**
     * Formats the given time in milliseconds into a string representation.
     *
     * @param timeInMilliseconds the time to format in milliseconds
     * @return the formatted time as a string
     */
    private String formatTime(long timeInMilliseconds) {
        if (timeInMilliseconds < 60000) {  
            return String.format("%.2f", timeInMilliseconds / 1000.0) + "s";
        } else {
            long totalSeconds = timeInMilliseconds / 1000; 
            long minutes = totalSeconds / 60;             
            long seconds = totalSeconds % 60;             
    
            return String.format("%dm %02ds", minutes, seconds);
        }
    }
}
