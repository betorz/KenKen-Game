package main.presentation.views;

import java.awt.event.ActionListener;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import main.domain.classes.exceptions.ExceptionUser;
import main.presentation.controllers.CtrlPresentation;

/**
 * Represents the login view of the application.
 * This view allows users to log in to the system.
 */
public class LoginView extends JFrame {

    private CtrlPresentation ictrlPresentation;
    private MainView mainView;

    private JTextField txtUser;
    private JPasswordField txtPassword;
    private JButton buttonLogin;
    private JPanel mainpanel;
    private JButton buttonBack;
    private JButton buttonExit;
    private JPanel centerPanel;
    private GridBagConstraints c;
    private JPanel topPanel;

    /**
     * Represents the login view of the application.
     * This view allows users to log in to the system.
     */
    public LoginView(CtrlPresentation pctrlPresentation, MainView mainView) {
        ictrlPresentation = pctrlPresentation;
        this.mainView = mainView;
        initializeComponents();
    }

    /**
     * Initializes the components of the LoginView.
     * This method sets up the UI components such as text fields, buttons, panels, and event listeners.
     * It also configures the layout and appearance of the components.
     */
    public void initializeComponents() {
        txtUser = new JTextField(15);
        txtPassword = new JPasswordField(15);
        buttonLogin = new JButton("Login");
        mainpanel = new JPanel(new BorderLayout());
        buttonBack = new JButton("Back");
        buttonExit = new JButton("Exit");
        centerPanel = new JPanel(new GridBagLayout());
        c = new GridBagConstraints();
        topPanel = new JPanel(new BorderLayout());

        setTitle("Login");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(768, 576);
        setResizable(false);
        setLocationRelativeTo(null);

        centerPanel.setBackground(new Color(249, 249, 249));
        c.insets = new Insets(10, 10, 10, 10);
        c.gridx = 0;
        c.gridy = 0;
        c.anchor = GridBagConstraints.WEST;

        ictrlPresentation.configureTextField(txtUser);
        ictrlPresentation.configureTextField(txtPassword);

        centerPanel.add(ictrlPresentation.configureLabel("User: ", 24), c);
        c.gridx++;
        centerPanel.add(txtUser, c);

        c.gridx = 0;
        c.gridy++;
        centerPanel.add(ictrlPresentation.configureLabel("Password: ", 24), c);
        c.gridx++;
        centerPanel.add(txtPassword, c);

        c.gridx = 0;
        c.gridy++;
        c.gridwidth = 2;
        c.anchor = GridBagConstraints.CENTER;
        buttonLogin.setFont(new Font("Arial", Font.PLAIN, 22));
        buttonLogin.setBackground(Color.WHITE);
        buttonLogin.setPreferredSize(new Dimension(200, 50));
        centerPanel.add(buttonLogin, c);

        topPanel.setBackground(new Color(2, 136, 209));
        topPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        buttonBack.setBackground(Color.WHITE);
        buttonBack.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                mainView.setVisible(true);
                dispose();
            }
        });
        topPanel.add(buttonBack, BorderLayout.WEST);

        buttonExit.setBackground(Color.WHITE);
        buttonExit.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
        topPanel.add(buttonExit, BorderLayout.EAST);

        mainpanel.add(topPanel, BorderLayout.NORTH);
        mainpanel.add(centerPanel, BorderLayout.CENTER);

        buttonLogin.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    ictrlPresentation.login(txtUser.getText(), new String(txtPassword.getPassword()));
                    new MenuView(ictrlPresentation, mainView).setVisible(true);
                    dispose();
                } catch (ExceptionUser exceptionUser) {
                    JOptionPane.showMessageDialog(null, exceptionUser.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        add(mainpanel);
    }
}
