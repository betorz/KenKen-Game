package main.presentation.views;

import java.awt.event.ActionListener;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import main.presentation.controllers.CtrlPresentation;

/**
 * Represents a menu view in the presentation layer.
 * This view is responsible for displaying the menu options to the user.
 */
public class MenuView extends JFrame {
    private CtrlPresentation ictrlPresentation;
    private MainView mainView;

    private JLabel lblTitle;
    private JLabel lblUser;
    private JButton buttonPlay;
    private JButton buttonGameCreator;
    private JButton buttonRanking;
    private JButton buttonStats;
    private JButton buttonProfileManagement;
    private JButton buttonExit;
    private JPanel buttonPanel;
    private JPanel topPanel;

    /**
     * Represents a menu view in the presentation layer.
     * This view is responsible for displaying the menu options to the user.
     */
    public MenuView(CtrlPresentation pctrlPresentation, MainView mainView) {
        this.ictrlPresentation = pctrlPresentation;
        this.mainView = mainView;
        initializeComponents();
    }

    /**
     * Initializes the components of the menu view.
     * This method sets up the UI elements such as labels, buttons, panels, and their properties.
     * It also configures the button tooltips and adds action listeners to handle button clicks.
     */
    public void initializeComponents() {
        lblTitle = new JLabel("Main Menu");
        buttonPlay = new JButton("Play");
        buttonGameCreator = new JButton("Create");
        buttonRanking = new JButton("Ranking");
        buttonStats = new JButton("Stats");
        buttonProfileManagement = new JButton("Profile");
        buttonExit = new JButton("Exit");
        buttonPanel = new JPanel(new GridBagLayout());
        topPanel = new JPanel(new BorderLayout());
        lblUser = new JLabel("Hi, " + ictrlPresentation.getCurrentUsername() + "!");

        setTitle("Main Menu");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(768, 576);
        setResizable(false);
        setLocationRelativeTo(null);

        setLayout(new BorderLayout());
        getContentPane().setBackground(new Color(249, 249, 249));

        lblTitle.setFont(new Font("Arial", Font.BOLD, 30));
        lblTitle.setForeground(Color.WHITE);
        lblTitle.setHorizontalAlignment(SwingConstants.CENTER);

        lblUser.setFont(new Font("Arial", Font.BOLD, 20));
        lblUser.setForeground(Color.WHITE);

        topPanel.setBackground(new Color(2, 136, 209));
        topPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        topPanel.add(lblTitle, BorderLayout.SOUTH);
        topPanel.add(buttonExit, BorderLayout.EAST);
        topPanel.add(lblUser, BorderLayout.WEST);

        buttonExit.setBackground(Color.WHITE);
        buttonExit.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });

        buttonPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        buttonPanel.setBackground(new Color(249, 249, 249));

        configureButtonTooltip(buttonPlay, "Start a new game or continue one already started");
        configureButtonTooltip(buttonGameCreator, "Create a new game");
        configureButtonTooltip(buttonRanking, "View the different rankings of players");
        configureButtonTooltip(buttonStats, "View your own stats");
        configureButtonTooltip(buttonProfileManagement, "Manage your profile settings");

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.BOTH;
        gbc.weightx = 1.0;
        gbc.weighty = 1.0;

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        buttonPanel.add(buttonPlay, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 1;
        buttonPanel.add(buttonGameCreator, gbc);

        gbc.gridx = 1;
        gbc.gridy = 1;
        buttonPanel.add(buttonRanking, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        buttonPanel.add(buttonStats, gbc);

        gbc.gridx = 1;
        gbc.gridy = 2;
        buttonPanel.add(buttonProfileManagement, gbc);

        add(topPanel, BorderLayout.NORTH);
        add(buttonPanel, BorderLayout.CENTER);

        buttonPlay.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new LevelSelectorView(ictrlPresentation, MenuView.this).setVisible(true);
                dispose();
            }
        });

        buttonGameCreator.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new CreateMenuView(ictrlPresentation, MenuView.this).setVisible(true);
                dispose();
            }
        });

        buttonRanking.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new RankingView(ictrlPresentation, MenuView.this).setVisible(true);
                dispose();
            }
        });

        buttonStats.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new StatsView(ictrlPresentation, MenuView.this).setVisible(true);
                dispose();
            }
        });

        buttonProfileManagement.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new MenuProfileManagementView(ictrlPresentation, mainView, MenuView.this).setVisible(true);
                dispose();
            }
        });
    }

    /**
     * Configures the tooltip for a given button.
     *
     * @param button   the button to configure the tooltip for
     * @param tooltip  the tooltip text to be displayed when hovering over the button
     */
    private void configureButtonTooltip(JButton button, String tooltip) {
        button.setFont(new Font("Arial", Font.PLAIN, 25));
        //button.setToolTipText(tooltip);
        button.setFocusPainted(false);
        button.setBackground(Color.WHITE);
        button.setForeground(new Color(6,6,6));
    }
}

