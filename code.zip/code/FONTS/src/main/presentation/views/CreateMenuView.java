package main.presentation.views;

import java.io.File;
import java.io.FileNotFoundException;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.util.List;

import javax.swing.filechooser.FileNameExtensionFilter;

import main.domain.classes.exceptions.ExceptionBoard;
import main.domain.classes.Board;
import main.presentation.controllers.CtrlPresentation;

/**
 * Represents a view for creating a menu in the application.
 * This view extends the JFrame class and provides functionality for creating a new game, creating a game with filters, and uploading a .txt file.
 * The view contains various panels and buttons for user interaction.
 */
public class CreateMenuView extends JFrame {

    private CtrlPresentation ctrlPresentation;
    private MenuView menuView;

    private int size;
    private int totalCells;
    private int usedCells;

    private JPanel topPanel;
    private JButton buttonBack;
    private JButton buttonExit;
    private JPanel centerPanel;
    private JButton createWithFiltersButton;
    private JButton createGameButton;
    private JButton uploadButton;
    private JFileChooser fileChooser;
    private JOptionPane filterOptionPane;
    private JPanel leftPanel;
    private JPanel rightPanel;
    private JPanel bottomPanel;
    

    /**
     * Represents a view for creating a menu.
     * This view allows the user to create a menu by selecting cells on a grid.
     * The created menu can be used for various purposes in the application.
     */
    public CreateMenuView(CtrlPresentation ictrlPresentation, MenuView menuView) {

        this.ctrlPresentation = ictrlPresentation;
        this.menuView = menuView;
        this.setTitle("Create Menu");
        this.setSize(768, 576);
        this.setLayout(new BorderLayout());

        size = 3;
        totalCells = size*size;
        usedCells = 0;

        initializeComponents();

        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null);
        this.setVisible(true);

    }

    /**
     * Initializes the components of the CreateMenuView.
     * This method sets up the top, center, left, right, and bottom panels of the view.
     * It also sets the borders and background colors for the panels.
     */
    private void initializeComponents() {

        initTopPanel();
        initCenterPanel();
        leftPanel = new JPanel();
        rightPanel = new JPanel();
        bottomPanel = new JPanel();
        leftPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        leftPanel.setBackground(new Color(249, 249, 249));
        rightPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        rightPanel.setBackground(new Color(249, 249, 249));
        bottomPanel.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        bottomPanel.setBackground(new Color(249, 249, 249));
        
        CreateMenuView.this.add(rightPanel, BorderLayout.EAST);
        CreateMenuView.this.add(leftPanel, BorderLayout.WEST);
        CreateMenuView.this.add(bottomPanel, BorderLayout.SOUTH);
    }

    /**
     * Initializes the center panel of the CreateMenuView.
     * This method sets up the layout, components, and event listeners for the center panel.
     */
    private void initCenterPanel() {
        
        centerPanel = new JPanel(new GridLayout(3,1,0,30));
        centerPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 10, 20));
        centerPanel.setBackground(new Color(249, 249, 249));


        createGameButton = new JButton("Create New Game");
        createGameButton.setBackground(Color.WHITE);
        createGameButton.setFont(new Font("Arial", Font.PLAIN, 22));
        createWithFiltersButton = new JButton("Create With Filters");
        createWithFiltersButton.setBackground(Color.WHITE);
        createWithFiltersButton.setFont(new Font("Arial", Font.PLAIN, 22));
        uploadButton = new JButton("Upload .txt");
        uploadButton.setBackground(Color.WHITE);
        uploadButton.setFont(new Font("Arial", Font.PLAIN, 22));

        createGameButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new CreateGameView(ctrlPresentation, CreateMenuView.this).setVisible(true);
                dispose();
            }        
        });

        createWithFiltersButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                List<Integer> predefinedRegions = new ArrayList<>();
                HashSet<Integer> predOps = new HashSet<>();

                JPanel filterPanel = new JPanel(new BorderLayout());
                JPanel filterPanelLeft = new JPanel(new BorderLayout());
                JPanel filterPanelCenter = new JPanel(new BorderLayout());
                JPanel filterPanelCenterTop = new JPanel(new BorderLayout());

                JComboBox<String> filterComboBox = new JComboBox<>(new String[] {"3x3", "4x4", "5x5", "6x6", "7x7", "8x8", "9x9"});
                filterPanelLeft.add(filterComboBox, BorderLayout.NORTH);


                JList<String> operationList = new JList<String> (new String[] {"=, +", "=, +, -", "=, +, -, * /", "=, +, -, *, /, %, ^"});
                operationList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
                operationList.setSelectedIndex(0);
                JScrollPane operationListScroller = new JScrollPane(operationList);
                operationListScroller.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
                filterPanelLeft.add(operationListScroller, BorderLayout.CENTER);

                JTextField regionSize = new JTextField();
                regionSize.setText("Region size: ");
                regionSize.addFocusListener(new FocusAdapter() {
                    public void focusGained(FocusEvent e) {
                        regionSize.setText("");
                    }
                });

                filterPanelCenterTop.add(regionSize, BorderLayout.CENTER);
                JButton addRegionSize = new JButton("Add");
                
                filterPanelCenterTop.add(addRegionSize, BorderLayout.EAST);
                filterPanelCenter.add(filterPanelCenterTop, BorderLayout.NORTH);

                JPanel regionValuesPanel = new JPanel(new GridLayout(0,1,0,10));
                JScrollPane regionValuesScroller = new JScrollPane(regionValuesPanel);
                regionValuesScroller.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
                filterPanelCenter.add(regionValuesScroller, BorderLayout.CENTER);

                filterComboBox.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        String selectedSize = (String) filterComboBox.getSelectedItem();
                        size = Integer.parseInt(selectedSize.substring(0, 1));
                        totalCells = size*size;
                        regionValuesPanel.removeAll();
                        regionValuesPanel.revalidate();
                        regionValuesPanel.repaint();
                        usedCells = 0;
                        predefinedRegions.clear();;
                    }
                });

                filterPanel.add(filterPanelLeft, BorderLayout.WEST);
                filterPanel.add(filterPanelCenter, BorderLayout.CENTER);

                filterPanelLeft.setBorder(BorderFactory.createEmptyBorder(20, 5, 20, 5));
                filterPanelCenter.setBorder(BorderFactory.createEmptyBorder(20, 5, 20, 5));
                filterPanel.setPreferredSize(new Dimension(400, 300));

                addRegionSize.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        String regionSizeText = regionSize.getText();


                        if (regionSizeText.isEmpty() || regionSizeText.equals("Region size: ")) {
                            JOptionPane.showMessageDialog(filterOptionPane, 
                            "Region size is empty", 
                            "Warning", 
                            JOptionPane.ERROR_MESSAGE);
                            return;
                        }

                        try {
                            int regionResult = Integer.parseInt(regionSizeText);

                            if (regionResult < 1) {
                                JOptionPane.showMessageDialog(filterOptionPane, 
                                "Region size has to be bigger than 0", 
                                "Warning", 
                                JOptionPane.ERROR_MESSAGE);
                                return;
                            }
                            if (regionResult > size) {
                                JOptionPane.showMessageDialog(filterOptionPane, 
                                "Region size has to be smaller than the board size", 
                                "Warning", 
                                JOptionPane.ERROR_MESSAGE);
                                return;
                            }

                        } catch (NumberFormatException ex) {
                            JOptionPane.showMessageDialog(null, 
                            "Region size must be a number", 
                            "Warning", 
                            JOptionPane.ERROR_MESSAGE);
                            return;
                        }

                        usedCells += Integer.parseInt(regionSizeText);

                        if (usedCells > totalCells) {
                            JOptionPane.showMessageDialog(null, 
                            "The total number of cells used is bigger than the board size. Only " + (totalCells - usedCells) + " cells left", 
                            "Warning", 
                            JOptionPane.ERROR_MESSAGE);
                            usedCells -= Integer.parseInt(regionSizeText);
                            return;
                        }

                        predefinedRegions.add(Integer.parseInt(regionSizeText));

                        JLabel regionLabel = new JLabel("Region with " + regionSizeText + " cells");
                        JButton removeRegion = new JButton("Remove");

                        JPanel regionPanel = new JPanel(new BorderLayout());
                        regionPanel.add(regionLabel, BorderLayout.CENTER);
                        regionPanel.add(removeRegion, BorderLayout.EAST);
                        regionValuesPanel.add(regionPanel);

                        removeRegion.addActionListener(new ActionListener() {
                            @Override
                            public void actionPerformed(ActionEvent e) {
                                regionValuesPanel.remove(regionPanel);
                                regionValuesPanel.revalidate();
                                regionValuesPanel.repaint();
                                usedCells -= Integer.parseInt(regionSizeText);
                                predefinedRegions.remove(Integer.parseInt(regionSizeText));
                            }
                        });

                        regionValuesPanel.revalidate();
                        regionValuesPanel.repaint();
                    }
                });

                filterOptionPane = new JOptionPane();
                int result = filterOptionPane.showConfirmDialog(null, filterPanel, "Filter Options", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

                if (result == JOptionPane.OK_OPTION) {

                    switch (operationList.getSelectedIndex()) {
                        case 0:
                            predOps.add(0); predOps.add(1);
                            break;
                        case 1:
                            predOps.add(0); predOps.add(1); predOps.add(2);
                            break;
                        case 2:
                            predOps.add(0); predOps.add(1); predOps.add(2); predOps.add(3); predOps.add(4);
                            break;
                        case 3:
                            predOps.add(0); predOps.add(1); predOps.add(2); predOps.add(3); predOps.add(4); predOps.add(5); predOps.add(6);
                            break;
                    }

                    try {
                        ctrlPresentation.generateBoard(size, predefinedRegions, predOps);
                    } catch (ExceptionBoard e1) {
                        JOptionPane.showMessageDialog(null, e1.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                    }
                    Board currentBoard = ctrlPresentation.getCurrentBoard();
                    if (!ctrlPresentation.hasSolution(currentBoard)) {
                        JOptionPane.showMessageDialog(null, 
                        "Your board has no solution", 
                        "Warning", 
                        JOptionPane.ERROR_MESSAGE);
                    }


                    String[] options = {"Show solution", "Play game"};

                    int choice = JOptionPane.showOptionDialog(
                    null, 
                    "Your board has a solution. What do you want to do:", 
                    null, 
                    JOptionPane.DEFAULT_OPTION, 
                    JOptionPane.INFORMATION_MESSAGE, 
                    null, 
                    options, 
                    null);

                    if (choice == 0) {
                        new SolvedKenkenView(ctrlPresentation, CreateMenuView.this).setVisible(true);
                        dispose();
                    }
                    else if (choice == 1) {
                        ctrlPresentation.startCustomGame();
                        new GameView(ctrlPresentation, CreateMenuView.this).setVisible(true);
                        dispose();
                    }
                }
                else if (result == JOptionPane.CANCEL_OPTION) {
                    predefinedRegions.clear();
                }
            }
        });

        uploadButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                fileChooser = new JFileChooser();
                
                FileNameExtensionFilter filter = new FileNameExtensionFilter("Text Files", "txt");
                fileChooser.setFileFilter(filter);
                fileChooser.setAcceptAllFileFilterUsed(false);


                int result = fileChooser.showOpenDialog(null);
                List<Integer> boardInfo = new ArrayList<>();
                if (result == JFileChooser.APPROVE_OPTION) {
                    File selectedFile = fileChooser.getSelectedFile();
                    boardInfo = fileToBoard(selectedFile);
                }

                try {
                    ctrlPresentation.makeBoard(boardInfo);
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, 
                    "Incorrect board", 
                    "Warning", 
                    JOptionPane.ERROR_MESSAGE);
                    return;
                }
                Board currentBoard = ctrlPresentation.getCurrentBoard();
                if (!ctrlPresentation.hasSolution(currentBoard)) {
                    JOptionPane.showMessageDialog(null, 
                    "Your board has no solution", 
                    "Warning", 
                    JOptionPane.ERROR_MESSAGE);
                }
                else {
                    String[] options = {"Show solution", "Play game"};

                    int choice = JOptionPane.showOptionDialog(
                    null, 
                    "Your board has a solution. What do you want to do:", 
                    null, 
                    JOptionPane.DEFAULT_OPTION, 
                    JOptionPane.INFORMATION_MESSAGE, 
                    null, 
                    options, 
                    null);

                    if (choice == 0) {
                        new SolvedKenkenView(ctrlPresentation, CreateMenuView.this).setVisible(true);
                        dispose();
                    }
                    else if (choice == 1) {
                        ctrlPresentation.startCustomGame();
                        new GameView(ctrlPresentation, CreateMenuView.this).setVisible(true);
                        dispose();
                    }
                }
            }
        });

        centerPanel.add(createGameButton);
        centerPanel.add(createWithFiltersButton);
        centerPanel.add(uploadButton);

        CreateMenuView.this.add(centerPanel, BorderLayout.CENTER);

    }

    /**
     * Reads the contents of a file and converts it into a list of integers representing board information.
     * The file should be formatted in a specific way, with each line containing the necessary information for a board.
     * The method performs various checks to validate the file format and contents.
     *
     * @param selectedFile the file to read and convert
     * @return a list of integers representing the board information, or null if there was an error
     */
    private List<Integer> fileToBoard(File selectedFile) {

        List<Integer> boardInfo = new ArrayList<>();

        try {
            Scanner sf = new Scanner(selectedFile);
            int size = sf.nextInt();
            if (size < 3 || size > 9) {
                sf.close();
                JOptionPane.showMessageDialog(null, 
                "Invalid board size", 
                "Error", 
                JOptionPane.ERROR_MESSAGE);
                return null;
            }
            boardInfo.add(size);

            int numRegions = sf.nextInt();
            if (numRegions < 1 || numRegions > size*size) {
                sf.close();
                JOptionPane.showMessageDialog(null, 
                "Invalid number of regions", 
                "Error", 
                JOptionPane.ERROR_MESSAGE);
                return null;
            }
            boardInfo.add(numRegions);

            for (int i = 0; i < numRegions; ++i) {
                int op = sf.nextInt();
                boardInfo.add(op);

                int result = sf.nextInt();
                boardInfo.add(result);

                int numCells = sf.nextInt();
                boardInfo.add(numCells);

                for (int j = 0; j < numCells; ++j) {
                    int row = sf.nextInt();
                    boardInfo.add(row);

                    int col = sf.nextInt();
                    boardInfo.add(col);

                    if (sf.hasNext()) {
                        sf.useDelimiter("");
                        sf.next();

                        if (sf.hasNext("\\[")) {
                            sf.next();
                            int value = sf.nextInt();
                            boardInfo.add(-1);
                            boardInfo.add(value);
                            boardInfo.add(-1);
                            sf.next();
                        }
                        sf.useDelimiter("\\s+");
                    }
                }
            }
            sf.close();
        } catch (FileNotFoundException e) {
            JOptionPane.showMessageDialog(null, 
                "File not found", 
                "Error", 
                JOptionPane.ERROR_MESSAGE);
            return null;
        } catch (InputMismatchException e) {
            JOptionPane.showMessageDialog(null, 
                "Invalid file format", 
                "Error", 
                JOptionPane.ERROR_MESSAGE);
            return null;
        }
        
        return boardInfo;
    }

    /**
     * Initializes the top panel of the CreateMenuView.
     * This panel contains buttons for navigation and exiting the application.
     */
    private void initTopPanel() {

        buttonBack = new JButton("Back");
        buttonBack.setBackground(Color.WHITE);

        topPanel = new JPanel(new BorderLayout());
        topPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        topPanel.setBackground(new Color(2, 136, 209));
        topPanel.add(buttonBack, BorderLayout.WEST);

        buttonBack.addActionListener(e -> {
            this.menuView.setVisible(true);
            dispose();
        });

        buttonExit = new JButton("Exit");
        buttonExit.setBackground(Color.WHITE);
        topPanel.add(buttonExit, BorderLayout.EAST);
        buttonExit.addActionListener(e-> {
            System.exit(0);
        });

        CreateMenuView.this.add(topPanel, BorderLayout.NORTH);
    }
}
