package main.presentation.views;

import main.domain.classes.Game;
import main.domain.classes.exceptions.ExceptionBoard;
import main.domain.classes.exceptions.ExceptionGame;
import main.domain.classes.exceptions.ExceptionUser;
import main.presentation.controllers.CtrlPresentation;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * The LevelSelectorView class represents the GUI view for selecting game levels.
 * It extends the JFrame class and provides a graphical interface for the user to
 * choose from different levels of the game.
 *
 * The LevelSelectorView class contains various components such as buttons, labels,
 * and panels to display the level options. It also interacts with the CtrlPresentation
 * and MenuView classes to handle user actions and navigate between views.
 *
 * The LevelSelectorView class initializes its components, sets up the layout, and
 * handles button actions to start the game at the selected level. It also displays
 * the status of each level, such as whether it is finished or in progress.
 *
 * @param ctrlPresentation The CtrlPresentation object for handling game logic.
 * @param menuView The MenuView object for navigating back to the main menu.
 */
public class LevelSelectorView extends JFrame {


    private CtrlPresentation ctrlPresentation;
    private MenuView menuView;

    private JPanel topPanel;
    private JButton buttonBack;
    private JButton buttonExit;

    private JScrollPane centerPanel;

    private JPanel allLevelsPane;
    private JPanel easyLevels;
    private JPanel mediumLevels;
    private JPanel hardLevels;
    private JPanel expertLevels;

    private JButton levelButton;
    private int pressedLevel;
    private JButton pressedButton;

    private JLabel easyLabel;
    private JPanel easyLabelPanel;
    private JPanel easyPanel;

    private JLabel mediumLabel;
    private JPanel mediumLabelPanel;
    private JPanel mediumPanel;

    private JLabel hardLabel;
    private JPanel hardLabelPanel;
    private JPanel hardPanel;

    private JLabel expertLabel;
    private JPanel expertLabelPanel;
    private JPanel expertPanel;


    public LevelSelectorView(CtrlPresentation ctrlPresentation, MenuView menuView) {
        this.ctrlPresentation = ctrlPresentation;
        this.menuView = menuView;

        this.setTitle("Level Selector");
        this.setSize(768, 576);

        initializeComponents();

        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null);
    }

    /**
     * Initializes the components of the LevelSelectorView.
     * This method sets up the UI elements such as buttons, labels, and panels,
     * and adds them to the LevelSelectorView.
     */
    private void initializeComponents() {
        
        JPanel legendPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        pressedButton = new JButton();
        JLabel defaultLabel = new JLabel("Start");
        defaultLabel.setOpaque(true);
        defaultLabel.setBackground(Color.WHITE);

        JLabel yellowLabel = new JLabel("Continue");
        yellowLabel.setOpaque(true);
        yellowLabel.setBackground(Color.YELLOW);

        JLabel greenLabel = new JLabel("Finished");
        greenLabel.setOpaque(true);
        greenLabel.setBackground(Color.GREEN);

        legendPanel.add(defaultLabel);
        legendPanel.add(yellowLabel);
        legendPanel.add(greenLabel);
        legendPanel.setBackground(new Color(2, 136, 209));
        
        
        //Top panel
        buttonBack = new JButton("Back");
        buttonBack.setBackground(Color.WHITE);

        topPanel = new JPanel(new BorderLayout());
        topPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        topPanel.add(buttonBack, BorderLayout.WEST);
        topPanel.add(legendPanel, BorderLayout.SOUTH);
        topPanel.setBackground(new Color(2, 136, 209));

        buttonBack.addActionListener(e -> {
            this.menuView.setVisible(true);
            dispose();
        });

        this.add(topPanel, BorderLayout.NORTH);

        buttonExit = new JButton("Exit");
        buttonExit.setBackground(Color.WHITE);
        topPanel.add(buttonExit, BorderLayout.EAST);
        buttonExit.addActionListener(e-> {
            System.exit(0);
        });

        //Center panel
        allLevelsPane = new JPanel();
        allLevelsPane.setLayout(new BoxLayout(allLevelsPane,BoxLayout.PAGE_AXIS));

        easyLevels = new JPanel(new GridLayout(0, 4, 7,7));
        mediumLevels = new JPanel(new GridLayout(0, 4, 7,7));
        hardLevels = new JPanel(new GridLayout(0, 4, 7,7));
        expertLevels = new JPanel(new GridLayout(0, 4, 7,7));

        int numBoards;
        try {
            numBoards = this.ctrlPresentation.getNumBoards();
        } catch (ExceptionBoard e1) {
            JOptionPane.showMessageDialog(null, e1.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        for (int i = 0; i < numBoards; ++i) {
            levelButton = getLevelButton(i);
            int boardDifficulty;
            try {
                boardDifficulty = this.ctrlPresentation.getBoardDifficulty(i);
            } catch (ExceptionBoard e1) {
                JOptionPane.showMessageDialog(null, e1.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            switch (boardDifficulty) {
                case 1:
                    easyLevels.add(levelButton);
                    break;
                case 2:
                    mediumLevels.add(levelButton);
                    break;
                case 3:
                    hardLevels.add(levelButton);
                    break;
                case 4:
                    expertLevels.add(levelButton);
                    break;
            }
        }

        this.easyLabel = new JLabel("EASY");
        this.easyLabel.setFont(new Font("Arial", Font.PLAIN, 18));
        this.easyLabelPanel = new JPanel(new FlowLayout());
        this.easyLabelPanel.add(easyLabel);
        this.easyPanel = new JPanel(new BorderLayout());
        this.easyPanel.add(easyLabel, BorderLayout.NORTH);
        this.easyPanel.add(easyLevels, BorderLayout.CENTER);
        this.easyPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        this.mediumLabel = new JLabel("MEDIUM");
        this.mediumLabel.setFont(new Font("Arial", Font.PLAIN, 18));
        this.mediumLabelPanel = new JPanel(new FlowLayout());
        this.mediumLabelPanel.add(mediumLabel);
        this.mediumPanel = new JPanel(new BorderLayout());
        this.mediumPanel.add(mediumLabel, BorderLayout.NORTH);
        this.mediumPanel.add(mediumLevels, BorderLayout.CENTER);
        this.mediumPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));


        this.hardLabel = new JLabel("HARD");
        this.hardLabel.setFont(new Font("Arial", Font.PLAIN, 18));
        this.hardLabelPanel = new JPanel(new FlowLayout());
        this.hardLabelPanel.add(hardLabel);
        this.hardPanel = new JPanel(new BorderLayout());
        this.hardPanel.add(hardLabel, BorderLayout.NORTH);
        this.hardPanel.add(hardLevels, BorderLayout.CENTER);
        this.hardPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));


        this.expertLabel = new JLabel("EXPERT");
        this.expertLabel.setFont(new Font("Arial", Font.PLAIN, 18));
        this.expertLabelPanel = new JPanel(new FlowLayout());
        this.expertLabelPanel.add(expertLabel);
        this.expertPanel = new JPanel(new BorderLayout());
        this.expertPanel.add(expertLabel, BorderLayout.NORTH);
        this.expertPanel.add(expertLevels, BorderLayout.CENTER);
        this.expertPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        allLevelsPane.add(easyPanel);
        allLevelsPane.add(mediumPanel);
        allLevelsPane.add(hardPanel);
        allLevelsPane.add(expertPanel);

        centerPanel = new JScrollPane(allLevelsPane);
        centerPanel.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);

        centerPanel.setBackground(new Color(249, 249, 249));
        this.add(centerPanel, BorderLayout.CENTER);

    }

    /**
     * An implementation of a button component. A button is a control that can be clicked by the user to perform an action.
     * This class extends the {@link AbstractButton} class and provides additional functionality specific to buttons.
     */
    private JButton getLevelButton(int i) {
        int levelNum = i;
        levelButton = new JButton() {
            @Override
            public Dimension getPreferredSize() {
                Dimension size = super.getPreferredSize();
                int newDimension = size.width;
                return new Dimension(newDimension, newDimension);
            }
        };
        try {
            switch (this.ctrlPresentation.getBoardSize(i)) {
                case 3:
                    levelButton.setText("3x3");
                    break;
                case 4:
                    levelButton.setText("4x4");
                    break;
                case 5:
                    levelButton.setText("5x5");
                    break;
                case 6:
                    levelButton.setText("6x6");
                    break;
                case 7:
                    levelButton.setText("7x7");
                    break;
                case 8:
                    levelButton.setText("8x8");
                    break;
                case 9:
                    levelButton.setText("9x9");
                    break;
            }
        } catch (ExceptionBoard e) {
            JOptionPane.showMessageDialog(null, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }


        try {
            Game savedGame = ctrlPresentation.getSavedGame(i);
            boolean isFinished = ctrlPresentation.isFinished(levelNum); 
            if (isFinished) {
                levelButton.setBackground(Color.GREEN);
            } else if (savedGame != null && savedGame.isStarted()) {
                levelButton.setBackground(Color.YELLOW);
            }
            else {
                levelButton.setBackground(Color.WHITE);
            }
        }
        catch (ExceptionUser e) {
            JOptionPane.showMessageDialog(null, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
        catch (ExceptionBoard e) {
            JOptionPane.showMessageDialog(null, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }

        levelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    try {
                        try {
                            LevelSelectorView.this.ctrlPresentation.startGame(levelNum);
                        } catch (ExceptionBoard e1) {
                            JOptionPane.showMessageDialog(null, e1.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                        }
                    } catch (ExceptionUser e1) {
                        JOptionPane.showMessageDialog(null, e1.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                    }
                    pressedLevel = levelNum;
                    pressedButton = (JButton) e.getSource();
                    new GameView(LevelSelectorView.this.ctrlPresentation, LevelSelectorView.this).setVisible(true);
                    dispose();
                } catch (ExceptionGame ex) {
                    JOptionPane.showMessageDialog(null, ex.getMessage(), "ERROR", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        return levelButton;
    }

    
    /**
     * Sets the visibility of the LevelSelectorView.
     *
     * @param visible true to make the LevelSelectorView visible, false to hide it
     */
    public void setVisible(boolean visible) {
        super.setVisible(visible);

        if (visible) {  
            try {
                Game savedGame = ctrlPresentation.getSavedGame(pressedLevel);
                boolean isFinished = ctrlPresentation.isFinished(pressedLevel); 
                if (isFinished) {
                    System.out.println(pressedButton);
                    pressedButton.setBackground(Color.GREEN);
                } else if (savedGame != null && savedGame.isStarted()) {
                    pressedButton.setBackground(Color.YELLOW);
                }
                else {
                    pressedButton.setBackground(Color.WHITE);
                }
            }
            catch (ExceptionUser e) {
                JOptionPane.showMessageDialog(null, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
            catch (ExceptionBoard e) {
                JOptionPane.showMessageDialog(null, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
}
