# Projecte KenKen - Presentació - Resources

Aquest directori conté els recursos addicionals per a les vistes del projecte KenKen. Aquests recursos són utilitzats en la interfície gràfica d'usuari (GUI).

## Fitxers i Recursos

1. **kenken.png**
   - Imatge utilitzada en la interfície gràfica d'usuari.
