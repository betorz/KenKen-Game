package main.presentation.views;

import java.awt.event.ActionListener;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import main.domain.classes.exceptions.ExceptionUser;
import main.presentation.controllers.CtrlPresentation;

/**
 * Represents a view for managing user profiles in the menu.
 * This class is responsible for initializing the components and handling user interactions related to profile management.
 *
 * @param pctrlPresentation The presentation controller for managing profiles.
 * @param mainView The main view of the application.
 * @param menuView The menu view of the application.
 */
public class MenuProfileManagementView extends JFrame {
    CtrlPresentation ictrlPresentation;
    MainView mainView;
    MenuView menuView;

    private JLabel lblTitle;
    private JButton buttonChangePassword;
    private JButton buttonLogout;
    private JButton buttonDeleteProfile;
    private JButton buttonBack;
    private JButton buttonExit;

    private JPanel buttonPanel;
    private JPanel mainPanel;
    private JPanel centerPanel;
    private JPanel topPanel;
    private JPanel emptyPanel;

    private CardLayout cardLayout;

    private JPanel changePasswordPanel;
    private JPasswordField txtCurrentPassword;
    private JPasswordField txtNewPassword;
    private JPasswordField txtConfirmPassword;
    private JButton buttonSubmit;

    private JPanel logoutPanel;
    private JButton buttonYes;
    private JButton buttonNo;
    private JPanel buttonLogoutPanel;

    private JPanel deleteProfilePanel;
    private JLabel lblWarning;
    private JPasswordField txtPassword;
    private JButton buttonConfirm;

    /**
     * Represents a view for managing user profiles in the menu.
     * This class is responsible for initializing the components and handling user interactions related to profile management.
     *
     * @param pctrlPresentation The presentation controller for managing profiles.
     * @param mainView The main view of the application.
     * @param menuView The menu view of the application.
     */
    public MenuProfileManagementView(CtrlPresentation pctrlPresentation, MainView mainView, MenuView menuView) {
        this.ictrlPresentation = pctrlPresentation;
        this.mainView = mainView;
        this.menuView = menuView;
        initializeComponents();
    }

    /**
     * Initializes the components of the MenuProfileManagementView.
     * This method creates and configures various Swing components such as labels, buttons, panels, and layouts.
     * It also sets the title, size, and background color of the frame.
     * Finally, it adds the components to the appropriate containers and sets up event listeners for button actions.
     */
    public void initializeComponents() {
        lblTitle = new JLabel("Profile Management");
        buttonChangePassword = new JButton("Change password");
        buttonLogout = new JButton("Logout");
        buttonDeleteProfile = new JButton("Delete profile");
        buttonBack = new JButton("Back");
        buttonBack.setBackground(Color.WHITE);
        buttonExit = new JButton("Exit");
        buttonExit.setBackground(Color.WHITE);

        buttonPanel = new JPanel(new GridLayout(3, 1, 20, 20));
        mainPanel = new JPanel(new BorderLayout());
        centerPanel = new JPanel(new CardLayout());
        topPanel = new JPanel(new BorderLayout());
        emptyPanel = new JPanel();

        cardLayout = (CardLayout) centerPanel.getLayout();

        changePasswordPanel = new JPanel(new GridBagLayout());
        txtCurrentPassword = new JPasswordField(15);
        txtNewPassword = new JPasswordField(15);
        txtConfirmPassword = new JPasswordField(15);
        buttonSubmit = new JButton("Submit");

        logoutPanel = new JPanel(new GridBagLayout());
        buttonYes = new JButton("Yes");
        buttonNo = new JButton("No");
        buttonLogoutPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 0));

        deleteProfilePanel = new JPanel(new GridBagLayout());
        txtPassword = new JPasswordField(15);
        buttonConfirm = new JButton("Delete profile");

        setTitle("Profile Management");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(768, 576);
        setResizable(false);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());
        getContentPane().setBackground(new Color(60, 63, 65));

        lblTitle.setFont(new Font("Arial", Font.BOLD, 30));
        lblTitle.setForeground(Color.WHITE);
        lblTitle.setHorizontalAlignment(SwingConstants.CENTER);

        topPanel.setBackground(new Color(2, 136, 209));
        topPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        topPanel.add(lblTitle, BorderLayout.SOUTH);

        buttonExit.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
        topPanel.add(buttonExit, BorderLayout.EAST);

        buttonBack.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                menuView.setVisible(true);
                dispose();
            }
        });
        topPanel.add(buttonBack, BorderLayout.WEST);

        buttonChangePassword.setFont(new Font("Arial", Font.PLAIN, 20));
        buttonChangePassword.setBackground(Color.WHITE);
        buttonChangePassword.setForeground(new Color(6,6,6));
        buttonChangePassword.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                cardLayout.show(centerPanel, "ChangePasswordPanel");
            }
        });

        buttonLogout.setFont(new Font("Arial", Font.PLAIN, 20));
        buttonLogout.setBackground(Color.WHITE);
        buttonLogout.setForeground(new Color(6,6,6));
        buttonLogout.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                cardLayout.show(centerPanel, "LogoutPanel");
            }
        });

        buttonDeleteProfile.setFont(new Font("Arial", Font.PLAIN, 20));
        buttonDeleteProfile.setBackground(Color.WHITE);
        buttonDeleteProfile.setForeground(new Color(6,6,6));
        buttonDeleteProfile.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                cardLayout.show(centerPanel, "DeleteProfilePanel");
            }
        });

        buttonPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        buttonPanel.setBackground(new Color(249, 249, 249));
        buttonPanel.add(buttonChangePassword);
        buttonPanel.add(buttonLogout);
        buttonPanel.add(buttonDeleteProfile);

        changePasswordPanel = createChangePasswordPanel();
        logoutPanel = createLogoutPanel();
        deleteProfilePanel = createDeleteProfilePanel();

        emptyPanel.setBackground(new Color(249, 249, 249));
        centerPanel.add(emptyPanel, "EmptyPanel");
        centerPanel.add(changePasswordPanel, "ChangePasswordPanel");
        centerPanel.add(logoutPanel, "LogoutPanel");
        centerPanel.add(deleteProfilePanel, "DeleteProfilePanel");

        mainPanel.add(buttonPanel, BorderLayout.WEST);
        mainPanel.add(centerPanel, BorderLayout.CENTER);

        add(topPanel, BorderLayout.NORTH);
        add(mainPanel, BorderLayout.CENTER);
    }
    
    /**
     * Creates a panel for changing the user's password.
     * This method creates a panel with labels, text fields, and a submit button for changing the user's password.
     * It also configures the appearance of the components and sets up event listeners for the submit button.
     */
    private JPanel createChangePasswordPanel() {
        JPanel changePasswordPanel = new JPanel(new GridBagLayout());
        changePasswordPanel.setBackground(new Color(249, 249, 249));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        changePasswordPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.WEST;
        changePasswordPanel.add(ictrlPresentation.configureLabel("Current password", 20), gbc);

        ictrlPresentation.configureTextField(txtCurrentPassword);
        gbc.gridx = 1;
        changePasswordPanel.add(txtCurrentPassword, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        changePasswordPanel.add(ictrlPresentation.configureLabel("New password", 20), gbc);

        ictrlPresentation.configureTextField(txtNewPassword);
        gbc.gridx = 1;
        changePasswordPanel.add(txtNewPassword, gbc);


        gbc.gridx = 0;
        gbc.gridy = 2;
        changePasswordPanel.add(ictrlPresentation.configureLabel("Confirm password", 20), gbc);
        ictrlPresentation.configureTextField(txtConfirmPassword);
        gbc.gridx = 1;
        changePasswordPanel.add(txtConfirmPassword, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        buttonSubmit.setFont(new Font("Arial", Font.PLAIN, 22));
        buttonSubmit.setBackground(Color.WHITE);
        buttonSubmit.setPreferredSize(new Dimension(200, 50));
        changePasswordPanel.add(buttonSubmit, gbc);

        buttonSubmit.addActionListener(ActionListener -> {
            String currentPassword = new String(txtCurrentPassword.getPassword());
            String newPassword = new String(txtNewPassword.getPassword());
            String confirmPassword = new String(txtConfirmPassword.getPassword());
            try {
                ictrlPresentation.changePassword(currentPassword, newPassword, confirmPassword);
                menuView.setVisible(true);
                dispose();
            } catch (ExceptionUser e) {
                JOptionPane.showMessageDialog(null, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        return changePasswordPanel;
    }
    /** 
     * Creates a panel for logging out the user.
     * This method creates a panel with a message and two buttons for logging out the user.
     * It also configures the appearance of the components and sets up event listeners for the buttons.
     */
    private JPanel createLogoutPanel() {
        JPanel logoutPanel = new JPanel(new GridBagLayout());
        logoutPanel.setBackground(new Color(249,249,249));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        logoutPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        logoutPanel.add(ictrlPresentation.configureLabel("Are you sure you want to logout?", 20), gbc);

        buttonYes.setFont(new Font("Arial", Font.PLAIN, 22));
        buttonYes.setPreferredSize(new Dimension(150, 50));
        buttonYes.setBackground(Color.WHITE);
        buttonYes.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    ictrlPresentation.logout();
                } catch (ExceptionUser e1) {
                    JOptionPane.showMessageDialog(null, e1.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }
                mainView.setVisible(true);
                dispose();
            }
        });

        buttonNo.setFont(new Font("Arial", Font.PLAIN, 22));
        buttonNo.setPreferredSize(new Dimension(150, 50));
        buttonNo.setBackground(Color.WHITE);
        buttonNo.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                menuView.setVisible(true);
                dispose();
            }
        });

        buttonLogoutPanel.setBackground(new Color(249,249,249));
        buttonLogoutPanel.add(buttonYes);
        buttonLogoutPanel.add(buttonNo);

        gbc.gridy = 1;
        logoutPanel.add(buttonLogoutPanel, gbc);

        return logoutPanel;
    }
    /**
     * Creates a panel for deleting the user's profile.
     * This method creates a panel with a warning message, a password field, and a button for deleting the user's profile.
     * It also configures the appearance of the components and sets up event listeners for the button.
     */
    private JPanel createDeleteProfilePanel() {
        JPanel deleteProfilePanel = new JPanel(new GridBagLayout());
        deleteProfilePanel.setBackground(new Color(249,249,249));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        deleteProfilePanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        lblWarning = ictrlPresentation.configureLabel("Warning: This action is irreversible", 20);
        lblWarning.setOpaque(true);
        lblWarning.setBackground(Color.RED);
        deleteProfilePanel.add(lblWarning, gbc);

        gbc.gridy = 1;
        gbc.gridwidth = 1;
        gbc.anchor = GridBagConstraints.WEST;
        deleteProfilePanel.add(ictrlPresentation.configureLabel("Password", 20), gbc);

        ictrlPresentation.configureTextField(txtPassword);
        gbc.gridx = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        deleteProfilePanel.add(txtPassword, gbc);

        buttonConfirm.setFont(new Font("Arial", Font.PLAIN, 22));
        buttonConfirm.setPreferredSize(new Dimension(200, 50));
        buttonConfirm.setBackground(Color.WHITE);
        buttonConfirm.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String password = new String(txtPassword.getPassword());
                try {
                    int choice = JOptionPane.showConfirmDialog(null, "Are you sure you want to delete your profile?", "Warning", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
                    if (choice == JOptionPane.YES_OPTION) {
                        ictrlPresentation.deleteProfile(password);
                        mainView.setVisible(true);
                        dispose();
                    }
                } catch (ExceptionUser e1) {
                    JOptionPane.showMessageDialog(null, e1.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        deleteProfilePanel.add(buttonConfirm, gbc);

        return deleteProfilePanel;
    }
}
