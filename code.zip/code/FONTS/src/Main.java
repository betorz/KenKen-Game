import main.presentation.controllers.CtrlPresentation;
import javax.swing.*;

public class Main {

    public static void main(String[] args) {

        try {
            UIManager.setLookAndFeel("javax.swing.plaf.metal.MetalLookAndFeel");
        }
        catch (UnsupportedLookAndFeelException | IllegalAccessException | InstantiationException | ClassNotFoundException e) {
            e.printStackTrace();
        }

        javax.swing.SwingUtilities.invokeLater(() -> {
            CtrlPresentation ctrlPresentation = new CtrlPresentation();
            ctrlPresentation.initializePresentation();
        });
    }
}
