# Projecte KenKen - Src

Aquest directori conté el codi font principal del projecte KenKen. A continuació es descriu breument el propòsit de cada subcarpeta i fitxer.

## Subcarpetes i Fitxers

### main
- Aquesta subcarpeta conté les diferents parts del projecte, incloent-hi domini, persistència i presentació. Per a més detalls, consulteu el fitxer `index.txt` dins de la carpeta `main`.

### Main.java
- Aquest fitxer conté el punt d'entrada principal del projecte KenKen. És el fitxer que inicialitza i engega l'aplicació.

### Makefile
- Aquest fitxer conté les instruccions per compilar i executar el projecte utilitzant el comandament `make`. Inclou les diferents tasques necessàries per construir, provar i executar l'aplicació.
