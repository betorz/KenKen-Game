# Projecte KenKen - Data

Aquest directori conté els fitxers JSON que s'utilitzen per emmagatzemar dades importants del projecte KenKen. A continuació es descriu breument el propòsit de cada fitxer.

## Fitxers JSON

1. **users.json**
   - Aquest fitxer conté les dades dels usuaris del joc, incloent informació de registre, estadístiques, etc.

2. **boards.json**
   - Aquest fitxer conté les dades dels taulers del joc, incloent informació sobre les configuracions dels puzles, nivells, etc.
