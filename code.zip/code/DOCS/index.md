# Projecte KenKen - DOCS

Aquest directori conté tota la documentació del projecte KenKen.
